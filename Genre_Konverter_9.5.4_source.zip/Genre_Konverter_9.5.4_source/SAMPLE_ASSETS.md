# Preview sample assets — 9.5.3

The ten original user-supplied drum recordings are embedded in `src/ui.ts` as base64 MP3 data and are also retained as standalone files in `samples/`.

Format: MP3, 320 kbit/s, 44.1 kHz, stereo. Each recording decodes gaplessly to the same PCM frame count as its 9.5.2 WAV source (129,074 stereo frames; 2.926848 seconds). Each recording contains four consecutive velocity layers; the existing preview engine continues to select one quarter of the decoded buffer per MIDI velocity layer.

Mapping:
- Kick C1 (36) → kick
- Snare D1 (38) → snare
- Rim / Side Stick C#1 (37) → Alt Snare / rim lane
- Floor Tom F1 (41) → low tom
- Closed Hi-Hat F#1 (42) → closed hat
- Mid Tom A1 (45) → mid tom
- Open Hi-Hat A#1 (46) → open hat
- High Tom C2 (48) → high tom
- Crash C#2 (49) → crash
- Ride D#2 (51) → ride

The preview waits for all ten MP3s to decode before playback. It does not silently substitute synthesized sounds if a sample is missing or fails to decode.

## Conversion validation

All ten embedded MP3 payloads were generated from the byte-identical 9.5.2 WAV files at 320 kbit/s. Gapless decoding was verified against the source PCM frame count. The Web Audio decoding path, four-layer velocity slicing, layer calibration, gain, panning, master chain, scheduler and stop behavior were not modified.
