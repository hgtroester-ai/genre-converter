## 9.5.4 — Branding correction

- Corrected the upper-left brand text to the shared product identity:
  - Genre
  - Converter
  - by HGT
  - supported with AI
- The existing logo mark is unchanged.
- No audio assets, audio engine, MIDI generation, genre logic, or layout dimensions were changed.
- Updated package, manifest, and GUI version labels to 9.5.4.

## 9.5.3 — MP3 Audio Assets

- Replaced the ten embedded WAV preview recordings with 320 kbit/s MP3 assets.
- Kept the four consecutive velocity layers in each recording and verified gapless decoding to the exact original PCM frame count (129,074 stereo frames at 44.1 kHz).
- Removed the ten WAV files from the source sample directory; the ten MP3 files are now the only standalone sample assets.
- The Web Audio decode path, four-way velocity slicing, layer calibration, velocity contour, per-lane gain/pan, master chain, preview scheduler and stop behavior remain unchanged.
- Normalized Audio Engine SHA-256 (excluding the replaced sample payloads and format-label text): `4ee4780c679cac8bfa7a5d007863008bb4853e1a99a30a2519d5a54f6bdd0776` — identical to the normalized 9.5.2 source.
- Ten sample payloads reduced from 10,326,720 bytes to 1,201,620 bytes (88.36% smaller).
- Added MP3 asset validation and updated release regression checks to 9.5.3.

## 9.5.2 — Genre Intelligence

- Added genre-specific voice articulation profiles for all 25 genres.
- Hat, kick, snare, ghost, ride and cymbal accents now follow genre-specific phrasing.
- Existing MIDI events only: no added/removed notes and no timing changes.
- Integrated once into the shared Performance Feel transform.
- Audio preview engine, samples and scheduler remain unchanged.

## 9.5.1 — Verse / Chorus / Bridge Intelligence

- Added explicit section ownership for phrase-development events to prevent overlapping pass layers.
- Chorus evolution remains owned by the dedicated Chorus Section Engine; Bridge contrast and turnarounds remain owned by the Bridge Section/Phrase engines.
- When Intelligent Verse Variations is enabled, it exclusively owns Second/Final Verse Pass development; the shared pass layer no longer adds a second set of Verse ornaments.
- Intro and Outro retain a smaller, section-specific shared ornament budget with restricted instrument lanes.
- Existing First Pass reference, genre rules, lane locks, fills, Song Arc, Probability Engine and MIDI note vocabulary are preserved.
- No GUI, MIDI mapping, audio preview, WAV sample or scheduler changes.
- Added regression coverage for section ownership and exact Audio Engine source hash preservation.

## 9.5.0 — Funk Drummer Intelligence

- Added a physical-performance constraint pass for all five Funk drummer profiles without replacing their authored groove engines or the 9.4.8 Probability Engine.
- Linear Funk and Jazz Funk enforce single-voice sixteenth-note slots; locked-lane events take precedence.
- Open-Hat articulation avoids an immediate same-step closed-hat choke and adds a quiet 16th-note close when the following close is missing and both lanes are editable.
- Added sparse, drummer-specific breathing gaps at higher Groove Variation: Ghost Note Funk and Jazz Funk thin selected closed-hat notes, New Orleans Funk occasionally leaves a ghost-note space, and Amen Break Funk uses rarer hat dropouts. Linear Funk remains unchanged by the dropout layer.
- Fills are excluded, lane locks are respected, no new fills or timing offsets are generated, and the GUI is unchanged.
- The complete Web Audio preview engine and embedded samples remain byte-identical to the 9.4.9 baseline.
- Added dedicated runtime regression coverage for open-hat choke/close, Linear and Jazz single-voice constraints, drummer-specific breathing gaps, locked lanes and fill isolation.

## 9.4.9 — Song Intelligence Refinement

- Combined Song Arc energy, genre/drummer touch and Next Section transition shaping into one bounded velocity pass; removes sequential velocity scaling and repeated clamping.
- Added genre-sensitive transition response so Funk, Jazz, Reggae and Dub retain their characteristic dynamic restraint while Rock, Punk and Heavy styles can use stronger pickups.
- Kept Song Arc responsible for section energy, Dramaturgy as its intensity control, and Next Section as a last-bar destination cue.
- Preserved the non-destructive base-pattern workflow, user sequencer edits, locked lanes, pass intelligence, fill isolation and all genre note vocabularies.
- Added 9.4.9 regression coverage for single-pass composition, transition behavior and exact Audio Engine source hash preservation.
- Web Audio preview engine, embedded WAV samples, scheduler and preview mix remain byte-identical to 9.4.8.

## 9.4.7 — Jazz Pocket Refinement

- Jazz swing, straight and fusion now receive distinct, restrained ride-accent contours as Groove Variation rises.
- Existing snare comping and kick anchors receive subtle style-aware dynamics; no MIDI timing or note positions are changed.
- Generic random ornaments are disabled for Jazz so its authored space and phrasing remain intact.
- Fill patterns, GUI layout, audio preview engine and all non-Jazz genre behavior remain unchanged.

# Version 9.4.6 — Reggae & Dub Pocket Refinement

- Added deterministic, style-aware Reggae accent shaping for One Drop, Rockers, and Steppers.
- Added drummer-sensitive velocity articulation while preserving existing Reggae drummer profiles and authored groove recipes.
- Added controlled Dub breathing gaps at higher Groove Variation settings; offbeat skank and kick/rim anchors remain protected.
- Excluded Dub from generic random groove ornaments so its intentional space is preserved.
- Fill sections are excluded; lane locks are respected.
- Audio preview engine remains byte-identical to the working 9.4.3 reference.
- No GUI layout, audio, sample, scheduler, Re-shuffle, or Fill Intensity changes.

# Version 9.4.5 — Genre Navigation & Full Sequencer Visibility

- Based on the working 9.4.4 Funk/Hip-Hop refinement release.
- Restored the left genre list's independent vertical scrolling; the version label remains fixed.
- Rebuilt the sequencer layout as a fixed ruler plus ten equal-height lane rows, keeping Kick through Ride visible without internal scrolling.
- Reduced lane controls and cell heights to fit the available sequencer area without removing any lane or control.
- Audio engine, embedded WAV samples, AudioContext, preview scheduler, Funk/Hip-Hop groove logic, drummer profiles and fill routines are unchanged.
- Added a layout regression test for genre-list scrolling and all ten sequencer lanes.

# Version 9.4.4 — Funk & Hip-Hop Pocket Refinement

- Development base: 9.4.3. The original preview/audio engine, embedded WAV data, AudioContext startup, scheduler and sample mixing are intentionally unchanged.
- Funk: refined existing ghost-note dynamics, hi-hat accent articulation and kick/snare interaction while retaining each of the five Funk drummer profiles and their authored note patterns.
- Hip-Hop: clearer quarter/eighth/ghost articulation, restrained ghost-note ranges and improved syncopated kick balance.
- Rap: distinct sixteenth-note hat articulation with a restrained phrase-end pickup at Groove Variation values of 40% and above.
- No GUI layout changes. Fill Intensity and the existing fill-generation routines are not modified.

# 9.4.2 – Embedded JavaScript Runtime Repair

- Removed TypeScript-only annotations from the inline browser script in Pass Intelligence.
- Fixed the stylesheet separator introduced in 9.4.1.
- Retained 9.4.0 Pass Intelligence behavior and the 9.3.9 sequencer/genre rendering architecture.

# 9.4.1 – Sequencer Visibility Repair

- Fixed explicit sizing and stacking of all ten sequencer lanes and the bar ruler.
- Reduced decorative background opacity so MIDI events remain clearly visible.
- Kept the existing 1240×820 layout intent, controls and non-scrolling sequencer.

# 9.4.0 – Pass Intelligence

- Added deterministic First Pass / Second Pass / Final Pass development across song sections.
- Added genre-specific lane eligibility for hi-hat, open hi-hat, ride, crash, tom and ghost-note details across all 25 genres.
- Limited Second Pass to two and Final Pass to three optional colour events.
- Prevented open/closed hi-hat collisions; preserved kick/snare anchors and locked lanes.
- Kept fill generation separate and based repeated applications on the immutable Song Arc source pattern.

# Genre Konverter 9.3.9 – Song Section Intelligence

- Added genre- and drummer-aware section touch for Intro, Verse, Chorus, Bridge and Outro.
- Section/drummer interaction reshapes velocities of existing notes only; note positions, lane assignments and note counts remain unchanged.
- Song Arc updates restart from the immutable base pattern, preventing cumulative velocity changes.
- Kept Swing, Performance Feel, Groove Variation, Fill Intensity and existing section-specific groove generators independent.

# Changelog

## 9.3.8 — Performance Feel 2.0
- Reworked all 25 genre performance profiles with tempo-aware timing offsets in milliseconds.
- Increased expressive velocity accents and articulation while retaining the authored rhythm and existing note set.
- Added a perceptible soft-start control curve; Swing remains independent.
- Kept deterministic, bounded variation and shared preview/export transform.

# Changelog

## 9.3.8 — Performance Feel 2.0
- Reworked all 25 genre performance profiles with tempo-aware timing offsets in milliseconds.
- Increased expressive velocity accents and articulation while retaining the authored rhythm and existing note set.
- Added a perceptible soft-start control curve; Swing remains independent.
- Kept deterministic, bounded variation and shared preview/export transform.

# Changelog

## 9.3.8 — Performance Feel 2.0
- Reworked all 25 genre performance profiles with tempo-aware timing offsets in milliseconds.
- Increased expressive velocity accents and articulation while retaining the authored rhythm and existing note set.
- Added a perceptible soft-start control curve; Swing remains independent.
- Kept deterministic, bounded variation and shared preview/export transform.

## 9.3.7 – Performance Feel Engine

- Renamed the Pocket control to Performance Feel.
- Added a bounded five-part performance layer: Micro Timing, Dynamics, Articulation, Interaction and deterministic Human Variation.
- Applies only to existing notes; no MIDI notes are added, removed or substituted.
- Swing remains an independent control. Preview and MIDI export share the same transform.
- Preserves the 25 existing genre timing fingerprints and the 9.3.6 Groove Variation slider.

- Restored the Ableton modal window to the requested 1240 × 820 px. No sequencer scrolling or Pocket/Groove control changes in this release.
## 9.3.3 — Footer Visibility and Song Arc Stability
- Fixed the main-window layout so the bottom action bar remains visible at constrained dialog heights.
- Made the sequencer grid the flexible, vertically scrollable region instead of allowing it to push the footer below the viewport.
- Kept Create MIDI Clip, Cancel, Re-shuffle, Regenerate Fill, Undo and Redo in a persistent bottom action row.
- Preserved the 9.3.2 non-regenerative, velocity-only Song Arc correction.
- Added a regression test for footer visibility and the required action controls.

# Changelog – Genre Konverter 9.3.1

## 9.3.1 — Song Arc Energy Preview
- Added a compact five-section energy overview for Intro, Verse, Chorus, Bridge and Outro.
- Preview levels blend the selected Song Arc with the existing section energy profile using the Dramaturgy Strength control.
- The currently selected song section is highlighted; the preview updates when section, arc preset or strength changes.
- No MIDI generation, transition, groove, drummer, sequencer or audio-engine behavior changed.
- Version metadata and GUI version label updated consistently to 9.3.1.



## 9.2.0 — Song Dramaturgy
- Added four selectable song-wide energy arcs: Classic Build, Slow Burn, Drop & Return, and Cinematic Rise.
- Added a Dramaturgy Strength control that blends each selected arc with the established section-energy behavior.
- Added Auto/manual Next Section context for Verse, Chorus, Bridge, Outro and Song End.
- Added non-destructive transition shaping in the final bar: crescendo into Chorus, pullback into Bridge, gentle reset into Verse, and taper into Outro/Song End.
- Transition shaping changes only existing MIDI note velocities; it does not add notes, alter the rhythmic vocabulary or override locked lanes.
- Applied the transition layer through a universal generator wrapper so specialized genre engines receive the same section-aware treatment.
- Persisted Song Arc, strength and Next Section preferences.
- Added regression coverage for all four arcs, five song sections, 2/4/8-bar interpolation, transitions, no-note-addition behavior and lane locks.
- Full verification suite: 105 scripts passed. Portable build and ABLX/source archive validation completed. No Ableton Live in-host audition is claimed.

## 9.1.3 — Jungle feel and fill refinement
- Jungle default tempo and maximum set to 144 BPM. Drum & Bass remains separately capped at 144 BPM.
- Replaced the generic, near-continuous breakbeat fill with a dedicated Amen-inspired Jungle phrase fill: short kick/snare/ghost/tom exchanges, deliberate gaps, and restrained open-hat landings.
- Refined Verse, Chorus and Bridge velocity contour with bar-level accents and quieter ghost-note replies.
- Bridge retains its half-time snare anchor on beat 3, but now keeps a more active syncopated kick and flowing 8th-note break pulse. The apparent speed drop was caused by the sparse half-time arrangement, not a BPM change.
- Preserved the existing genre banks, fill controls, lane locks and other extension features.

# Changelog

## 9.0.2 — Jazz Chorus & Bridge Completion

- Added eight independent authored Jazz Chorus grooves; the Chorus no longer falls back to the Verse bank.
- Expanded Jazz Bridge from one authored pattern to seven distinct grooves, with spacious comping, broken-time responses, soft tom color and gentle turnarounds.
- Added Jazz-specific Bridge First/Second/Final Pass development. Second Pass adds occasional quiet offbeat comping; Final Pass adds a few restrained phrase-end responses without imposing a rock backbeat.
- Preserved the Jazz triplet ride engine, foot hi-hat on beats 2 and 4, Jazz style selector, lane locks and existing Chorus pass development.
- Added a dedicated Jazz completion regression test and updated the structural genre audit.
- Updated package, manifest, GUI version tag and all active release metadata checks to 9.0.2.
- Full verification suite: all 94 test files passed; portable build, bundle syntax and package integrity checks passed. No Ableton Live in-host audition is claimed.

## 9.0.1 — Complete Genre & Feature Audit

- Audited all 25 selectable genre definitions and their arrangement-family routing.
- Fixed the Hip-Hop arrangement-family lookup (`hiphop`) so it no longer falls through to the generic Rock family.
- Corrected the stale Punk genre key in Intelligent Verse Variation; removed the non-existent `rapRock` key from that classification.
- Added an automated audit for generated tab-bank coverage, Classic Rock's separate authored bank, special Funk/Reggae/Punk/Jazz banks, event lanes, beat positions and MIDI velocities.
- Reconciled the verification command list with the test directory: all 93 test files now run exactly once (two previously omitted tests were restored and one duplicate command removed).
- Confirmed 20 generated genre banks each contain 12 Verse, 8 Chorus, 6 Bridge and 6 Fill tabs.
- Documented remaining content gaps and follow-up priorities in `GENRE_AUDIT_9.0.1.md`; this audit release does not redesign existing grooves.

## 9.0.0 — Jamaican Ska · First Wave

- Added a dedicated 1960s Jamaican First Wave Ska drummer profile, distinct from British 2-Tone and later Ska variants.
- Added swung triplet-grid hi-hat/ride patterns, dry rim-click offbeats, restrained bass-drum support, a jazzier chorus and a quarter-note bridge with rolling rim-click turnaround.
- Added First/Second/Final Pass development, four Re-shuffle recipes, genre-specific fills with intensity control, 2/4/8-bar phrase support, lane-lock awareness and the existing groove/verse/section controls.
- Default tempo: 125 BPM; users can adjust it freely.

# Changelog

## 8.9.25 — Nutty Sound: vollständige 8-Bar-Phrasen
- Nutty Sound erzeugt Verse, Chorus und Bridge jetzt über die komplette ausgewählte Taktzahl (2/4/8).
- Bei 8 Bars bilden Takte 5–8 eine musikalisch weiterentwickelte zweite Viererphrase statt einer bloßen Wiederholung.
- Schlussakzente und Fill-Aufbau liegen jetzt im tatsächlich letzten Takt der gewählten Phrase.
- DanceBEATZ 8-Bar-Verbesserungen aus 8.9.24 und alle bisherigen Profile bleiben erhalten.

## 8.9.24 — DanceBEATZ 8-bar sections

- DanceBEATZ Verse, Chorus and Bridge now honor the global 2/4/8-bar phrase selector.
- Eight-bar sections are composed as two related four-bar phrases, with restrained second-half variations rather than a literal copy.
- Section-specific pass development and Re-shuffle now cover both four-bar halves.
- Preserves 8.9.23 intelligent fill recipes and 0–100 Fill Intensity behavior.
- 4-bar DanceBEATZ phrase layout remains unchanged; final-bar turnarounds move to the actual end of the selected phrase.

## 8.9.22 — DanceBEATZ controls restored and connected

- Re-shuffle now advances through four distinct DanceBEATZ phrase treatments while preserving the Four-on-the-Floor anchor and respecting lane locks.
- Groove Variation now runs in the specialized DanceBEATZ generator path, affecting performance dynamics and restrained ornaments instead of being bypassed by its early return.
- Regenerate Fill remains enabled in every pass and uses the dedicated DanceBEATZ fill builder.
- Explicitly re-enable the Re-shuffle and Regenerate Fill buttons and retain pointer interaction for the Groove Variation knob.
- Added regression coverage for all three controls.

## 8.9.21 — DanceBEATZ Pass-Entwicklung und Verse Variation

- Second und Final Pass entwickeln jetzt den eigentlichen DanceBEATZ-Groove in Verse, Chorus und Bridge – nicht nur die Fills.
- Die optionale Intelligent Verse Variation ist im spezialisierten DanceBEATZ-Generator angeschlossen und ergänzt zusätzliche, über die vier Takte verteilte Verse-Details für Second und Final Pass.
- First Pass bleibt die unveränderte Referenz; Lane-Sperren werden respektiert.
- Two Tone Groove und Nutty Sound bleiben unverändert.

## 8.9.20 — DanceBEATZ Pop-Ska drummer

- Added DanceBEATZ as a third selectable Ska drummer profile, defaulting to 140 BPM.
- Added an exact four-bar Verse with four-on-the-floor kick, offbeat eighth-note hats and clean backbeat.
- Added an eighth-note Chorus with syncopated snare accents, stable club kick and a fourth-bar snare build.
- Added a stripped-back Bridge with quarter-note hats, quiet double ghost notes, half-time kick and a final-bar crescendo.
- Added dedicated First, Second and Final Pass fills; preserved lane locks and the existing Two Tone Groove and Nutty Sound profiles.

## 8.9.19 — Nutty Sound drummer

- Enabled the Nutty Sound Ska drummer profile as a distinct selectable drummer.
- Added a four-bar, ~150 BPM marching/polka Verse with springy alternating kick, clipped snare doubles and crisp eighth-note hats.
- Added an aggressive open-hat Chorus with strong backbeat and driving kick.
- Added a staccato Bridge with separated accents and deliberate space for horn riffs.
- Added pass-specific Nutty Sound turnarounds/fills for First, Second and Final Pass.
- Preserved Two Tone Groove as its own profile and retained lane-lock behavior.

## 8.9.18 — Two Tone Groove fill repair

- Fixed the specialized Two Tone generator returning before Verse, Chorus and Bridge phrase fills were applied.
- Added a dedicated Two Tone ska turnaround: restrained rim/snare pickups in First Pass, extra syncopated kick and tom responses in Second Pass, and a stronger phrase-ending response in Final Pass.
- Preserves the One-Drop anchor: no kick on beat 1; kick and rim remain together on beat 3.
- The Fill regeneration control now uses the same Two Tone-specific fill grammar.

## 8.9.17 — Two Tone Verse Variation repair
- Fixed the specialized Two Tone Groove generator's early return, which bypassed the shared Intelligent Verse Variation pipeline.
- Connected the Verse Variation checkbox directly to the Two Tone phrase engine for Second and Final Verse.
- Added dedicated Ska-aware phrase development: alternate kick pickups, rim/ghost-note answers, selective open-hat changes, accent shifts and a stronger final-bar turnaround.
- Preserved the One-Drop anchor, 130 BPM starting tempo, lane locks, existing Second/Final Pass evolution and all other genre/drummer engines.
- Added a dedicated regression test for the checkbox-to-generator connection and pass-specific phrase changes.

# Changelog

## 8.9.16 — Two Tone Groove phrase development

- Set the Two Tone Groove starting tempo to 130 BPM, including initial load and Ska genre selection.
- Reworked the four-bar Verse, Chorus and Bridge so each bar has a distinct musical role instead of repeating a static one-bar pattern.
- Verse: preserved the empty downbeat / One-Drop anchor while adding offbeat kick answers, restrained rim/ghost-note responses, selective hat openings and a phrase-ending fill.
- Chorus: added syncopated kick movement, ride/crash contrast, snare ghost-note responses and a stronger final-bar turnaround.
- Bridge: expanded the eighth-note ska drive with offbeat kick movement, open-hat changes, ghost-note conversation and a progressive final-bar snare build.
- Second Pass adds controlled rhythmic conversation; Final Pass creates stronger phrase peaks without changing the section identity.
- Added dedicated 8.9.16 regression coverage and updated release-version assertions across the verification suite.

## 8.9.15 — Two Tone Groove (Ska)
- Added the first of five planned Ska drummer profiles: Two Tone Groove.
- Verse: sparse One-Drop with the downbeat intentionally empty, kick and rim-click together on beat 3, and light offbeat hat/skank texture.
- Chorus: quarter-note ride, strong snare on 2 and 4, and kick on 3, with a final-bar lift.
- Bridge: continuous eighth-note hats, a driving kick on 1 and 3, offbeat ghost-note support and a final-bar snare crescendo.
- Added the Ska drummer selector; Nutty Sound, DanceBEATZ, Power-Ska and Jamaican Ska are shown as upcoming profiles and remain disabled until implemented.
- Version metadata synchronized to 8.9.15.

## 8.9.14 — The Proto-Punk Pulse

- Added The Proto-Punk Pulse as a distinct Punk drummer profile inspired by 1969–1973 proto-punk and Detroit/garage rock.
- Verse: heavy half-open eighth-note hi-hat with quarter-note accents, restless kick push around beat 2+, and a hard 2/4 snare backbeat.
- Chorus: quarter-note crash wall with interlocking kick/snare drive; Final Pass adds a rough last-bar snare rake and kick punctuation.
- Bridge: open, triplet-grid shuffle wash with offbeat ghost-note snare; Final Pass builds a rising snare rake and heavier kick movement.
- Second and Final Pass add restrained phrase development while preserving the core groove and respecting lane locks.
- Updated GUI version label, saved-profile validation and release metadata to 8.9.14.

## 8.9.13 — The Downbeat Anchor

- Added The Downbeat Anchor as a selectable Punk drummer profile.
- Verse: precise closed eighth-note hi-hat, kick on beats 1 and 3, snare on 2 and 4; restrained final-pass accents.
- Chorus: eighth-note ride, four-on-the-floor kick and snare on every offbeat for a double-time mosh feel; final bar intensifies.
- Bridge: half-open/sizzling hi-hat, one heavy snare on beat 3 and spacious kick; Final Pass builds a rising snare crescendo with a driving kick return.
- Updated GUI version label, saved-profile validation and release metadata to 8.9.13.

## 8.9.12 — 70s US Garage-Drive

- Added the 70s US Garage-Drive as a distinct Punk drummer profile.
- Verse: open eighth-note hi-hat, straight kick on beats 1 and 3, snare on 2 and 4.
- Chorus: quarter-note crash pulse, four-on-the-floor kick and hard backbeat.
- Bridge: sizzling half-open eighth-note hat, syncopated kick pickup before beat 3; Final Pass closes with quarter-note snare accents.
- First/Second/Final Pass variations remain restrained and deterministic; no shuffle, reggae offbeats or automatic snare rolls.
- Updated GUI version label, selector and release metadata to 8.9.12.

## 8.9.11 — The Tribal Tom-Pulse

- Added a third Punk drummer profile: The Tribal Tom-Pulse.
- Verse: continuous eighth-note Floor Tom drive, snare backbeats and a syncopated kick.
- Chorus: simultaneous eighth-note High Tom and Floor Tom wall, accented snare and driving kick; no cymbals.
- Bridge: sparse closed-hat offbeats, one snare accent on beat 3 and a minimal kick pattern; Final Pass builds a snare swell and four-quarter kick return.
- Added pass-specific MIDI note development for Second and Final Pass while preserving the profile's cymbal-sparse identity.
- Existing drummer profiles and audio/sample engine remain unchanged.

# Changelog

## 8.9.10 — Intelligent Pass Variation 2.0
- Military-Punk Roll: Second and Final Pass now create audible structural developments in Verse, Chorus and Bridge, not only in fills.
- Verse adds staged snare rudiment pickups, selected hat openings and phrase-end kick responses.
- Chorus develops from quarter-note cymbal drive toward selected eighth-note ride motion, kick pushes and a final snare build.
- Bridge adds progressively denser high/floor-tom exchanges and a stronger return march while keeping cymbals silent.
- Intelligent Verse Variation no longer conceptually substitutes for pass evolution; the new pass development is independent of that checkbox.
- Existing groove foundation, other drummer profiles, audio engine and samples remain unchanged.

- Added the first dedicated Punk drummer profile: 77er UK Ska-Drop.
- Verse: offbeat Ska hi-hat accents, snare on beat 3 and syncopated kick.
- Chorus: straight punk backbeat with continuous ride eighths and opening crash.
- Bridge: tom-led military roll with snare movement and a final-bar return cue.
- The profile is isolated to Punk Rock and leaves existing Punk/Pop Punk engines and audio/sample playback unchanged when not selected.

# Changelog

## 8.9.7
- MIDI clip names now include the selected drummer profile for Classic Rock, Funk and Reggae, followed by the song section.
- Clip naming remains generic and backward-compatible for genres without a dedicated drummer selector.
- No groove, MIDI note, sample, preview or audio-engine behavior changed.

- Added Jazz-Funk drummer profile with a 12-bar linear Verse / displaced-backbeat Chorus / up-tempo Bridge arrangement.
- Enforced single-voice sixteenth-note orchestration by resolving same-slot collisions; added subtle behind-the-beat timing and controlled ghost-note pass development.
- Existing Ghost Note Funk, Linear Funk, New Orleans Funk, Classic Rock Bridge, audio engine and original samples retained.

## 8.9.4 — New Orleans Funk and Linear Verse cleanup

- Added a third Funk Drummer profile: New Orleans Funk, with a 12-bar Verse / Second Line Chorus / Meters Bridge arrangement based on the supplied 16-step patterns.
- Added restrained late sixteenth-note placement and soft snare ghost-note articulation for a rolling New Orleans pocket.
- Removed toms from Linear Funk Verse in all passes; Chorus and Bridge behavior remain unchanged.
- Ghost Note Funk and the Classic Rock Bridge/audio/sample engines remain unchanged.

# Changelog

## 8.9.3 — Ghost Note Funk: Clyde-style pocket
- Reworked Ghost Note Funk around the supplied 12-bar example: Verse, Chorus and Bridge patterns with restrained transition bars.
- Removed generated toms from Ghost Note Funk; the profile uses kick, snare, ghost snare and hi-hat only.
- Strong backbeats and very quiet ghost notes create the main dynamic contrast.
- Linear Funk, Classic Rock Bridge, audio engine and original samples are unchanged.

# Changelog

## 8.9.2 — Funk groove identities
- Reworked Ghost Note Funk with a layered 16th-note pocket, quieter snare ghost-note lattice, syncopated kick answers, phrase-ending tom responses and restrained ride/crash punctuation.
- Reworked Linear Funk around a single-voice-per-sixteenth hand-off, including kick, snare, closed hat, high/mid/floor toms and ride.
- Linear Chorus evolution now changes the voice occupying selected slots rather than stacking additional notes, preserving its linear identity.
- Lane locks remain respected; a locked voice retains ownership of its occupied slot.
- Funk selector remains compact and artist-neutral. Classic Rock Bridge, audio engine, samples and other genre engines are unchanged.


- Ghost Note Funk now has a more distinct Chorus identity: stronger eighth-note hi-hat, more ride/open-hat color and restrained kick/snare responses, while Verse retains its tighter pocket.
- Added Linear Funk as a separate profile with interlocking, predominantly non-simultaneous kick, snare and cymbal events plus restrained pass evolution.
- Funk Drummer selector now shows only profile names under the existing heading; artist references removed from the UI.
- Bridge behavior and the established audio engine remain unchanged.

# Changelog

## 8.9.0 — Funk Drummer Evolution: Ghost Note Funk
- Added a dedicated Funk Drummer selector with the first profile, Ghost Note Funk (Clyde Stubblefield / Jabo Starks-inspired playing principles).
- Established a stable, recognizable ghost-note pocket across First, Second and Final Pass; 8-bar phrases use two related four-bar variations.
- Later passes add restrained low-velocity snare ghosts, syncopated kick answers and small hi-hat articulations.
- Respects locked lanes and leaves the existing Classic Rock, Reggae, other genre engines and preview audio engine unchanged.


## 8.8.0 — Classic Rock Bridge Evolution
- Added a dedicated Classic Rock Bridge groove with First, Second and Final Pass development.
- Preserved the six existing Classic Rock drummer identities and added profile-specific touch, timing and cymbal behavior.
- Added restrained Hi-Hat breathing, Ride development, ghost-note details and a final-pass pickup.
- Locked lanes remain untouched; other genre bridge engines and the audio engine are unchanged.

## 8.7.9 — Clean Fill-to-Loop Transition

- Prevented final-bar fill landings from wrapping an extra Kick/Crash/Ride accent onto the first beat of the next loop.
- Kept normal fill landings between internal bars unchanged.
- Applied the same no-wrap rule to the Progressive Rock fill path.
- Preserved the 8.7.8 Chorus phrase evolution and audio scheduler behavior.

## 8.7.8 — Classic Rock Chorus Evolution

- Fixed automatic Repetition progression for both Verse and Chorus: First Pass → Second Pass → Final Pass → Final Pass; the selector and sequencer update together at loop boundaries.
- Expanded the Classic Rock Chorus phrase engine for 4- and 8-bar patterns with drummer-shaped Kick, Snare, Hi-Hat and sparse Ride development.
- Restored a dependable eighth-note chorus hat pulse, then introduced selected sixteenth-note details, intentional spaces, occasional Ride phrases and restrained Open Hat lifts on later passes.
- Kept Classic Rock changes scoped to the Chorus; preserved the audio engine and other genre paths.

## 8.7.7

- Classic Rock chorus: sparse, low-velocity ride punctuation instead of a continuous ride layer.
- Creates deliberate closed-hi-hat breathing spaces around selected ride taps.
- Final pass adds one short, quiet 16th-note hi-hat pickup in bar three.
- Keeps the existing Classic Rock drummer profiles, verse behavior, and other genre chorus rules unchanged.

# Changelog

## 8.7.3 – Intelligent Verse Evolution

- Expanded Verse 1 / Verse 2 / Final Verse development with genre-family-aware phrase variations.
- Verse 1 remains the reference; later passes add restrained, deterministic details instead of replacing the core groove.
- Added genre-specific behavior for Funk, Reggae, Ska, Hip-Hop/Rap/Lo-Fi and rock-family grooves.
- Preserved genre-defining anchors, including Reggae One Drop kick placement and established backbeats.
- Variation respects locked instrument lanes and avoids duplicate note positions.
- Added sparse phrase breathing-space edits and subtle final-pass accent development.
- Kept the 8.7.2 preview/audio engine, sample assets and playback stability implementation unchanged.

# Changelog

## 8.7.2
- Reduced excessive amplification of the quiet Ride velocity layers with a Ride-only peak target and maximum sample gain.
- Kept the original Ride WAV, four velocity layers, timing, other instrument lanes, MIDI generation, and 8.7.1 playback-stability behavior unchanged.


- Added an immutable audio-pattern snapshot so GUI edits cannot mutate events already being read by the playback scheduler.
- Pattern changes are adopted at the next bar boundary without stopping or restarting the preview.
- The look-ahead scheduler no longer schedules across a bar boundary, preventing old and new pattern states from being mixed in the same scheduling window.
- Kept the 8.7.0 original-WAV sample engine, velocity layers, preview mix, and MIDI/groove modules unchanged.
- Synchronized the visible UI version tag, manifest, package metadata, changelog, and release tests to 8.7.1.

## 8.7.0 — Original WAV sample engine cleanup

- Replaced all ten embedded MP3 previews with the ten supplied original WAV recordings (44.1 kHz stereo float WAV).
- The four velocity layers are decoded directly from the original WAV files; no lossy MP3 conversion is used.
- Preview start now waits until all ten original WAV files decode successfully.
- Removed synthetic fallback playback from sample-triggered lanes; a missing/failed sample is reported instead of silently substituting a different sound.
- Alt Snare explicitly uses the supplied Rim / Side Stick C#1 recording, matching the submitted instrument file.
- MIDI generation and groove modules remain unchanged; this release changes preview sample assets/loading only.
- Synchronized the visible UI version tag, manifest, package metadata, changelog, and release tests to 8.7.0.

## 8.6.1 — Preview loudness and transient control

- Increased preview output drive by a factor of 10 while retaining the user's lane faders.
- Added per-hit peak guarding so unusually hot sample layers cannot create isolated level spikes.
- Added a short fade-in to avoid clicks and strengthened the master transient catcher for overlapping hits.
- MIDI generation, note velocities, groove logic and genre patterns are unchanged.

## 8.6.0 — Preview velocity dynamics

- Preview sample playback now follows the actual MIDI velocity continuously within each of the four recorded sample layers.
- Strong accents become more pronounced and low-velocity ghost notes become quieter in the preview.
- The four recorded timbral layers and their per-instrument calibration remain in place.
- Preview-only change: MIDI generation, note timing, note selection, groove, and generated MIDI velocities are unchanged.

## 8.5.9 — Stronger Classic Rock preview

- Increased Classic Rock preview gain for kick and snare to 4.00; alternate snare to 3.00.
- Kept hi-hat, cymbal and tom balance unchanged from 8.5.8.
- The change affects Classic Rock audio preview only; MIDI generation, other genres, instrument faders and GUI remain unchanged.

## 8.5.8 — Classic Rock preview balance

- Added a Classic Rock-only preview mix: kick and snare are raised, hats are reduced, and cymbals are balanced more conservatively.
- User instrument faders remain effective and unchanged.
- Other genres, MIDI generation, velocity-layer selection, and GUI layout are unchanged.

## 8.5.7 — Preview velocity correction
- Removed the second MIDI-velocity amplitude multiplier from sample preview playback.
- The selected WAV velocity layer now provides the dynamic level; the per-instrument fader controls lane volume.
- Kept per-layer calibration, MIDI generation, and GUI unchanged.

## 8.5.6
- Calibrated all ten preview instruments independently across their four recorded velocity layers using measured layer RMS.
- Removed conservative preview attenuation; retained a 14/9/4/0 dB relative velocity contour and preserved MIDI output.
- GUI layout unchanged; corrected visible version label to 8.5.6.

# Changelog

## 8.5.5 — Four-layer drum preview bank
- Replaced the previous preview sounds with the supplied recordings for all ten drum lanes.
- Each recording is split into four consecutive velocity layers: 1–50, 51–80, 81–105, and 106–127.
- Added per-instrument preview trims while retaining the existing lane-volume controls and master compressor.
- MIDI generation and exported MIDI velocities remain unchanged.

# Genre Konverter 8.5.4 — GUI Layout & English UI Consistency

- Rebalanced the primary control row so Verse Variation has enough width in Classic Rock and Reggae layouts.
- Reduced the Repetition column to a compact width sized for the longest option, “Second Pass”.
- Kept the Verse Variation checkbox and strength selector on a clean, readable layout.
- Replaced the remaining German grid label “Takt” with “Bar” to keep the interface consistently English.
- Updated the visible GUI version tag, package version and extension manifest to 8.5.4.
- Added a command-level error boundary so unexpected dialog or Live API failures are handled locally instead of becoming unhandled promise rejections.
- No groove-generation or MIDI behavior changed.

# Genre Konverter 8.5.0 – Bridge Intelligence

- Genre-aware Bridge phrase arc with inferred Breakdown, Build-Up, Half-Time, Contrast and Transition modes.
- Drummer/genre-aware bridge dynamics while protecting Reggae and Dub style anchors.
- Dedicated First, Second and Final Pass bridge turnarounds for 2, 4 and 8 bars.
- Existing Verse, Chorus, GUI and MIDI-map behavior retained.

# Changelog

## 8.4.0 — Chorus Intelligence 2.0
- Chorus generation now uses the dedicated Reggae phrase engine for both Verse and Chorus.
- Reggae Style (One Drop, Rockers, Steppers) and Drummer selections are visible and active in Chorus.
- Chorus repetition passes add small, genre-aware rhythmic/articulation details while preserving the core groove.
- One Drop beat-1 kick prohibition is reasserted after Chorus shaping.
- Existing 2/4/8-bar chorus final-bar fills remain active; Reggae uses its matching style-specific fill grammar and drummer profile.
- GUI layout otherwise unchanged.

## 8.3.2 – MIDI Map readability correction

- Removed the redundant MIDI note-number summary below the MIDI Map selector.
- Gave MIDI Map a dedicated full-width panel with a wider selector.
- Shows the mapped drum-lane names in a readable two-row overview; no note numbers are displayed.
- Chorus generation and final-bar fill logic are unchanged from 8.3.1.

## 8.3.0 – Chorus Intelligence

- Introduces a genre-aware Chorus profile with separate treatment for Rock, Blues, Punk, Funk, Jazz, Reggae, Dub, Ska, Hip-Hop, Heavy and Breaks families.
- Adds First, Second and Final Pass behavior for the Chorus: the core groove remains recognizable while later repetitions add restrained phrase details.
- Uses 4- and 8-bar phrase landmarks for chorus openings and turnarounds; avoids a continuous crash wash.
- Supports deliberately restrained choruses in Alternative/Indie Rock, Grunge, Lo-Fi, Jazz and Dub instead of forcing every chorus to become louder and denser.
- Preserves genre-specific rhythmic vocabulary and does not alter the Verse repetition engine or the GUI layout.
- Respects locked MIDI lanes throughout the Chorus profile.

# Genre Konverter 8.2.2 — Repetition & Reggae UI Fixes

- Fixed a Reggae Repetition variation that could introduce an unrelated random note into the opening bar. Generic random groove ornaments are now disabled for Reggae; its authored groove and drummer logic remain responsible for Reggae-specific detail.
- Moved the Deep One Drop low-tom answer away from phrase bar 1 so the opening measure remains consistent across First, Second and Final Pass.
- Reworked the primary control row for Reggae Verse: Section, Reggae Style and Reggae Drummer use tighter columns, while Repetition receives more width so all pass labels are readable.
- Added regression coverage for the opening-bar stability and Reggae control layout.

# Genre Konverter 8.2.1 — Reggae Groove Intelligence

- Added dedicated One Drop, Rockers and Steppers groove banks (six to eight authored foundations per style).
- Added six Reggae drummer profiles with distinct kick/rim/hat balance, ghost-note density and timing feel.
- Added phrase-aware 4-bar development, repeated coherently across 8 bars; First/Second/Final Pass share the same base recipe and add restrained differences.
- Rebuilt Reggae fills as full-measure style-specific turnarounds; One Drop preserves the beat-3 kick/rim anchor and never receives a generic kick-on-one landing.
- Reggae-only change: all other genre engines remain unchanged.

# Changelog

## 8.2.0 — Reggae One Drop refinement
- Reggae Verse now uses a consistent One Drop foundation across 4- and 8-bar phrases.
- Removed random mixing of legacy Steppers/Rockers verse tabs from the default Reggae Verse.
- Rebuilt Reggae turnaround fills as complete, sparse measures, preserving the kick + rim/snare One Drop anchor on beat 3.
- Reggae fills avoid a forced kick/crash landing on beat 1.


- Extended automatic Verse turnaround fills from Classic Rock to every genre with Repetition passes.
- First, Second and Final Pass now all receive a genre-specific fill in the final bar of 4- and 8-bar phrases.
- Promoted automatic fills to full-measure scope, including restrained genre-appropriate lead-ins for sparse Dub, Reggae, Jazz, Hip-Hop and related grammars.
- Kept the Regenerate Fill control available so users can audition alternative fills without rebuilding the groove.

## 8.1.6
- Classic Rock Verse: automatic fill is limited to First Pass; switching to Second/Final Pass clears any manually regenerated First-Pass fill overlay. Same rule applies to 4- and 8-bar phrases (fill in the final bar on First Pass only).
- Renamed the GUI control heading to “Drummer” and aligned Bars, Section, Drummer, Repetition, BPM and MIDI Map in one primary control row.

## 8.1.0 — Songteil Intelligence: Section Identity & Energy Arc
- Added a phrase-aware energy contour for Intro, Verse, Chorus, Bridge and Outro across 2/4/8-bar clips.
- Section identity now shapes note dynamics across the phrase: restrained Verse growth, stronger Chorus plateau, Bridge build and Outro decay.
- Added a restrained late-phrase hat lift for compatible genre families; Roots, Dub, Reggae and Jazz preserve their intentional space.
- Locked lanes remain untouched by the new energy layer. Existing genre banks, fill generation and fill-overlay restoration remain in place.

## 8.0.5 — Glam Rock Fill Engine
- Replaced the repetitive quarter-note kick/snare/altSnare stomp fill with a dedicated Glam Rock phrase engine.
- Added coherent but changing Glitter-drive, Glam-hard-rock, snare-drive, tom-pickup, stop/re-entry and restrained stomp-clap figures.
- Kept short and full-bar fill families distinct; retained controlled landing accents and existing fill-scope handling.

## 8.0.2 – Dub Fill Intelligence & Version Display Fix

- Expanded Dub fill grammar from a small set of gestures to ten distinct studio-inspired concepts: rim echo, tape delay, one-drop space, bass echo, tom call, skank cut, triplet rim, dub dropout, cross-stick answer and soft pickup.
- Small fills remain scoped to the final two beats; big fills can span the full bar.
- All Dub fills retain deliberate gaps for delay/reverb and avoid forced crash or downbeat landings.
- Corrected the visible GUI version tag from the stale 7.9.6 label to 8.0.2.
- Preserved the 8.0.1 Hard Rock, Symphonic Rock and Ska section refinements, plus the existing Euclidean control and GUI layout.

## 8.0.1 – Hard Rock, Symphonic Rock & Ska section refinement

- Hard Rock: independent Verse, Chorus and Bridge groove banks; Chorus gains kick propulsion and snare variation; Bridge shifts to half-time/tom-based patterns.
- Hard Rock cymbals: one restrained crash punctuation at the start of the generated section instead of recurring crash hits.
- Symphonic Rock: independent Verse, Chorus and Bridge recipes; one crash at the start of each generated section, with ride and tom movement providing lift.
- Ska: tighter Verse, more driving Chorus with ride/offbeat support and snare answers, and a contrasting Bridge.
- GUI and Euclidean control unchanged. Classic Rock, Indie Rock, Lo-Fi, Reggae and Progressive Rock code paths were not intentionally modified.

## 7.9.9 – Fill Intelligence: Rock & Lo-Fi Grammars

- Added dedicated authored fill vocabularies for Classic Rock, Hard Rock, Symphonic Rock, Indie Rock and Lo-Fi.
- Added phrase shuffle bags per genre and fill scope to reduce immediate repetition.
- Classic Rock now uses short snare-to-tom turnarounds rather than relying mainly on generic snare rolls.
- Hard Rock uses stronger kick/snare punctuation and compact tom runs without continuous double-kick density.
- Symphonic Rock uses longer melodic tom contours and orchestral-style cymbal/ride punctuation.
- Indie Rock uses sparse, broken fills with deliberate gaps and softer landings.
- Lo-Fi uses low-velocity ghost/rim gestures, subtle timing drift and quiet ride/hat landings; no routine crash ending.
- Preserved the Progressive Rock section engine, GUI, Euclidean control and existing fill-scope behavior.
- Automated regression checks cover routing, phrase variation, density and preservation of prior behavior.

## 7.9.8 – Progressive Rock Chorus, Snare & Bridge Fixes

- Fixed missing 4/4 Progressive Rock snare: the single-group 4/4 mapping previously produced an empty backbeat list.
- Added recipe-specific, bar-rotating kick answers in Chorus so the section has a real rhythmic lift beyond velocity changes.
- Added Chorus snare answer variations and a deliberate Bridge backbeat; Bridge remains sparser but no longer loses its snare.
- Added restrained alternating Bridge tom punctuation.
- Preserved the 7.9.7 GUI dimensions and fill-scope behavior.

# Changelog

## 7.9.3 – Genre Expansion
- Added phrase-coherent, dedicated groove vocabularies for Reggae, Dub, Ska, Hip-Hop, Jungle and Drum & Bass.
- Reggae retains its existing authored one-bar tab bank and adds new Roots/Steppers/Rockers and sparse bridge/chorus choices.
- Dub emphasizes space, dropouts and restrained rim/offbeat roles rather than rock-style tom fills.
- Ska adds distinct first-/second-wave-flavored offbeat patterns and section contrasts.
- Hip-Hop separates Boom Bap, swung pocket, sparse and half-time approaches.
- Jungle and Drum & Bass receive distinct break-chop, ghost-snare, 2-step, neuro/break and half-time phrase vocabularies.
- Added audit-driven original recipe choices for Psychedelic/Progressive/Symphonic Rock, Grunge, Indie Rock, Nu Metal, Gothic Rock, Glam Rock and Lo-Fi.
- The Groove Variation control, seamless preview, fill regeneration and 2/4/8-bar limits are retained.

## 7.9.1 – Groove Control
- Removed the 16-bar phrase option; maximum phrase length is now 8 bars.
- Added a continuous Groove Variation knob (0–100%) with 20% default and double-click reset.
- Reduced chorus energy across genre families; Classic Rock chorus no longer adds crashes, open hats or kick pickups.
- Variation is applied as restrained velocity nuance and sparse low-level ornaments, preserving core kick/snare anchors.


## 7.9.2 – Fill Intelligence & Repair
- Added a genre-wide fill balancing pass: long continuous snare runs are broken up with tom hand-offs; excessive snare density is capped and very soft excess ghost notes are omitted.
- Fixed Regenerate Fill so it regenerates the selected fill scope and refreshes the sequencer without reapplying Intro/Bridge section generation over the new fill.
- Added regression coverage for snare density handling and the Regenerate Fill event path.


## 7.9.0 – Arrangement Intelligence
- Added genre-family arrangement profiles for all 25 genres, with dedicated Verse, Chorus, Bridge, Intro and Outro behavior.
- Chorus now uses genre-aware rhythmic lift, cymbal/ride choices, phrase-turn accents and restrained pickups instead of a universal velocity boost and crash on every bar.
- Added distinct Bridge vocabularies for Rock, Blues Rock, Punk, Funk, Jazz, Reggae, Dub, Ska, Hip-Hop/Rap, heavy rock and breakbeat families. Generic tom-breakdown fallback removed.
- Intro and Outro now use genre-family-specific instrumentation and endings.
- Phrase length selector now supports 2, 4, 8 and 16 bars.
- Existing genre groove generators, Funk engine, Classic Rock bank and Reggae phrase engine retained.
- Manual lane edits are no longer overwritten by a section-profile rebuild when shuffling an individual lane.

## 7.8.3 — Genre Audit
- Added a source-based audit of all 25 genres covering groove foundations, derived variations, song sections, timing, dynamics and fill coverage.
- No groove-generation logic or GUI layout changes in this audit release; only the visible version label and package metadata were updated.
- Added an Ableton Live 12.4.5 practical test plan and prioritized follow-up roadmap.

# Changelog

## 7.8.2 — Reggae Phrase Engine
- Reggae now chooses one of its 12 authored one-bar groove patterns per generation and repeats it across the full 4- or 8-bar phrase.
- Dedicated fill generation remains independent, allowing a break at the end of a 4-bar or 8-bar phrase.
- No GUI or non-Reggae genre behavior changed.

- Added 12 book-inspired Reggae groove variants and 9 Reggae break/fill variants based on the rhythmic concepts on pages 52–58 of *Drum Machine – 260 Patterns*. These are newly authored interpretations, not exact note-for-note reproductions.
- Expanded Reggae verse and fill selection banks; preserved existing GUI, clip workflow, and other genre engines.

## 7.8.0
- Fixed duplicate coincident MIDI hits at export to prevent doubled notes at phrase endings.
- Expanded Reggae and Dub groove variation banks with One Drop, Steppers/Rockers, offbeat rim/cross-stick and hat variations.
- Expanded Lo-Fi kick/snare/hat variations while preserving a laid-back, swung feel.
- Capped Jungle and Drum & Bass at 144 BPM in the UI and export path.

# Changelog

## 7.7.1 — Rename, licensing and release preparation

- Renamed the extension to **Genre Konverter** in project metadata, package naming, context-menu label, logs and documentation.
- GUI title is **Genre Converter** (English) as requested.
- Replaced the prior PolyForm Noncommercial license with a project-specific free-use license: commercial use of music created with the extension is allowed; sale or commercial redistribution of the extension itself is not allowed without written permission.
- Added clear human/AI contribution disclosure and independent third-party status.
- Replaced visible artist/song-specific groove labels with descriptive genre/groove names.
- Updated README and package version to 7.7.1.
- Automated tests and an Ableton Live in-host playback check are required before public release.

## 7.8.1 — Reggae Pattern & Break Bank
- Added 12 newly authored, book-inspired Reggae groove variants and 9 Reggae break/fill variants based on the rhythmic concepts on pages 52–58 of *Drum Machine – 260 Patterns*.
- These are style-based interpretations of the source's rhythmic ideas, not exact note-for-note reproductions.
- Preserved existing GUI, clip workflow, genre list and other genre engines.
- Updated version regression checks for 7.8.1.

## 7.9.2.1 – Human Performance Engine A: Dynamics
- Added a genre-aware velocity contour for kick, snare, hats, ride, auxiliary snare and toms.
- Added sparse, low-velocity auxiliary-snare ghost notes for genres where they fit; main backbeats remain protected.
- Dynamics are applied without moving MIDI note positions or changing the groove's core rhythmic pattern.
- Uses the existing Pocket and Groove Variation controls; no additional UI control was added.
- Kept arrangement, fill generation, Groove Variation knob and seamless preview behavior intact.

## 7.9.5 – Progressive Rock & Jazz Intelligence
- Added Progressive Rock meter selector: 4/4, 5/4, 7/8 and 9/8.
- Added explicit grouping choices: 5/4 (3+2 / 2+3), 7/8 (2+2+3 / 3+2+2), 9/8 (3+3+3 / 2+2+2+3).
- Progressive Rock uses meter-aware bar offsets, sequencer step counts, preview loop duration, MIDI note bounds and clip creation length.
- Added distinct Progressive Rock Verse, Chorus, Bridge, Intro and Outro profiles plus meter-aware phrase-ending fills.
- Added Jazz style selector: Swing, Straight Jazz and Jazz Fusion, with distinct ride pulse and comping dynamics.
- Preserved existing genre banks and Groove Variation / Regenerate Fill controls.
- Note: Ableton Live's global project time-signature setting is not changed; the generated MIDI clip length and internal pattern grid follow the selected Progressive Rock meter.

## 7.9.6 – Progressive Rock Groove Engine
- Replaced the single limited Progressive Rock base recipe with six distinct groove archetypes: Driving, Syncopated, Heavy, Flowing, Broken and Ostinato.
- Expanded 7/8 and 9/8 grouping choices and made kick/snare/hat/ride placements respond to the selected metric grouping and song section.
- Groove Variation now adds genre-specific rhythmic events (optional offbeat hats, kick syncopations, tom responses and ride accents) in addition to velocity nuance.
- Re-shuffle selects a different groove recipe where possible, avoiding an immediate repeat.
- Progressive Rock Regenerate Fill now selects among five meter-aware fill vocabularies and avoids an immediate fill repeat; it preserves the selected meter and phrase boundary.
- Jazz and other genre engines were not intentionally changed.

## 7.9.7 – GUI Space & Progressive Fill Scope
- Enlarged the extension dialog to 1240 × 820 and tightened workspace spacing.
- Removed the main-pane scrollbar; the taller dialog is intended to keep the full workspace visible.
- Fixed Progressive Rock Regenerate Fill so the 1 Bar scope replaces the complete selected meter bar.
- Added full-bar, half-bar and quarter-bar meter-aware fill scopes for Progressive Rock.
- Preserved the existing fill-scope behavior for other genres.


## 8.0.0 – Groove & Fill Refinement

- Hard Rock: stronger verse/chorus/bridge contrast through kick/snare answers and tom-led bridge movement; crash cymbals reduced to sparse punctuation.
- Symphonic Rock: crash removed as a continuous groove layer; ride, tom movement and section-specific kick/snare variation carry the arrangement.
- Lo-Fi: added restrained offbeat kick motion and low-velocity rim/ghost-note answers for more forward drive without losing its laid-back pocket.
- Reggae: expanded verse pocket choices (One Drop, steppers, rockers, four-on-the-floor and syncopated variations) and more rhythmic rim/tom answers.
- Dub: expanded fill grammar to six contrasting studio-style gestures: dropout, rim echo, kick echo, tom answer, skank and soft build.
- Ska: crash removed from verse/chorus recipe banks; open-hat offbeats and ride accents provide brightness. Ska fills now resolve on open hat rather than crash.
- Classic Rock and Indie Rock intentionally unchanged. GUI and Euclidean control unchanged.

## 8.0.4 – Fill-safe Groove Variation & Dub Pocket
- Groove Variation and its double-click reset now restore the stored fill overlay after rebuilding the groove, preserving the fill notes and velocities.
- Dub receives clearer One Drop, Steppers and Roots groove choices plus tempo-sensitive offbeat hat/rim movement below 105 BPM without changing host tempo.
- Added automated regression checks for both fixes.


## 8.1.1 — Repetition Intelligence & Grunge Section Contrast
- Added an explicit section occurrence selector: first pass, second pass, and finale.
- Added controlled repeat dynamics and phrase accents without compounding on re-shuffles.
- Authored separate Grunge Verse, Chorus, and Bridge groove vocabularies.
- Chorus opens the cymbal field and adds kick propulsion; Verse stays tighter; Bridge uses a spacious half-time shape.
- Existing fill overlay restoration and locked-lane behavior remain in place.

## 8.2.3 – Reggae Phrase Variation
- Added a dedicated Reggae Verse repetition layer with more audible Second and Final Pass note-placement changes.
- Added deterministic rhythmic signatures for all six Reggae drummer profiles.
- Preserved One Drop beat-one kick protection, Rockers/Steppers pulse identity, the existing Reggae fill engine, and the existing GUI layout.


## 8.3.1 – Chorus GUI & Final-Bar Fills
- Improved MIDI Map readability with a wider selector and a live note-number summary.
- Reduced the BPM control width while preserving tempo behavior.
- Added a genre-specific full-measure fill to the final Chorus bar for 2-, 4- and 8-bar phrases.
- Kept the existing Chorus groove, Verse logic, and overall GUI structure intact.


## 8.5.1 – Bridge Refinement & MIDI Map

- Reduced Classic Rock chorus crash cymbals to a restrained opening accent; removed repeated phrase crashes from the generated chorus.
- Added a dedicated Alternative Rock / Indie / Grunge bridge vocabulary to distinguish the Bridge more clearly from the Verse.
- Restored Reggae Style and Drummer selectors for Bridge and added style-aware One Drop, Rockers and Steppers bridge patterns with drummer-specific articulation.
- Expanded MIDI Map overview to show instrument, note name and MIDI note number for every lane.
- EZdrummer 3 values follow Toontrack's published Main Room map for core articulations. Battery 4 and Kontakt 8 are clearly identified as editable GM starting templates, not universal factory maps. Drumlogue is labelled with its MULTI-mode per-part MIDI-channel caveat; displayed GM values are a compatibility fallback.


## 8.5.2 – Alternative Rock Verse/Bridge Contrast

- Added a dedicated Alternative Rock Verse groove: steady eighth-note hat pulse, clear backbeat and restrained syncopated kick variations.
- Added a contrasting Bridge vocabulary: half-time snare placement, sparser cymbal pulse, different kick placement and restrained tom punctuation.
- Kept the Verse stable across bars while the Bridge gains a small phrase-end lift.
- No GUI changes; Classic Rock, Reggae, Funk, Hip-Hop and all other genre engines remain on their existing paths.


## 8.5.3 – Intelligent Verse Variation

- Added an optional **Verse Variation** control for developing Verse 1, Verse 2 and Final Verse.
- First Pass remains the reference groove; Second Pass adds restrained, genre-aware phrase details.
- Final Pass introduces a slightly stronger phrase development without turning the Verse into a fill or pre-empting the Chorus.
- Added Subtle, Balanced and Expressive variation strengths.
- Locked instrument lanes remain untouched; disabling the option retains the previous repetition behavior.
- Updated the lower-left GUI version label to **Version 8.5.3**.

## 8.7.6
- Fixed New Take Each Loop for Verse playback: the pass advances at the phrase loop boundary from First to Second to Final and remains on Final for subsequent loops.
- Kept the Repetition selector synchronized with automatic pass changes; a fresh preview run starts from First Pass when automatic loop variation is enabled.
- Added drummer-aware Classic Rock closed-hi-hat phrasing that combines the eighth-note pulse with restrained sixteenth-note additions and deliberate eighth-note omissions.
- Preserved the existing Classic Rock drummer profiles, core groove, preview audio engine, sample assets, and other genre engines.


## 8.9.6
- Added Amen Break Funk as a fifth Funk Drummer profile.
- Added a 12-bar Verse / Chorus / Bridge arrangement with the supplied breakbeat accents, ghost-note roll, chorus ride lift, and bridge snare cascades.
- Preserved intentional layered kick/hat/snare hits; Amen Break is not forced into Jazz-Funk's linear voice-allocation rule.
- Existing Funk profiles and the Linear Funk Verse tom-free behavior remain unchanged.


## 8.9.9
- Added **The Military-Punk Roll** as a second selectable Punk Drummer profile.
- Verse: steady eighth-note hi-hat, marching snare rudiments with accented backbeats, and a firm kick foundation; the final bar opens into a short snare roll.
- Chorus: quarter-note ride/cymbal drive, emphatic snare backbeats, a broad syncopated kick pattern, and a restrained final-bar snare fill.
- Bridge: cymbal-free high-/floor-tom pulse with strong snare accents; the final bar adds a short tom/snare roll and four-quarter kick march back into the Verse.
- First, Second and Final Pass retain the same core groove, with only restrained dynamic and phrase-end development. The selected drummer is included in the generated MIDI clip name.
- The existing 77er UK Ska-Drop profile, other genre engines, audio preview and original samples remain unchanged.


## 8.9.26
- Nutty Sound Re-shuffle now advances through four distinct groove treatments across the full selected section, while respecting lane locks and the section ending.
- Nutty Sound Regenerate Fill now cycles through four different fill recipes for each pass; fill scope and intensity remain active.
- Nutty Sound now receives the same Groove Variation processing in its specialized generator path.
- Added regression coverage for Nutty Sound shuffle and fill controls.


## 8.9.27 — Power-Ska Drummer
- Added Power-Ska at 175 BPM with 77er-Punk energy, offbeat Verse snare, dense ride-led Chorus and Half-Time Bridge.
- Added 2/4/8-bar generation, second-phrase variation, Second/Final Pass development, Re-shuffle, Groove Variation and dedicated Regenerate Fill recipes.
- Removed the redundant disabled “DanceBEATZ · in Entwicklung” menu entry; the released DanceBEATZ profile remains available.

## 9.1.0 — Groove Intelligence

- Added explicit genre-specific performance fingerprints for all 25 selectable genres.
- Reworked the shared Pocket/Swing performance transform: genre-specific kick, snare, hat and ride microtiming; bounded per-lane/per-bar pocket; deterministic event nuance; controlled velocity accents.
- Kept Pocket=0 timing quantized (apart from the explicit Swing control).
- Removed large, uncorrelated random timing/velocity swings from the final preview/MIDI transform.
- Applied the same transform to preview playback and exported MIDI so both represent the same performance feel.
- Added subtle section/pass awareness while preserving each genre's authored rhythmic vocabulary.
- Preserved all 9.0.2 Jazz Chorus/Bridge content and all other genre engines.

## 9.1.1 — Jungle Break Intelligence
- Set Jungle's default tempo to 160 BPM and raised its genre-specific BPM ceiling from 144 to 160. Drum & Bass retains its separate 144 BPM ceiling.
- Added a dedicated Jungle section engine: Verse break foundation, denser syncopated Chorus/Drop, and sparse half-time Bridge.
- Added Amen-inspired kick displacement, accented backbeat snares, low-velocity ghost-note layers, open-hat punctuation, and pass-aware phrase development.
- Added short 32nd-note snare rushes at the end of later Drop/Bridge passes. Pitch automation is not generated; pitch movement remains instrument/sample dependent.
- Separated Jungle's velocity treatment from the shared Drum & Bass/Breakbeat branch.
- Preserved the other genre engines, lane locks, section processing, preview/MIDI performance transform, and all prior regression coverage.

## 9.1.2 — Jungle Break Reconstruction
- Rebuilt Jungle Verse, Chorus/Drop and Bridge as four-bar break phrases.
- Removed constant eighth-note hats and continuous straight rolls.
- Added phrase-aware ghost-note edits, selective omissions and restrained pass evolution.
- Preserved Jungle-specific Verse/Chorus/Bridge phrasing from generic section overrides.
- Kept Jungle BPM default/cap at 160 and Drum & Bass cap at 144.

## 9.1.4 — Jungle Sequencer Repair
- Fixed the Jungle generator's `phraseBar` scope error: the lane insertion helper now receives the current phrase-bar index explicitly.
- Prevented the Jungle groove generation from aborting after the sequencer had been cleared during Re-shuffle or initial generation.
- Added executable regression coverage for Verse, Chorus and Bridge at 2, 4 and 8 bars, across First, Second and Final Pass.
- Kept the Jungle tempo at 144 BPM and preserved the existing Jungle groove/fill design and all non-Jungle engines.
- Updated the visible GUI version label and release metadata to 9.1.4.

## 9.3.4 — Expanded GUI / Full Sequencer View
- Enlarged the Ableton modal from 1240×820 to 1500×1000 to provide substantially more workspace.
- Restored a fully visible, non-scrollable sequencer grid; the sequencer no longer enters scroll mode.
- Kept the footer as a non-shrinking action row with Create MIDI Clip, Cancel, Re-shuffle, Regenerate Fill, Undo and Redo.
- Added a regression test for dialog dimensions, non-scrolling sequencer, footer and action controls.
- Retains the 9.3.2 non-destructive Song Arc correction.
