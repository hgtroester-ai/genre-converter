# Genre Konverter 9.1.0 — Groove Intelligence Audit

**Baseline:** 9.0.2  
**Scope:** Genre-aware performance feel shared by preview playback and exported MIDI.  
**Preservation goal:** retain authored groove vocabulary, genre/drummer engines, song sections, passes, fills, lane locks, MIDI maps and the Jazz completion from 9.0.2.

## 1. What changed

9.1.0 introduces an explicit performance fingerprint for every selectable genre. The fingerprints describe restrained timing tendencies for kick, snare/ghost voices, hats and ride, plus a bounded velocity nuance range. The layer does not add notes and does not replace any authored groove or genre generator.

The 25 profiles are defined in `src/ui.ts` as `GROOVE_INTELLIGENCE_PROFILES`:

- Classic Rock, Hard Rock, Blues Rock, Psychedelic Rock, Progressive Rock, Symphonic Rock
- Punk Rock, Pop Punk, Grunge, Alternative Rock, Indie Rock, Nu Metal
- Gothic Rock, Glam Rock, Funk, Reggae, Ska, Jazz
- Hip-Hop, Rap, Dub, Breakbeat, Jungle, Drum & Bass, Lo-Fi

## 2. Performance behavior

### Genre-specific micro-timing

- Kick, snare/ghost voices, hats and ride receive separate timing tendencies.
- Positive offsets sit slightly behind the beat; negative offsets sit slightly ahead.
- At Pocket 100%, the profile component remains restrained. Including the stable lane/bar and event nuance, the additional pocket timing is approximately within 0.044 beats in the most expressive section/pass context (about 22 ms at 120 BPM).
- Pocket 0 keeps timing quantized apart from the user's explicit Swing setting.
- Existing genre swing-grid behavior (8th or 16th) remains active.

### Stable pocket

The former uncorrelated random timing drift was replaced in the final performance transform with a small deterministic hash-based lane/bar bias and event nuance. The same note at the same beat in the same genre receives the same performance treatment, making preview and MIDI export consistent.

### Velocity intelligence

- Genre-specific velocity nuance is bounded to a small range (3–7 profile points).
- Main kick/snare anchors receive restrained support; hats/ride receive modest pulse accents; alternate snare voices remain slightly behind the main snare.
- Existing generated velocities, ghost-note treatment and Human Performance dynamics remain in place.

### Section and pass awareness

Chorus and Bridge receive a small expressive timing multiplier. Second and Final Pass receive a subtle increase over First Pass. This changes performance feel only; it does not rewrite the authored note vocabulary or introduce generic ornaments.

## 3. Shared output path

Both preview scheduling and MIDI clip creation call the same `applyPocketSwing(laneKey, beatTime, velocity)` transform. Therefore, the MIDI written into Live carries the same genre-aware timing and velocity treatment heard in the preview, subject to the same Pocket and Swing settings.

## 4. Preserved from 9.0.2

- 25 selectable genre definitions and all authored/generated tab banks.
- Jazz: 8 dedicated Chorus grooves and 7 dedicated Bridge grooves.
- Funk, Reggae, Punk, Ska, Jamaican First Wave and all specialized drummer profiles.
- First / Second / Final Pass, 2/4/8-bar phrases, fills, Re-shuffle, lane locks and MIDI maps.
- Existing preview sample engine, velocity layers, lane mix and clip-target behavior.

## 5. Verification

- `npm run test:verify`: **95 of 95** test scripts passed; 95 unique commands, no duplicates, no missing test files.
- Added `tests/verify-groove-intelligence-910.mjs` to validate all 25 profiles, bounded offsets, deterministic processing, retained Swing/Pocket controls, and the shared preview/MIDI transform.
- `npm run build:portable`: PASS.
- `node --check dist/extension.js`: PASS.
- ABLX ZIP integrity: PASS.
- Source ZIP integrity: PASS.
- Release metadata in `package.json`, `manifest.json`, GUI version tag and embedded ABLX manifest: 9.1.0.

## 6. Practical listening checklist

Please compare the same kit and tempo in Live, particularly:

1. Funk: laid-back snare, forward kick, quiet ghost-note articulation.
2. Jazz: ride pulse and relaxed comping without a rock backbeat.
3. Reggae / Dub: steady One Drop space and clean offbeat placement.
4. Punk / Pop Punk: tight, direct drive without excessive looseness.
5. Hip-Hop / Lo-Fi: deep pocket and restrained, non-mechanical hat accents.
6. Classic Rock / Blues Rock: stable backbeat versus shuffle feel.

Automated tests validate code paths, profile coverage, metadata and package integrity. They do not establish an actual Ableton Live launch or listening test; no in-host test is claimed.
