# Genre Konverter Free Music Creator License (Draft 1.0)

Copyright © 2026 Hans-Georg Tröster (HGT). All rights reserved except for the permissions expressly granted below.

This is a project-specific license, not an OSI-approved open-source license.

## 1. Permission to use

You may download and use Genre Konverter free of charge to create, edit, arrange, record, distribute, perform, publish, and monetize your own music, including music made for clients or released commercially. This permission applies to musical output created with the software; it does not transfer ownership of the software.

## 2. Software may not be sold or commercially redistributed

Without prior written permission from the copyright holder, you may not: (a) sell or rent the software; (b) charge a fee for access to or distribution of the software; (c) bundle or redistribute the software as a paid product or paid feature; or (d) commercially distribute modified or derivative versions of the software.

## 3. Free sharing of the original release

You may share an unmodified copy of the original software free of charge, provided that you include this license and all copyright and third-party notices, do not misrepresent the origin of the software, and do not imply endorsement by the copyright holder or Ableton. You may link to the official project download instead.

## 4. Modifications

You may modify a copy for your own private use. You may not publicly distribute modified versions without prior written permission from the copyright holder. Nothing in this license grants exclusive rights over general musical ideas, techniques, or functionality that are not protected by applicable law.

## 5. Names, trademarks and attribution

“Genre Konverter” and “Genre Converter” identify this project. This license does not grant trademark rights. Ableton, Ableton Live, and other third-party names are the property of their respective owners and are used only where necessary to identify compatibility or third-party components.

## 6. Third-party components

Third-party components remain subject to their own licenses. If a third-party license conflicts with this license, the third-party license governs that component. This license does not relicense the Ableton Extensions SDK or any other third-party material.

## 7. Copyright and contribution disclosure

Concept, musical requirements, GUI planning and testing: Hans-Georg Tröster. Software development and technical implementation were created with assistance from ChatGPT, an AI assistant by OpenAI. This statement is a contribution disclosure and does not claim that the AI is a legal person or copyright holder.

## 8. Disclaimer

The software is provided “as is”, to the maximum extent permitted by applicable law. No warranty is given that it will be error-free or suitable for a particular purpose. Nothing in this license excludes liability that cannot lawfully be excluded.

## 9. Governing law and rights

Mandatory rights under applicable law remain unaffected. If you need permission for a use not expressly allowed here, contact the copyright holder and obtain written permission before that use.

---

**Release note:** This is a tailored license draft for this project. It is deliberately not presented as an open-source license. Check third-party license obligations before public distribution.
