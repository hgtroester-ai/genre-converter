# Pass Intelligence Audit – 9.4.0

## Scope
Adds a deterministic, bounded First / Second / Final Pass development layer across song sections, with genre-specific lane eligibility.

## Musical rules
- First Pass is the reference pattern and receives no pass-layer edits.
- Second Pass permits at most two optional colour events; Final Pass at most three.
- Genre rules cover all 25 supported genres and define eligible hats, open hats, ride, crash, tom and ghost-note lanes.
- Open and closed hi-hat events are never added at the same beat.
- Main kick and snare anchors are not modified by this new pass layer.
- Crash punctuation is limited to one phrase accent, not repeated on every bar.
- Locked lanes are respected.
- Fill section is excluded; Regenerate Fill remains independent.
- Pass layer starts from the immutable Song Arc base pattern, so reapplying it does not accumulate events.

## Validation
- Portable `.ablx` build succeeded.
- Full `npm run test:verify` suite passed, including the new `verify-pass-intelligence-940.mjs`.
- Archive integrity checked for both release artifacts.
- Manual Ableton Live host testing was not performed in this environment.
