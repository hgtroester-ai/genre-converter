# Genre Konverter 9.1.1 — Jungle Break Intelligence Audit

## Scope
This release continues from 9.1.0. The change is intentionally focused on Jungle; other genre engines and the existing Groove Intelligence transform are retained.

## Tempo
- Jungle default BPM: **160**.
- Jungle genre-specific maximum: **160 BPM**.
- Drum & Bass remains independently capped at **144 BPM** in this build.

## Musical behavior
- **Verse:** break foundation with a clear snare anchor, displaced kick placements, steady sixteenth-note hat articulation, and low-velocity ghost-note answers.
- **Chorus / Drop:** denser syncopated kick/snare chopping, offbeat snare accents, ghost-note chains, and a short 32nd-note snare burst in later passes.
- **Bridge:** sparse half-time snare anchor, reduced kick activity, more open-hat space, and a short 32nd-note rush into the next section in later passes.
- **Pass development:** First Pass establishes the phrase; Second/Final passes add restrained ghost-note and roll details rather than replacing the whole groove.
- **Lane locks:** all generated Jungle voices and roll events respect their corresponding lane lock.
- **Pitch movement:** no pitch automation is fabricated. A pitched snare roll requires instrument/sample support or separate automation in Live.

The patterns are original Amen-inspired style interpretations, not note-for-note transcriptions or samples from the original recording.

## Validation
- `npm run test:verify`: all configured regression checks passed, including the new Jungle 9.1.1 test.
- `npm run build:portable`: passed.
- JavaScript syntax check: passed.
- ABLX archive integrity: checked with `unzip -t`.
- Source ZIP integrity: checked with `unzip -t`.
- Package, manifest, embedded manifest, and GUI version: 9.1.1.

No Ableton Live launch or listening test was performed in this build environment. Please audition Jungle at 160 BPM in Live, particularly Verse → Drop → Bridge transitions and the 32nd-note rushes.
