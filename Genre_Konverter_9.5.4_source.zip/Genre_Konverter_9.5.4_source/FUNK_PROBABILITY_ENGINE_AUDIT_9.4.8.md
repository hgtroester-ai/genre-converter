# Funk Probability Engine — 9.4.8

## Purpose
Add controlled, drummer-specific optional events to the existing authored Funk groove skeleton. The layer is intentionally additive and does not replace the five established drummer engines.

## Behavior
- Ghost Note Funk: additional low-velocity alt-snare ghosts around the backbeat, restrained kick syncopations, and sparse closed-hat 16th pickups.
- New Orleans Funk: denser ghost vocabulary and a slightly stronger syncopated-kick profile.
- Jazz Funk: lighter ghost density, more open kick phrasing, and optional hat pickups.
- Amen Break Funk: break-oriented kick/ghost candidates and more active hat subdivisions.
- Linear Funk: excluded from layered additions to preserve its single-voice orchestration.

## Probability model
Groove Variation scales the optional-event probabilities. Ghost-note chance is bounded at 50%, additional kick chance at 70%, and closed-hat pickup chance at 36%. Per-bar caps limit the engine to two added ghosts, one added kick, and two added closed-hat events. The authored backbeat and existing groove anchors are not removed.

## Determinism
A small seeded pseudo-random stream is initialized for each explicit Funk generation. Decisions within a generated take are reproducible; subsequent Generate / Reshuffle / New Take operations advance the generation seed and can produce a different controlled variation.

## Safety and compatibility
- 0% Groove Variation leaves the authored Funk pattern unchanged by this layer.
- Fill sections are excluded.
- Locked lanes are respected.
- No GUI controls or dimensions changed.
- No MIDI map, audio preview, scheduler, or sample code changed.
- Existing Funk phrase, section, and fill engines remain in place.

## Verification
- Full `npm run test:verify` suite passed.
- Dedicated `verify-funk-probability-engine-948.mjs` passed.
- Audio preview engine source hash remains identical to the 9.4.3 baseline.
- Ableton-host audition remains a user-side musical check; automated tests do not establish audible quality.
