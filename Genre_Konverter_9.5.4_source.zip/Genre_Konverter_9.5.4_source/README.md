# Genre Konverter 9.5.2
Song Intelligence Refinement: Song Arc energy, drummer touch and Next Section transitions are composed in one bounded pass. The Web Audio preview engine remains byte-identical to 9.4.8.
Song Intelligence Refinement release. Song Arc, genre/drummer touch and Next Section now share one non-compounding velocity pass. Existing groove patterns, MIDI note vocabulary, GUI layout and Audio Engine are preserved.

## Song Dramaturgy 9.2.0

- Four musical arc presets: Classic Build, Slow Burn, Drop & Return, and Cinematic Rise.
- Each preset defines a four-point energy curve for Intro, Verse, Chorus, Bridge and Outro; the curve is smoothly interpolated across 2-, 4- and 8-bar sections.
- Dramaturgy Strength blends the selected arc with the established section-energy behavior, from 0% (legacy behavior) to 100% (full selected arc).
- Next Section can be Auto or explicitly set to Verse, Chorus, Bridge, Outro or Song End.
- Transition shaping is non-destructive: it changes only existing notes in the final bar, adds no MIDI events, and respects lane locks.
- Song Arc, strength and next-section preferences are retained in the extension settings.
- A universal generation wrapper applies transition shaping after each genre-specific generator path, including specialized Jungle/Funk/Reggae/Ska engines.

## Preserved

- All 25 genres, specialist banks, drummer profiles and Jungle 9.1.4 runtime repair.
- First / Second / Final Pass, fills, lane locks, MIDI maps, preview engine and existing groove controls.

## Verification

- `npm run test:verify` runs all 105 verification scripts.
- `npm run build:portable` creates the installable Ableton extension.
- The release checks include bundle syntax, metadata consistency, Song Arc interpolation, transition behavior and lane-lock protection.
- No Ableton Live in-host launch or listening test is claimed; please audition the results in Live.

### Previous Groove Intelligence release (9.1.0)

Groove Intelligence release. This version adds a genre-specific performance layer to the existing groove engines, connecting micro-timing, pocket, swing and velocity nuance while preserving authored rhythm patterns and all existing genre/drummer engines.

## Groove Intelligence

- Explicit performance fingerprints for all 25 selectable genres.
- Genre-specific timing feel for kick, snare/ghost voices, hats and ride.
- Stable, bounded per-lane/per-bar timing nuance; no uncontrolled random timing drift.
- Pocket controls the amount of human looseness; Pocket at 0 keeps timing quantized apart from the explicit Swing setting.
- Swing remains active and follows each genre's existing 8th- or 16th-note swing grid.
- Small genre-aware velocity accents preserve anchor hits, ghost-note hierarchy and cymbal articulation.
- Preview playback and exported MIDI share the same performance transform, so the generated MIDI reflects what the preview plays.
- Chorus, Bridge and pass context subtly shape the performance without changing the authored note vocabulary.

## Preserved

- All 25 genres and their existing pattern banks.
- Jazz 9.0.2 Chorus and Bridge completion.
- First / Second / Final Pass, fills, lane locks, groove variation, drummer profiles and MIDI maps.
- Existing Pocket and Swing controls and the preview engine.

## Verification

- `npm run test:verify` runs all 105 verification scripts.
- `npm run build:portable` creates the installable Ableton extension.
- The release checks include bundle syntax, metadata consistency and ABLX/source ZIP integrity.
- No Ableton Live in-host launch or listening test is claimed; please audition the results in Live.

### Jungle (9.1.1)
Jungle now starts at 144 BPM (genre ceiling: 144 BPM) and uses a dedicated break-oriented Verse, Chorus/Drop, and half-time Bridge engine. It adds Amen-inspired syncopated kick placement, accented snares, low-velocity ghost notes, open-hat punctuation, pass-aware edits, and short 32nd-note snare rushes. Drum & Bass remains a separate engine and retains its own tempo ceiling.


## Version 9.3.8 — Song Arc Non-Destructive Correction
A compact overview displays the blended energy levels for Intro, Verse, Chorus, Bridge and Outro. The selected section is highlighted. This is a visual-only refinement; the existing 9.2.0 MIDI dramaturgy engine remains unchanged.


### 9.3.8 Fehlerkorrektur
- Song-Arc-Preset, Strength und Next Section aktualisieren den vorhandenen Groove ohne vollständige Neugenerierung.
- Song Arc verändert ausschließlich Velocity-Werte vorhandener MIDI-Noten; Notenanzahl, Positionen und Groove-Auswahl bleiben erhalten.
- Wiederholte Änderungen werden stets vom unveränderten generierten Groove abgeleitet und addieren sich nicht aufeinander.
- Genre-/Drummer-spezifische Groove-Generierung und Re-Shuffle bleiben davon getrennt.

## Version 9.3.8 — Expanded GUI
The Ableton dialog is enlarged to 1500×1000. The sequencer remains fully visible without a scroll mode; the complete lower action bar stays in view. The 9.3.2 non-destructive Song Arc correction is retained.
