# GUI Repair Audit – 9.4.1

## User-reported issue
In Ableton Live the 9.4.0 modal displayed its transport controls and footer, but the genre list and ten-lane sequencer area appeared empty. The decorative drum-kit banner was also too prominent.

## Changes
- Explicit fixed flex basis, height and minimum height for every lane row.
- Explicit ruler height and stacking order.
- Explicit grid stacking order.
- Reduced banner opacity from 0.12 to 0.035.
- Kept the sequencer non-scrolling and preserved all ten lanes.
- Bumped release metadata and GUI version to 9.4.1.

## Verification
- Full existing automated verification suite passed before the CSS-only repair.
- Portable build and package verification are required after this patch.
- Manual Ableton Live verification remains necessary; not performed in this environment.
