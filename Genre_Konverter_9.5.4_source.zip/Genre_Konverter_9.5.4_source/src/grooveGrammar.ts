// Coordinated whole-groove recipes for genre-specific generation.
// Each recipe is a complete one-bar relationship between lanes, using 16th-note
// step indices 0..15. This prevents independent per-lane random choices from
// accidentally combining unrelated kick, snare and hat variations.
export type GrooveRecipe = {
  kick?: number[]; snare?: number[]; altSnare?: number[];
  midTom?: number[]; lowTom?: number[]; closedHat?: number[];
  openHat?: number[]; hiTom?: number[]; crash?: number[]; ride?: number[];
};
const r = (kick: number[], snare: number[], closedHat: number[], extra: GrooveRecipe = {}): GrooveRecipe => ({ kick, snare, closedHat, ...extra });
const eighths = [0,2,4,6,8,10,12,14];
const sixteenths = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];
const quarters = [0,4,8,12];

export const GROOVE_GRAMMAR: Record<string, GrooveRecipe[]> = {
  hardRock: [
    r([0,6,8,14],[4,12],eighths,{openHat:[14]}),
    r([0,4,8,10,14],[4,12],eighths,{openHat:[6,14],altSnare:[11]}),
    r([0,3,8,11,14],[4,12],eighths,{midTom:[7,15],openHat:[14]}),
    r([0,4,8,12],[4,12],eighths,{ride:[0,4,8,12],openHat:[6,14]}),
    r([0,6,8,10,14],[4,12],eighths,{openHat:[2,14],altSnare:[11]}),
    r([0,2,8,10,12],[4,12],eighths,{ride:[2,6,10,14],openHat:[6,14]}),
    r([0,4,8,10,12,14],[4,12],eighths,{openHat:[14]}),
    r([0,2,8,10,14],[4,12],eighths,{ride:[0,4,8,12],openHat:[2,6,10,14]})
  ],
  bluesRock: [
    r([0,8],[4,12],eighths,{ride:eighths,altSnare:[3,7,11,15],openHat:[6,14]}),
    r([0,6,8,14],[4,12],eighths,{ride:eighths,altSnare:[3,11],openHat:[14]}),
    r([0,8,10],[4,12],eighths,{ride:[0,2,4,6,8,10,12,14],altSnare:[2,7,10,15],midTom:[14]})
  ],
  psychRock: [
    r([0,7,10],[4,12],eighths,{openHat:[2,10],hiTom:[3,7,11,15],lowTom:[14]}),
    r([0,6,8,13],[4,12],eighths,{openHat:[6,14],hiTom:[2,3,6,7,10,11,14,15],crash:[0]}),
    r([0,8,11],[4,12],quarters,{altSnare:[7,15],midTom:[6,14],lowTom:[10,15],crash:[0,8]})
  ],
  progRock: [
    r([0,3,8,11],[4,12],sixteenths,{altSnare:[7,15],hiTom:[3,11],crash:[0]}),
    r([0,6,9,14],[4,12],sixteenths,{openHat:[6,14],midTom:[7,15],crash:[0,8]}),
    r([0,5,8,10,15],[4,12],eighths,{altSnare:[3,7,11,15],hiTom:[3,7,11,15],lowTom:[14],crash:[0]})
  ],
  symphonicRock: [
    r([0,8],[4,12],quarters,{ride:[2,6,10,14],lowTom:[0,8]}),
    r([0,4,8,12],[4,12],eighths,{ride:[2,6,10,14],midTom:[8]}),
    r([0,8,10],[4,12],quarters,{ride:eighths,hiTom:[0,8],lowTom:[12]})
  ],
  punkRock: [
    r([0,2,4,6,8,10,12,14],[4,12],eighths,{crash:[0],openHat:[2,6,10,14]}),
    r([0,4,8,12],[4,12],eighths,{crash:[0,8],openHat:[6,14]}),
    r([0,2,6,8,10,14],[4,12],eighths,{crash:[0],altSnare:[7,15],openHat:[2,6,10,14]}),
    r([0,4,8,12],[4,12],eighths,{crash:[0,8],openHat:[6,14]}),
    r([0,2,4,8,10,12,14],[4,12],eighths,{crash:[0],openHat:[2,6,10,14]}),
    r([0,6,8,14],[4,12],eighths,{crash:[0,12],openHat:[14]}),
    r([0,4,6,8,10,12],[4,12],eighths,{crash:[0,8],openHat:[2,10,14]}),
    r([0,2,8,10,12,14],[4,12],eighths,{crash:[0],openHat:[6,14]})
  ],
  popPunk: [
    r([0,4,8,10,12],[4,12],eighths,{crash:[0,8],openHat:[2,6,10,14]}),
    r([0,4,8,12],[4,12],eighths,{crash:[0],openHat:[6,14]}),
    r([0,2,4,8,10,12,14],[4,12],eighths,{crash:[0,8],openHat:[2,6,10,14],altSnare:[11]})
  ],
  grunge: [
    r([0,8,10],[8],quarters,{crash:[0],openHat:[6,14],lowTom:[14]}),
    r([0,6,8],[8],[0,2,4,6,8,10,12,14],{crash:[0,8],midTom:[7,15]}),
    r([0,8,11],[4,12],quarters,{crash:[0],openHat:[2,10],altSnare:[7,15],lowTom:[14]})
  ],
  altRock: [
    r([0,8],[4,12],eighths,{openHat:[6,14]}),
    r([0,6,8,14],[4,12],eighths,{openHat:[2,10],altSnare:[7,15]}),
    r([0,4,8],[4,12],quarters,{crash:[0,8],openHat:[6,14],midTom:[15]}),
    r([0,6,8,14],[4,12],eighths,{crash:[0],openHat:[2,10]}),
    r([0,4,8,10,14],[4,12],eighths,{crash:[0,8],openHat:[6,14]}),
    r([0,8,12],[4,12],quarters,{crash:[0],openHat:[2,6,10,14]}),
    r([0,2,8,10],[4,12],eighths,{crash:[0,12],openHat:[6,14]}),
    r([0,4,6,8,12],[4,12],eighths,{crash:[0,8],openHat:[2,14]})
  ],
  indieRock: [
    r([0,4,8,12],[4,12],quarters,{openHat:[6,14]}),
    r([0,6,8,14],[4,12],eighths,{openHat:[2,10],altSnare:[7,15]}),
    r([0,8],[4,12],quarters,{crash:[0],openHat:[6,14],ride:[2,10]})
  ],
  nuMetal: [
    r([0,3,8,10,14],[8],sixteenths,{altSnare:[7,15],crash:[0]}),
    r([0,6,8,11,14],[8],eighths,{altSnare:[3,7,11,15],openHat:[6,14],crash:[0,8]}),
    r([0,2,7,8,13],[4,12],sixteenths,{altSnare:[3,11],lowTom:[14],crash:[0]})
  ],
  gothicRock: [
    r([0,8],[4,12],quarters,{ride:[0,4,8,12],lowTom:[8]}),
    r([0,4,8,12],[4,12],eighths,{ride:[0,4,8,12],crash:[0],midTom:[14]}),
    r([0,8,10],[4,12],quarters,{ride:eighths,lowTom:[7,15],crash:[0,8]})
  ],
  glamRock: [
    r([0,8],[4,12],eighths,{crash:[0],openHat:[6,14]}),
    r([0,4,8,12],[4,12],eighths,{crash:[0,8],openHat:[2,6,10,14]}),
    r([0,8,10],[4,12],quarters,{crash:[0],openHat:[6,14],midTom:[15]})
  ],
  reggae: [
    r([8],[],[0,2,4,6,8,10,12,14],{altSnare:[8],openHat:[6,14]}), // One Drop
    r([0,8],[],[0,2,4,6,8,10,12,14],{altSnare:[8],ride:[2,6,10,14]}), // Roots steppers
    r([0,6,8,14],[4,12],[0,2,4,6,8,10,12,14],{altSnare:[8],openHat:[6,14]}), // Rockers
    r([0,4,8,12],[4,12],[0,2,4,6,8,10,12,14],{altSnare:[8],ride:[0,4,8,12]}), // Four-on-floor
    r([8,12,14],[],[0,2,4,6,8,10,12,14],{altSnare:[4,8],openHat:[14]}), // syncopated roots
    r([0,5,8,13],[4,12],[0,2,4,6,8,10,12,14],{altSnare:[7,15],ride:[2,6,10,14]}) // skanking variation
  ],
  ska: [
    r([0,8],[4,12],[2,6,10,14],{openHat:[2,6,10,14]}),
    r([0,4,8,12],[4,12],eighths,{openHat:[2,6,10,14],ride:[0,8]}),
    r([0,8,10],[4,12],[0,2,4,6,8,10,12,14],{openHat:[2,6,10,14],altSnare:[7,15]})
  ],
  jazz: [
    r([0,4,8,12],[3,10,14],eighths,{ride:eighths,altSnare:[3,7,11,15]}),
    r([0,8],[2,7,10,15],eighths,{ride:eighths,altSnare:[3,11],closedHat:[4,12]}),
    r([0,4,8,12],[4,12],eighths,{ride:eighths,altSnare:[2,6,10,14],closedHat:[4,12]})
  ],
  hiphop: [
    r([0,7,10],[4,12],eighths,{altSnare:[3,11,15]}),
    r([0,6,10,14],[4,12],[0,2,4,6,8,10,12,14],{altSnare:[3,7,11,15],openHat:[14]}),
    r([0,8,11],[4,12],quarters,{altSnare:[7,15],openHat:[6,14]})
  ],
  rap: [
    r([0,6,10,13],[8],sixteenths,{altSnare:[7,15],openHat:[6,14]}),
    r([0,4,8,11,14],[8],sixteenths,{altSnare:[3,7,11,15],openHat:[6,14]}),
    r([0,7,10,15],[8],[0,2,4,6,8,10,12,14],{altSnare:[7,15],openHat:[2,14]})
  ],
  dub: [
    r([8],[],[2,6,10,14],{altSnare:[8],openHat:[14]}),
    r([0,8],[],[0,2,4,6,8,10,12,14],{altSnare:[8],openHat:[6,14]}),
    r([8,14],[4,12],[2,6,10,14],{altSnare:[8],openHat:[14],lowTom:[15]})
  ],
  breakbeat: [
    r([0,3,7,10],[4,11,12],eighths,{altSnare:[7,15]}),
    r([0,6,8,11,14],[4,12],sixteenths,{altSnare:[3,7,15],openHat:[6,14]}),
    r([0,3,8,10,15],[4,12],eighths,{altSnare:[7,11,15],crash:[0]})
  ],
  jungle: [
    r([0,3,6,10,14],[4,12],sixteenths,{altSnare:[7,11,15],openHat:[14]}),
    r([0,2,7,10,13],[4,12],sixteenths,{altSnare:[3,7,11,15],openHat:[6,14]}),
    r([0,5,8,11,14],[4,12],eighths,{altSnare:[7,15],midTom:[14]})
  ],
  drumAndBass: [
    r([0,6,10],[4,12],sixteenths,{altSnare:[7,15],openHat:[14]}),
    r([0,3,8,10,14],[4,12],sixteenths,{altSnare:[3,7,11,15],openHat:[6,14]}),
    r([0,6,9,11,14],[4,12],eighths,{altSnare:[7,15],openHat:[2,14],crash:[0]})
  ],
  lofi: [
    r([0,8],[4,12],[0,4,8,12],{altSnare:[3,11],ride:[6,14]}),
    r([0,7,10],[8],[0,2,4,6,8,10,12,14],{altSnare:[3,15],openHat:[14]}),
    r([0,8,11],[4,12],[0,4,8,12],{altSnare:[7,15],ride:[2,10],openHat:[14]})
  ]
};

// v7.6.1: expand each authored groove family with controlled, style-safe
// variations. Backbeat/snare placement is preserved; variations come from
// kick pickups and cymbal/hat punctuation rather than random lane replacement.
const sortedUnique = (steps: number[]) => Array.from(new Set(steps)).sort((a, b) => a - b);
const KICK_PICKUPS = [[], [2], [6], [10], [14], [2, 10], [6, 14], [2, 14], [6, 10], [2, 6], [10, 14], [2, 6, 14]];
const HAT_PUNCTUATION = [[], [6], [14], [2, 10], [6, 14], [2, 6, 10, 14], [4, 12], [2, 14]];
const CRASH_PUNCTUATION = [[], [8], [0, 8], [0, 12], [0, 8, 12], [4, 12]];
function expandGrooveBank(recipes: GrooveRecipe[], target = 12): GrooveRecipe[] {
  const result = recipes.map(recipe => ({ ...recipe }));
  const signature = (recipe: GrooveRecipe) => JSON.stringify(Object.fromEntries(Object.entries(recipe).sort(([a], [b]) => a.localeCompare(b))));
  const seen = new Set(result.map(signature));
  let attempt = 0;
  while (result.length < target && attempt < target * 20) {
    const base = recipes[attempt % recipes.length];
    const kickPickup = KICK_PICKUPS[(attempt + 1) % KICK_PICKUPS.length];
    const hatPunctuation = HAT_PUNCTUATION[(attempt * 3 + 1) % HAT_PUNCTUATION.length];
    const crashPunctuation = CRASH_PUNCTUATION[(attempt * 5 + 2) % CRASH_PUNCTUATION.length];
    const candidate: GrooveRecipe = { ...base };
    const toggle = (original: number[], changes: number[]) => {
      const next = new Set(original);
      for (const step of changes) { if (next.has(step)) next.delete(step); else next.add(step); }
      return sortedUnique(Array.from(next));
    };
    candidate.kick = sortedUnique([0, ...toggle(base.kick ?? [], kickPickup)]);
    if (base.closedHat) candidate.closedHat = toggle(base.closedHat, hatPunctuation);
    if (base.openHat) candidate.openHat = toggle(base.openHat, hatPunctuation.filter(step => step % 2 === 0));
    if (base.crash) candidate.crash = toggle(base.crash, crashPunctuation);
    else if (crashPunctuation.length) candidate.crash = crashPunctuation;
    // Keep the authored snare/backbeat and the recipe's other lane relationships intact.
    const key = signature(candidate);
    if (!seen.has(key)) { seen.add(key); result.push(candidate); }
    attempt++;
  }
  return result;
}
for (const key of Object.keys(GROOVE_GRAMMAR)) {
  GROOVE_GRAMMAR[key] = expandGrooveBank(GROOVE_GRAMMAR[key], 14);
}
