// Genre Konverter
// Copyright (c) 2026 Hans-Georg Tröster
// Licensed under the Genre Konverter Free Music Creator License.
// See LICENSE.md for the project license.
// Free for all music friends - personal, hobby, and noncommercial use.
// Not licensed for commercial use or resale. See LICENSE.md.

// Pattern data for 25 Rock (and Rock-adjacent) subgenres.
// Hit times are in beats (0-4, one 4/4 bar). Each lane can have several
// variation arrays; one is picked at random per bar when generating a clip.
// Characteristics below are derived from general genre-drumming conventions
// (community knowledge on how each style's groove is typically played,
// informed by the standard rhythm vocabulary documented in genre drum-
// pattern reference books), not transcribed from any specific copyrighted
// recording, tab, or pattern grid.

export interface GenrePattern {
  key: string;
  label: string;
  defaultBpm: number;
  swingAmount: number; // 0-100
  swingGrid: "8" | "16";
  lanes: {
    kick: number[][];
    snare: number[][];
    altSnare: number[][];
    midTom: number[][];
    lowTom: number[][];
    closedHat: number[][];
    openHat: number[][];
    hiTom: number[][];
    crash: number[][];
    ride: number[][];
  };
}

export const GENRES: GenrePattern[] = [
  {
    key: "classicRock",
    label: "Classic Rock",
    defaultBpm: 122,
    swingAmount: 10,
    swingGrid: "8",
    lanes: {
      kick: [[0, 2], [0, 1.5, 2], [0, 2, 2.5], [0, 1, 2, 3]],
      snare: [[1, 3]],
      altSnare: [[2.75]], // extra pickup hit before the "and" of 3
      lowTom: [],
      midTom: [[1, 3]],
      closedHat: [[0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]],
      openHat: [[0.5, 1.5, 2.5, 3.5], [0], [0, 2]],
      hiTom: [[0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]], // tambourine doubling the hat
      crash: [],
      ride: []
    }
  },
  {
    key: "hardRock",
    label: "Hard Rock",
    defaultBpm: 132,
    swingAmount: 6,
    swingGrid: "8",
    lanes: {
      kick: [[0, 0.75, 2, 2.75], [0, 1.5, 2, 3], [0, 0.75, 1.5, 2, 2.75], [0, 1, 1.5, 2, 3, 3.5]],
      snare: [[1, 3], [1, 2.75, 3]], // extra pickup hit ahead of beat 3
      altSnare: [[0.75, 2.75], [0.75, 1.75, 2.75, 3.75]], // rimshot accents
      lowTom: [],
      midTom: [[1, 3]],
      closedHat: [[0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]], // ride-style drive
      openHat: [[0], [0, 2]], // crash on the downbeat
      hiTom: [[0, 1, 2, 3]], // cowbell
      crash: [],
      ride: []
    }
  },
  {
    key: "bluesRock",
    label: "Blues Rock",
    defaultBpm: 116,
    swingAmount: 58,
    swingGrid: "8",
    lanes: {
      kick: [[0, 2], [0, 1.67, 2], [0, 1.33, 2, 3.33], [0, 2, 2.67]],
      snare: [[1, 3]],
      altSnare: [[0.33, 0.67, 1.33, 1.67, 2.33, 2.67, 3.33, 3.67], [0.67, 1.67, 2.67, 3.67]], // ghost notes
      lowTom: [],
      midTom: [[1, 3]],
      closedHat: [[0, 0.67, 1, 1.67, 2, 2.67, 3, 3.67]], // shuffle
      openHat: [[1.67, 3.67], [0], [1.67]],
      hiTom: [],
      crash: [],
      ride: [[0, 0.67, 1, 1.67, 2, 2.67, 3, 3.67]]
    }
  },
  {
    key: "psychRock",
    label: "Psychedelic Rock",
    defaultBpm: 108,
    swingAmount: 25,
    swingGrid: "8",
    lanes: {
      kick: [[0, 1.75, 2.5], [0, 2, 3.25]],
      snare: [[1, 3]],
      altSnare: [[1.75, 2.25, 3.75]],
      lowTom: [],
      midTom: [],
      closedHat: [[0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]],
      openHat: [[0.5, 2.5]],
      hiTom: [[0.25, 0.5, 0.75, 1.25, 1.5, 1.75, 2.25, 2.5, 2.75, 3.25, 3.5, 3.75]], // rolling toms
      crash: [],
      ride: []
    }
  },
  {
    key: "progRock",
    label: "Progressive Rock",
    defaultBpm: 128,
    swingAmount: 4,
    swingGrid: "16",
    lanes: {
      kick: [[0.5, 1.75, 2.5], [0.75, 2, 3.25], [0.25, 1.5, 2.75]], // shifted off the 1
      snare: [[1, 3]],
      altSnare: [[0.5, 1.75, 2.75, 3.5]],
      lowTom: [],
      midTom: [],
      closedHat: [[0, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 3.75]],
      openHat: [[1.5, 3.5]],
      hiTom: [[0.75, 1.75, 2.75, 3.75]],
      crash: [],
      ride: []
    }
  },
  {
    key: "symphonicRock",
    label: "Symphonic Rock",
    defaultBpm: 118,
    swingAmount: 8,
    swingGrid: "8",
    lanes: {
      kick: [[0, 2], [0, 1.5, 2, 3]],
      snare: [[1, 3]],
      altSnare: [[0.75, 2.75]],
      lowTom: [],
      midTom: [],
      closedHat: [[0, 1, 2, 3]],
      openHat: [[0, 1, 2, 3]], // cymbal swells
      hiTom: [[0, 2]], // timpani
      crash: [],
      ride: [[0.5, 1.5, 2.5, 3.5]] // chimes
    }
  },
  {
    key: "punkRock",
    label: "Punk Rock",
    defaultBpm: 158,
    swingAmount: 0,
    swingGrid: "8",
    lanes: {
      kick: [[0, 0.5, 2, 2.5], [0, 1, 2, 3], [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]], // D-beat, straight quarters, galloping 8ths
      snare: [[1, 3], [1, 1.5, 3, 3.5]],
      altSnare: [],
      lowTom: [],
      midTom: [[1, 3]],
      closedHat: [[], [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]],
      openHat: [[0, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 3.75], []], // wide open, aggressive
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "popPunk",
    label: "Pop Punk",
    defaultBpm: 155,
    swingAmount: 0,
    swingGrid: "8",
    lanes: {
      kick: [[0, 1, 2, 2.5, 3], [0, 0.5, 1, 2, 2.5, 3], [0, 1, 1.5, 2, 3]],
      snare: [[1, 3], [1, 2.5, 3]],
      altSnare: [],
      lowTom: [],
      midTom: [[1, 3]],
      closedHat: [[0, 1, 2, 3], [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]],
      openHat: [[0.5, 1.5, 2.5, 3.5], []], // clean open/close alternation
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "grunge",
    label: "Grunge",
    defaultBpm: 95,
    swingAmount: 15,
    swingGrid: "8",
    lanes: {
      kick: [[0, 2.5], [0, 1.5], [0, 2]], // half-time-leaning, a few options instead of just two
      snare: [[2], [2], [1.5, 2]], // mostly half-time (snare only on 3), occasional pickup
      altSnare: [[], [0.75, 2.75]], // occasional loose ghost accent
      lowTom: [[], [2.5]],
      midTom: [[], [1.5]],
      closedHat: [[0, 1, 2, 3], []], // quiet/verse option, or resting entirely under the crash
      openHat: [[0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5], [0.5, 1.5, 2.5, 3.5]],
      hiTom: [],
      crash: [[0], [], [0, 2]], // the loud/chorus side of grunge's quiet-loud contrast - was never used before
      ride: []
    }
  },
  {
    key: "altRock",
    label: "Alternative Rock",
    defaultBpm: 120,
    swingAmount: 12,
    swingGrid: "8",
    lanes: {
      kick: [[0, 2], [0, 1.5, 2]],
      snare: [[1, 3]],
      altSnare: [[0.75, 2.75]],
      lowTom: [],
      midTom: [[1, 3]],
      closedHat: [[0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]],
      openHat: [[1.5, 3.5]],
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "indieRock",
    label: "Indie Rock",
    defaultBpm: 118,
    swingAmount: 5,
    swingGrid: "8",
    lanes: {
      kick: [[0, 1, 2, 3], [0, 1.5, 2, 3], [0, 2]], // four-on-the-floor, syncopated, sparse/restrained
      snare: [[1, 3]],
      altSnare: [[], [0.75, 2.75]], // occasional light ghost accents
      lowTom: [],
      midTom: [[1, 3]],
      closedHat: [[0, 1, 2, 3], []], // closes on the downbeats, sometimes rests entirely
      openHat: [[0.5, 1.5, 2.5, 3.5], [1.5, 3.5]], // opens on the "and"s
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "nuMetal",
    label: "Nu Metal / Rap Rock",
    defaultBpm: 100,
    swingAmount: 0,
    swingGrid: "16",
    lanes: {
      kick: [[0, 0.25, 0.75, 1, 2, 2.25, 2.75, 3], [0, 0.5, 0.75, 1, 2, 2.5, 2.75, 3]], // dense double-kick clusters
      snare: [[1, 3]],
      altSnare: [[1, 3, 3.25]],
      lowTom: [[], [2.75]],
      midTom: [[], [1.25]],
      closedHat: [[0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]],
      openHat: [[3.5]],
      hiTom: [],
      crash: [[], [0]],
      ride: []
    }
  },
  {
    key: "gothicRock",
    label: "Gothic Rock",
    defaultBpm: 128,
    swingAmount: 0,
    swingGrid: "16",
    lanes: {
      kick: [[0, 2], [0, 1, 2, 3], [0, 1.5, 2, 3.5]], // still mechanical/precise, just not bar-for-bar identical
      snare: [[1, 3]],
      altSnare: [],
      lowTom: [],
      midTom: [],
      closedHat: [[0, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 3.75], [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]], // mechanical 16ths or straight 8ths
      openHat: [],
      hiTom: [[0, 2], [0, 1, 2, 3], [0, 1.5, 2, 3.5]], // toms parallel to the kick
      crash: [],
      ride: []
    }
  },
  {
    key: "glamRock",
    label: "Glam Rock",
    defaultBpm: 128,
    swingAmount: 8,
    swingGrid: "8",
    lanes: {
      kick: [[0, 1, 2, 3]], // stomping
      snare: [[1, 3]],
      altSnare: [],
      lowTom: [],
      midTom: [[1, 3], [1, 3]], // prominent claps
      closedHat: [[0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]],
      openHat: [[0]], // crash at bar start
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "funk",
    label: "Funk",
    defaultBpm: 104,
    swingAmount: 12,
    swingGrid: "16",
    lanes: {
      // Syncopated 16th-note kick, tight backbeat snare, ghost notes on
      // Alt Snare, and a constant 16th hi-hat pulse — the funk staples.
      kick: [[0, 0.75, 2, 2.75], [0, 1.5, 2.25, 3], [0, 0.75, 1.5, 2, 2.75, 3.5], [0, 0.5, 1.75, 2.5, 3.25]],
      snare: [[1, 3]],
      altSnare: [[0.5, 0.75, 1.75, 2.5, 2.75, 3.75], [0.25, 0.75, 1.25, 2.25, 2.75, 3.25, 3.75]], // ghost notes
      lowTom: [],
      midTom: [],
      closedHat: [[0, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 3.75]],
      openHat: [[0.75, 2.75], [0.75], [2.75, 3.75]],
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "reggae",
    label: "Reggae",
    defaultBpm: 82,
    swingAmount: 10,
    swingGrid: "8",
    lanes: {
      kick: [[2], [0, 2], [0, 1, 2, 3], [2], [0, 1.5, 2, 3.5], [2, 3.5], [0, 2, 3.5], [0, 1.5, 2]], // one-drop, steppers, rockers + restrained variations
      snare: [[2], [1, 3], [2], [2], [1, 3]],
      altSnare: [[2], [0.5, 1.5, 2.5, 3.5], [], [0.5, 1, 1.5, 2.5, 3, 3.5], [1.5, 3.5], [2, 3.5]], // skank rim clicks
      lowTom: [],
      midTom: [],
      closedHat: [[0.5, 1, 1.5, 2, 2.5, 3, 3.5], [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5], [0.5, 1.5, 2.5, 3.5], [0, 1, 2, 3]],
      openHat: [[3.5], [1.5, 3.5], [1.5], [3, 3.5]],
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "ska",
    label: "Ska",
    defaultBpm: 150,
    swingAmount: 8,
    swingGrid: "8",
    lanes: {
      // Uptempo, driving four-on-the-floor-ish kick with the offbeat
      // "skank" accent carried on Alt Snare/hat rather than the guitar,
      // since this is a drums-only converter. Backbeat snare stays steady.
      kick: [[0, 2], [0, 1, 2, 3], [0, 2, 2.5]],
      snare: [[1, 3]],
      altSnare: [[0.5, 1.5, 2.5, 3.5], [0.5, 2.5]], // offbeat skank accents
      lowTom: [],
      midTom: [],
      closedHat: [[0.5, 1.5, 2.5, 3.5], [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]],
      openHat: [[0], []],
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "jazz",
    label: "Jazz",
    defaultBpm: 132,
    swingAmount: 62,
    swingGrid: "8",
    lanes: {
      // Classic "spang-a-lang" ride pattern, hi-hat chick on 2 & 4, sparse
      // comping on Alt Snare rather than a steady backbeat.
      kick: [[0], [], [0, 2]],
      snare: [[], [1.75], [2.5, 3.75], []], // sparse comping - intermittent by nature, mostly empty
      altSnare: [[0.5, 1.75, 2.5, 3.25], [1.75, 3.25], [0.75, 2.25, 3.75]],
      lowTom: [],
      midTom: [],
      closedHat: [[1, 3]],
      openHat: [],
      hiTom: [],
      crash: [],
      ride: [[0, 1.5, 2, 3.5], [0, 1, 1.5, 2, 3, 3.5], [0, 1.67, 2, 3.67]]
    }
  },
  {
    key: "hiphop",
    label: "Hip-Hop",
    defaultBpm: 92,
    swingAmount: 15,
    swingGrid: "16",
    lanes: {
      // Boom-bap: laid-back kick placement, tight backbeat, ghost notes.
      kick: [[0, 1.75], [0, 2.5], [0, 1.5, 2.75]],
      snare: [[1, 3]],
      altSnare: [[0.75, 2.75]],
      lowTom: [],
      midTom: [],
      closedHat: [[0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]],
      openHat: [[3.5]],
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "rap",
    label: "Rap / Trap",
    defaultBpm: 140,
    swingAmount: 0,
    swingGrid: "16",
    lanes: {
      // Half-time trap feel: snare only on beat 3, syncopated 808-style
      // kick, dense rolling hi-hats.
      kick: [[0, 0.5, 2.25], [0, 1.75, 2.5]],
      snare: [[2]],
      altSnare: [],
      lowTom: [],
      midTom: [],
      closedHat: [[0, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 3.75]],
      openHat: [[3.75]],
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "dub",
    label: "Dub",
    defaultBpm: 72,
    swingAmount: 10,
    swingGrid: "8",
    lanes: {
      // Dub is the reggae rhythm track itself, remixed with effects - not
      // a separately-composed, sparser drum style. The baseline groove
      // here matches reggae's own one-drop/steppers/rockers skeleton, so
      // there's always a real groove present; the dramatic "drop out"
      // silence lives in the fill (dubEffectFill) as an occasional
      // production moment, not baked into every single bar. The
      // cross-stick (Alt Snare), not the snare, still carries the beat-3
      // backbone, matching real reggae/dub practice.
      kick: [[2], [0, 2], [0, 1, 2, 3], [0, 1.5, 2, 3.5], [2, 3.5], [0, 2, 3.5], [0, 1.5, 2]], // one-drop, steppers, rockers + variations
      snare: [],
      altSnare: [[2], [0.5, 1.5, 2.5, 3.5], [0.5, 1, 1.5, 2.5, 3, 3.5], [1.5, 3.5], [2, 3.5], []],
      lowTom: [],
      midTom: [],
      closedHat: [[0.5, 1, 1.5, 2, 2.5, 3, 3.5], [0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]],
      openHat: [[3.5], [1.5, 3.5]],
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "breakbeat",
    label: "Breakbeat",
    defaultBpm: 136,
    swingAmount: 8,
    swingGrid: "16",
    lanes: {
      // Chopped-break syncopation: snare lands off the strict backbeat too.
      kick: [[0, 0.75, 2], [0, 1.25, 2.5]],
      snare: [[1, 1.75, 3], [1, 3, 3.5]],
      altSnare: [[2.25]],
      lowTom: [],
      midTom: [],
      closedHat: [[0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5]],
      openHat: [[0.75, 2.75]],
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "jungle",
    label: "Jungle",
    defaultBpm: 144, // Jungle project tempo selected after the 9.1.3 groove review
    swingAmount: 8,
    swingGrid: "16",
    lanes: {
      // Transcribed directly from the precise 16th-note MIDI drum tab:
      // Kick on 1, "a" of 2 (step 8), and "&" of 3 (step 11). Accent
      // snare on 2 and 4. Ghost-note snare on the "&" of 3 and the "a" of
      // 4. Closed hat driving underneath, Open hat marking the "a" of 2.
      // Velocity handling for the accent/ghost split lives in
      // grooveVelocity() below - this is what was missing before and is
      // most of why it didn't read as real jungle.
      kick: [[0, 1.75, 2.5], [0, 2, 2.5]],
      snare: [[1, 3]], // accent snare (S)
      altSnare: [[2.25, 3.75], [2.25, 3.5]], // ghost-note snare (s/g) - low velocity, handled in grooveVelocity
      lowTom: [],
      midTom: [],
      closedHat: [[0, 0.5, 1, 1.5, 2.5, 3, 3.5]],
      openHat: [[1.75]],
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "drumAndBass",
    label: "Drum & Bass",
    defaultBpm: 160, // capped at 160 - real DnB runs 160-190 BPM
    swingAmount: 8,
    swingGrid: "16",
    lanes: {
      // Four classic DnB skeletons mixed into one bank, so re-shuffling
      // moves between them: 2-Step (kick 1 & "3-and", rigid 2&4 snare),
      // Neurofunk (extra kick before the second snare for a stumbling
      // momentum), Amen-break-style (busy, syncopated kick, pushed-ahead
      // snare near the barline), and Halftime/Drumstep (snare pulled all
      // the way back to just the "3").
      kick: [[0, 2.5], [0, 1.5, 2.5], [0, 1.5, 2, 3.5], [0, 3.5]],
      snare: [[1, 3], [1, 3], [1, 2.5, 3, 3.75], [2]],
      altSnare: [[], [1.75], [0.75, 2.75], []], // "rollers" - quiet ghost fills between the main hits
      lowTom: [],
      midTom: [],
      closedHat: [[0, 0.5, 1, 1.5, 2, 2.5, 3, 3.5], [0, 0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 3.75]],
      openHat: [[3.5], []],
      hiTom: [],
      crash: [],
      ride: []
    }
  },
  {
    key: "lofi",
    label: "Lo-Fi",
    defaultBpm: 80,
    swingAmount: 35,
    swingGrid: "8",
    lanes: {
      // Laid-back, sparse, heavily swung — the lo-fi hip-hop staple.
      kick: [[0, 2.5], [0, 2], [0, 1.75, 2.5], [0, 2.75], [0, 1.5, 2.5], [0, 2, 3.5], [0, 1.75, 3]],
      snare: [[1, 3], [1, 3], [1, 2.75, 3], [1.25, 3], [1, 3.25]],
      altSnare: [],
      lowTom: [],
      midTom: [],
      closedHat: [[0, 1, 2, 3], [0, 0.75, 1.5, 2, 3], [0, 1, 2, 2.75, 3], [0, 0.5, 1.5, 2.5, 3], [0, 1, 2, 3.5], [0, 1.5, 2, 3]],
      openHat: [[3.5], [], [2.5], [1.5, 3.5]],
      hiTom: [],
      crash: [],
      ride: []
    }
  }
];
