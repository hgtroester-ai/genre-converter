/**
 * Genre Konverter
 * Copyright (c) 2026 Hans-Georg Tröster
 *
 * Licensed under the Genre Konverter Free Music Creator License.
 * See LICENSE.md for the project license.
 *
 * Free to use for music creation, including commercial release of music made with the software.
 * The software itself may not be sold or commercially redistributed. See LICENSE.md.
 */
import * as fs from "node:fs";
import * as path from "node:path";
import {
  initialize,
  ClipSlot,
  MidiTrack,
  type ActivationContext,
  type Handle,
} from "@ableton-extensions/sdk";
import { buildUiHtml, type PanelSettings } from "./ui";

interface GenerateMessage {
  type: "generateMidiClip" | "cancel";
  genre?: string;
  genreLabel?: string;
  sectionLabel?: string;
  drummerLabel?: string;
  bars?: number;
  clipBeats?: number;
  bpm?: number;
  setTempo?: boolean;
  trackIndex?: number;
  slotIndex?: number;
  notes?: { pitch: number; time: number; duration: number; velocity: number }[];
  settings?: PanelSettings;
}

const SETTINGS_FILE = "genre-konverter-settings.json";

function loadSettings(storageDir: string | undefined): PanelSettings {
  if (!storageDir) return {};
  try {
    const raw = fs.readFileSync(path.join(storageDir, SETTINGS_FILE), "utf8");
    return JSON.parse(raw) as PanelSettings;
  } catch {
    return {}; // no settings saved yet, or file unreadable — start fresh
  }
}

function saveSettings(storageDir: string | undefined, settings: PanelSettings) {
  if (!storageDir) return;
  try {
    fs.mkdirSync(storageDir, { recursive: true });
    fs.writeFileSync(path.join(storageDir, SETTINGS_FILE), JSON.stringify(settings));
  } catch {
    // Non-fatal — the panel just won't remember state for next time.
  }
}

function messageDialogHtml(title: string, message: string): string {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    body { margin:0; background:#101216; color:#f5f7fa; font-family:-apple-system,"Segoe UI",Helvetica,Arial,sans-serif;
           display:flex; flex-direction:column; justify-content:center; align-items:center; height:100vh; text-align:center; padding:0 24px; box-sizing:border-box; }
    h2 { margin:0 0 10px 0; font-size:16px; }
    p { margin:0 0 20px 0; color:#d3d9e3; font-size:13px; line-height:1.5; }
    button { background:#d94f16; color:#fff; border:none; border-radius:6px; padding:9px 22px; font-size:13px; cursor:pointer; }
    button:hover { background:#f26828; }
  </style></head><body>
    <h2>${title}</h2>
    <p>${message}</p>
    <button id="ok">OK</button>
    <script>
      document.getElementById("ok").addEventListener("click", () => {
        const msg = { method: "close_and_send", params: ["{}"] };
        if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.live) {
          window.webkit.messageHandlers.live.postMessage(msg);
        } else if (window.chrome && window.chrome.webview) {
          window.chrome.webview.postMessage(msg);
        }
      });
    </script>
  </body></html>`;
}

async function showMessageDialog(
  context: ReturnType<typeof initialize>,
  title: string,
  message: string
) {
  const url = `data:text/html,${encodeURIComponent(messageDialogHtml(title, message))}`;
  try {
    await context.ui.showModalDialog(url, 380, 220);
  } catch {
    // If even the message dialog can't open, there's nothing more we can
    // do — but we still avoid crashing the extension host.
  }
}

export function activate(activation: ActivationContext) {
  const context = initialize(activation, "1.0.0");

  context.commands.registerCommand("genreKonverter.open", (arg: unknown) =>
    (async (handle: Handle) => {
      // Fallback target: whichever ClipSlot the user right-clicked.
      let fallbackClipSlot: ClipSlot<"1.0.0"> | null = null;
      try {
        fallbackClipSlot = context.getObjectFromHandle(handle, ClipSlot);
      } catch {
        // Command may have been invoked without a ClipSlot handle; that's
        // fine as long as the panel's own track/slot picker is used instead.
      }

      const songTracks = context.application.song.tracks;
      // Preserve the selected ClipSlot as the initial destination, when the
      // command was opened from a specific slot in Live.
      let defaultTarget: { trackIndex?: number; slotIndex?: number } = {};
      if (fallbackClipSlot) {
        for (let trackIndex = 0; trackIndex < songTracks.length; trackIndex++) {
          const slotIndex = songTracks[trackIndex].clipSlots.findIndex((slot) => slot === fallbackClipSlot);
          if (slotIndex >= 0) {
            defaultTarget = { trackIndex, slotIndex };
            break;
          }
        }
      }

      const tracks = songTracks
        .map((t, i) => ({ track: t, index: i }))
        .filter(({ track }) => track instanceof MidiTrack)
        .map(({ track, index }) => ({
          index,
          name: track.name,
          slots: track.clipSlots.map((slot, slotIndex) => ({
            index: slotIndex,
            occupied: !!slot.clip
          }))
        }));

      const storageDir = context.environment.storageDirectory;
      const savedSettings = loadSettings(storageDir);

      const url = `data:text/html,${encodeURIComponent(buildUiHtml(tracks, savedSettings, defaultTarget))}`;
      const result = await context.ui.showModalDialog(url, 1240, 820);

      let msg: GenerateMessage;
      try {
        msg = JSON.parse(result);
      } catch {
        return; // dialog was closed without any result at all
      }

      // Remember genre / lock-mute / volume regardless of Create vs Cancel,
      // so preferences aren't lost just because no clip was generated.
      if (msg.settings) {
        saveSettings(storageDir, msg.settings);
      }

      if (msg.type !== "generateMidiClip" || !msg.notes) return;

      let targetClipSlot: ClipSlot<"1.0.0"> | null = fallbackClipSlot;
      if (msg.trackIndex !== undefined && msg.slotIndex !== undefined) {
        const track = context.application.song.tracks[msg.trackIndex];
        if (track) targetClipSlot = track.clipSlots[msg.slotIndex] ?? targetClipSlot;
      }
      if (!targetClipSlot) return;
      const clipSlot = targetClipSlot;
      const bars = msg.bars ?? 4;
      const clipBeats = msg.clipBeats ?? bars * 4;
      const bpm = msg.bpm ?? 120;
      const notes = msg.notes;

      // Re-check occupancy right before writing — the slot list shown in
      // the panel is a snapshot from when it opened, so this catches a
      // slot that got filled in the meantime instead of crashing on it.
      if (clipSlot.clip) {
        await showMessageDialog(
          context,
          "Slot Occupied",
          "This clip slot already contains a clip. Please choose an empty slot or delete the existing clip first."
        );
        return;
      }

      try {
        // withinTransaction's callback must be synchronous, but can return
        // a promise chain to group the async clip-creation into one step.
        await context.withinTransaction(() => {
          if (msg.setTempo) {
            context.application.song.tempo = bpm;
          }
          return clipSlot.createMidiClip(clipBeats).then((clip) => {
            clip.notes = notes.map((n) => ({
              pitch: n.pitch,
              startTime: n.time,
              duration: n.duration,
              velocity: n.velocity
            }));
            if (msg.genreLabel) {
              const parts = [msg.genreLabel, msg.drummerLabel, msg.sectionLabel].filter((part) => Boolean(part && part.trim()));
              clip.name = parts.join(" - ");
            }
          });
        });
      } catch (err) {
        await showMessageDialog(
          context,
          "Clip Could Not Be Created",
          "An error occurred while writing the MIDI clip. Please check the slot/track and try again."
        );
      }
    })(arg as Handle).catch(async () => {
      // Keep an unexpected Live/API or dialog error local to this command.
      // A failed panel launch must not leave an unhandled rejection behind.
      await showMessageDialog(
        context,
        "Genre Konverter",
        "The panel could not be opened or completed. Please close it and try again."
      );
    })
  );

  context.ui.registerContextMenuAction(
    "ClipSlot",
    "Genre Konverter…",
    "genreKonverter.open"
  );
}
