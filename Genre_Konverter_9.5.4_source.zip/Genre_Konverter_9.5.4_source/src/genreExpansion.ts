import { GrooveRecipe } from "./grooveGrammar";

// Newly authored, coordinated one-bar recipes for Genre Expansion 7.9.4.
// Step indices are 16th-note positions (0..15) in 4/4. These are original
// style interpretations, not transcriptions of commercial recordings.
const r = (kick: number[], snare: number[], closedHat: number[], extra: GrooveRecipe = {}): GrooveRecipe => ({ kick, snare, closedHat, ...extra });
const eighths = [0,2,4,6,8,10,12,14];
const quarters = [0,4,8,12];
const sixteenths = Array.from({length:16},(_,i)=>i);

export const GENRE_EXPANSION: Record<string, { verse: GrooveRecipe[]; chorus?: GrooveRecipe[]; bridge?: GrooveRecipe[] }> = {
  reggae: {
    verse: [
      r([8],[],eighths,{altSnare:[8],openHat:[6,14]}), // One Drop
      r([0,8],[],eighths,{altSnare:[8],openHat:[6,14]}), // Roots / Steppers
      r([0,6,8,14],[4,12],eighths,{altSnare:[8],openHat:[6,14]}), // Rockers
      r([8],[4,12],eighths,{altSnare:[8],ride:[0,4,8,12]}),
      r([0,8],[],[0,4,8,12],{altSnare:[8],ride:[2,6,10,14]}),
      r([8,14],[],eighths,{altSnare:[8],openHat:[14],lowTom:[15]})
    ],
    chorus: [
      r([0,8],[],eighths,{altSnare:[8],openHat:[2,6,10,14],crash:[0]}),
      r([0,6,8,14],[4,12],eighths,{altSnare:[8],openHat:[6,14],crash:[0]})
    ],
    bridge: [
      r([8],[],[0,4,8,12],{altSnare:[8],lowTom:[14]}),
      r([8],[],[0,8],{altSnare:[8],ride:[2,10]})
    ]
  },
  dub: {
    // Three recognizable Dub foundations: One Drop, Steppers and Roots.
    // The kick/rim relationship is deliberately clear even at 65-100 BPM;
    // offbeat hats provide the skank without a constant rock backbeat.
    verse: [
      r([8],[],eighths,{altSnare:[8],openHat:[6,14]}),
      r([0,4,8,12],[],eighths,{altSnare:[8],openHat:[6,14]}),
      r([0,8],[],[2,6,10,14],{altSnare:[8],openHat:[6,14]}),
      r([0,6,8,14],[],eighths,{altSnare:[8,4,12],openHat:[6,14]}),
      r([8,14],[],eighths,{altSnare:[8],lowTom:[15],openHat:[14]}),
      r([0,8],[],[0,2,4,6,8,10,12,14],{altSnare:[8],ride:[6,14]})
    ],
    chorus: [
      r([0,4,8,12],[],eighths,{altSnare:[8],openHat:[2,6,10,14],ride:[0,8]}),
      r([0,6,8,12,14],[],eighths,{altSnare:[4,8,12],openHat:[6,14],ride:[0,4,8,12]})
    ],
    bridge: [
      r([8],[],[2,6,10,14],{altSnare:[8],lowTom:[14]}),
      r([0,8],[],[0,4,8,12],{altSnare:[8],lowTom:[7,15]}),
      r([],[],[2,6,10,14],{altSnare:[8],lowTom:[6,14]})
    ]
  },
  ska: {
    // Verse: tight, lighter offbeat skank with a compact backbeat.
    verse: [
      r([0,8],[4,12],eighths,{openHat:[2,6,10,14]}),
      r([0,8,14],[4,12],eighths,{openHat:[2,6,10,14],altSnare:[7]}),
      r([0,4,8],[4,12],quarters,{openHat:[2,6,10,14]}),
      r([0,6,8],[4,12],eighths,{openHat:[2,6,10,14],ride:[0,8]})
    ],
    // Chorus: unmistakably bigger skank; more kick propulsion, ride support
    // and occasional snare answers, but no continuous crash layer.
    chorus: [
      r([0,4,6,8,12,14],[4,12],eighths,{openHat:[2,6,10,14],ride:[0,4,8,12]}),
      r([0,3,4,8,11,12],[4,12],eighths,{openHat:[2,6,10,14],ride:[0,2,4,6,8,10,12,14],altSnare:[15]}),
      r([0,4,8,10,12],[4,10,12],eighths,{openHat:[2,6,10,14],ride:[0,4,8,12]}),
      r([0,2,6,8,12,14],[4,12],eighths,{openHat:[2,6,10,14],ride:[0,8],altSnare:[7,15]})
    ],
    bridge: [
      r([0,8],[8],quarters,{closedHat:[0,4,8,12],lowTom:[14]}),
      r([0,6],[4,12],eighths,{openHat:[6,14],midTom:[7,15]}),
      r([0,8,14],[8],quarters,{closedHat:[0,8],lowTom:[7,15]})
    ]
  },
  hiphop: {
    // Hip-Hop is deliberately pocket-led: sparse kick placement, a firm
    // backbeat, mostly quarter/eighth-note hats and restrained ghost notes.
    verse: [
      r([0,10],[4,12],[0,4,8,12],{altSnare:[7]}), // dry boom bap
      r([0,6,10],[4,12],[0,2,4,6,8,10,12,14],{altSnare:[11]}), // swung pocket
      r([0,11],[4,12],[0,4,8,12],{altSnare:[3,15]}), // laid-back push
      r([0,8],[8],[0,4,8,12],{altSnare:[7]}), // half-time pocket
      r([0,7,10],[4,12],[0,4,8,12],{altSnare:[15]}) // sparse syncopation
    ],
    chorus: [
      r([0,6,10,14],[4,12],[0,2,4,6,8,10,12,14],{altSnare:[7,15],openHat:[14]}),
      r([0,4,10],[4,12],[0,4,8,12],{altSnare:[3,11],crash:[0]})
    ],
    bridge: [
      r([0,10],[8],[0,4,8,12],{altSnare:[7]}),
      r([0],[4,12],[0,8],{altSnare:[3,15]})
    ]
  },
  jungle: {
    verse: [
      r([0,6,8,11,14],[4,7,12,15],sixteenths,{altSnare:[3,10],ride:[0,8]}),
      r([0,3,6,8,11,14],[4,7,12,15],eighths,{altSnare:[2,10,14]}),
      r([0,6,8,10,14],[4,7,12,15],sixteenths,{altSnare:[3,11],openHat:[14]}),
      r([0,5,8,11,14],[4,7,12],eighths,{altSnare:[2,6,10,14]}),
      r([0,6,8,13],[4,7,12,15],sixteenths,{altSnare:[3,11],lowTom:[15]})
    ],
    chorus: [
      r([0,3,6,8,11,14],[4,7,12,15],sixteenths,{altSnare:[2,10,14],crash:[0]}),
      r([0,6,8,10,14],[4,7,12,15],eighths,{altSnare:[3,11],openHat:[6,14]})
    ],
    bridge: [
      r([0,8],[8],[0,4,8,12],{altSnare:[3,7,11,15],lowTom:[14]}),
      r([0,6,8],[4,12],sixteenths,{altSnare:[2,10,14]})
    ]
  },
  drumAndBass: {
    // DnB is not a faster Hip-Hop loop: 2-step propulsion, displaced
    // kicks, stronger offbeat/16th hat motion and break-oriented snare edits.
    verse: [
      r([0,6,10,14],[4,12],[0,2,4,6,8,10,12,14],{altSnare:[3,7,11,15]}), // rolling 2-step
      r([0,3,6,8,11,14],[4,12],sixteenths,{altSnare:[7,15],openHat:[6,14]}), // break edge
      r([0,5,8,10,13],[4,12],[0,2,4,6,8,10,12,14],{altSnare:[3,11],ride:[2,6,10,14]}),
      r([0,6,8,14],[4,12],sixteenths,{altSnare:[2,7,10,15],openHat:[14]}), // neuro push
      r([0,4,7,10,14],[4,12],[0,2,4,6,8,10,12,14],{altSnare:[3,7,11,15]})
    ],
    chorus: [
      r([0,3,6,8,11,14],[4,12],sixteenths,{altSnare:[3,7,11,15],crash:[0]}),
      r([0,6,8,10,14],[4,12],[0,2,4,6,8,10,12,14],{altSnare:[2,7,10,15],openHat:[6,14],crash:[0]})
    ],
    bridge: [
      r([0,8,14],[8],[0,2,4,6,8,10,12,14],{altSnare:[3,7,11,15]}), // halftime breakdown
      r([0,6,10],[4,12],sixteenths,{altSnare:[2,7,10,15]})
    ]
  },
  // Audit-driven authored additions for the remaining thin recipe banks.
  hardRock: {
    verse:[
      r([0,8,14],[4,12],eighths,{closedHat:[0,2,4,6,8,10,12,14],openHat:[14]}),
      r([0,6,8],[4,12],eighths,{closedHat:[0,2,4,6,8,10,12,14],altSnare:[7,15]}),
      r([0,4,8,14],[4,12],quarters,{ride:[0,4,8,12]})
    ],
    chorus:[
      r([0,4,8,10,12,14],[4,12],eighths,{openHat:[2,6,10,14],ride:[0,4,8,12]}),
      r([0,6,8,11,14],[4,10,12],eighths,{openHat:[6,14],ride:[0,2,4,6,8,10,12,14]}),
      r([0,3,8,10,12],[4,12],eighths,{openHat:[2,6,10,14],altSnare:[7,15]})
    ],
    bridge:[
      r([0,8],[8],quarters,{lowTom:[0,4,8,12],closedHat:[0,8]}),
      r([0,6],[4,12],eighths,{midTom:[7,15],closedHat:[0,4,8,12]}),
      r([0,8,14],[8],quarters,{lowTom:[7,15],ride:[0,8]})
    ]
  },
  bluesRock: { verse:[r([0,8],[4,12],eighths,{ride:eighths,altSnare:[3,7,11,15]}),r([0,6,8,14],[4,12],eighths,{ride:eighths,altSnare:[3,11],openHat:[14]}),r([0,8,10],[4,12],[0,3,4,7,8,11,12,15],{ride:[0,3,4,7,8,11,12,15],altSnare:[2,7,10,15]})] },
  altRock: { verse:[r([0,8],[4,12],eighths,{openHat:[6,14]}),r([0,6,8,14],[4,12],eighths,{altSnare:[7,15]}),r([0,4,8,12],[4,12],quarters,{crash:[0,8],midTom:[15]})] },
  popPunk: { verse:[r([0,4,8,10,12],[4,12],eighths,{crash:[0,8],openHat:[2,6,10,14]}),r([0,4,8,12],[4,12],eighths,{crash:[0],openHat:[6,14]}),r([0,2,4,8,10,12,14],[4,12],eighths,{crash:[0,8],altSnare:[11]})] },
  rap: { verse:[r([0,8,14],[8],[0,2,4,6,8,10,12,14],{altSnare:[3,7,11,15]}),r([0,6,10],[8],[0,4,8,12],{altSnare:[3,11]}),r([0,3,8,11,14],[8],[0,2,4,6,8,10,12,14],{altSnare:[7,15]})] },
  breakbeat: { verse:[r([0,6,8,14],[4,12],eighths,{altSnare:[3,11]}),r([0,3,6,8,11,14],[4,7,12,15],sixteenths,{altSnare:[2,10]}),r([0,5,8,10,14],[4,12],eighths,{altSnare:[3,7,11,15],openHat:[14]})] },
  psychRock: { verse:[r([0,8,11],[4,12],eighths,{hiTom:[3,7,11,15]}),r([0,6,8],[4,12],[0,4,8,12],{lowTom:[7,15]}),r([0,8],[4,12],eighths,{altSnare:[7,15],crash:[0,8]})] },
  progRock: { verse:[r([0,3,8,11],[4,12],sixteenths,{hiTom:[3,11]}),r([0,6,9,14],[4,12],eighths,{midTom:[7,15]}),r([0,5,8,10,15],[4,12],sixteenths,{altSnare:[3,11],lowTom:[14]})] },
  symphonicRock: {
    verse:[
      r([0,8],[4,12],quarters,{ride:[0,2,4,6,8,10,12,14],lowTom:[0,8]}),
      r([0,4,8,12],[4,12],eighths,{ride:[0,4,8,12]}),
      r([0,8,10],[4,12],quarters,{hiTom:[0,8],lowTom:[12],ride:[0,4,8,12]})
    ],
    chorus:[
      r([0,4,8,10,12],[4,12],eighths,{ride:[0,2,4,6,8,10,12,14],openHat:[6,14]}),
      r([0,6,8,12,14],[4,10,12],eighths,{ride:[0,4,8,12],midTom:[7,15]}),
      r([0,3,8,11,12],[4,12],eighths,{ride:[0,2,4,6,8,10,12,14],hiTom:[15]})
    ],
    bridge:[
      r([0,8],[8],quarters,{lowTom:[0,4,8,12],closedHat:[0,8]}),
      r([0,6],[4,12],eighths,{midTom:[7,15],ride:[0,8]}),
      r([0,8,14],[8],quarters,{hiTom:[7,15],lowTom:[0,8]})
    ]
  },
  grunge: { verse:[r([0,8],[8],quarters,{crash:[0],openHat:[6,14]}),r([0,6,8],[8],eighths,{midTom:[7,15]}),r([0,8,11],[4,12],quarters,{altSnare:[7,15],lowTom:[14]})] },
  indieRock: { verse:[r([0,8],[4,12],quarters,{openHat:[6,14]}),r([0,6,8],[4,12],eighths,{altSnare:[7,15]}),r([0,8],[4,12],quarters,{ride:[2,10]})] },
  nuMetal: { verse:[r([0,3,8,10,14],[8],sixteenths,{altSnare:[7,15],lowTom:[14]}),r([0,6,8,11,14],[8],eighths,{altSnare:[3,7,11,15]}),r([0,2,7,8,13],[4,12],sixteenths,{lowTom:[14],crash:[0]})] },
  gothicRock: { verse:[r([0,8],[4,12],quarters,{ride:[0,4,8,12],lowTom:[8]}),r([0,4,8,12],[4,12],eighths,{ride:[0,4,8,12],midTom:[14]}),r([0,8,10],[4,12],quarters,{ride:eighths,lowTom:[7,15]})] },
  glamRock: {
    // Glam: danceable stomp in the verse, wide singalong lift in the chorus,
    // then a half-time / tom-led contrast in the bridge. Crashes are punctuation.
    verse: [
      r([0,8],[4,12],eighths,{openHat:[6,14]}),
      r([0,6,8],[4,12],eighths,{openHat:[6,14],altSnare:[15]}),
      r([0,8,10],[4,12],quarters,{openHat:[2,6,10,14]})
    ],
    chorus: [
      r([0,4,8,12],[4,12],eighths,{openHat:[2,6,10,14],crash:[0]}),
      r([0,4,6,8,12,14],[4,12],eighths,{openHat:[2,6,10,14],ride:[0,8]}),
      r([0,2,4,8,10,12],[4,12],eighths,{openHat:[2,6,10,14],crash:[0,8]})
    ],
    bridge: [
      r([0,8],[8],quarters,{lowTom:[0,4,8,12],closedHat:[0,8]}),
      r([0,6],[4,12],quarters,{midTom:[7,15],openHat:[14]}),
      r([0,8,14],[8],quarters,{hiTom:[3,7,11,15],lowTom:[0,8]})
    ]
  },
  lofi: { verse:[r([0,10],[4,12],[0,4,8,12],{altSnare:[7,15]}),r([0,6,10],[4,12],[0,2,4,6,8,10,12,14],{altSnare:[3,11]}),r([0,8],[8],[0,4,8,12],{altSnare:[7,15]})] }
};
