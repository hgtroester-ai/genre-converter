// Classic Rock drum-tab bank parsed from the user-provided "drum tabs misc. genres.txt".
// Tab timing is normalized to one 4/4 bar for the existing clip engine. Pattern 67 is labeled 6/8 in the source and retained as a normalized variation.
export interface ClassicRockTabEvent { lane: string; beat: number; velocity: number; }
export interface ClassicRockTab { id: number; title: string; section: "verse" | "chorus" | "bridge" | "fill"; events: ClassicRockTabEvent[]; }
export const CLASSIC_ROCK_TABS: ClassicRockTab[] = [
  {
    "id": 1,
    "title": "Der ultimative Standard-Rock (AC/DC-Stil)",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 2,
    "title": "Der „Four on the Floor“ Rock-Verse",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 3,
    "title": "Off-Beat Bass Drum (Synkopiert)",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 4,
    "title": "Halftime Feel Strophe (Sehr getragen)",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 5,
    "title": "Treibende Achtel-Bass-Drum",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 6,
    "title": "Offene Hi-Hat auf die „4+“ (Akzent vor dem Wechsel)",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "openHat",
        "beat": 3.5,
        "velocity": 92
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 7,
    "title": "Double-Kick am Taktende",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.25,
        "velocity": 90
      }
    ]
  },
  {
    "id": 8,
    "title": "Gedämpfter Rim-Click Verse (Für ruhige Strophen)",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "altSnare",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "altSnare",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 9,
    "title": "Tom-Groove Strophe (Dunkler Sound, z. B. Fleetwood Mac)",
    "section": "verse",
    "events": [
      {
        "lane": "lowTom",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 10,
    "title": "Der Led-Zeppelin-Strophe-Shuffle",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.75,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.25,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.25,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.75,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.75,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 11,
    "title": "Doppel-Schlag auf der Snare (Einfacher Ghostnote-Ersatz)",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 12,
    "title": "Verschobene Bass Drum (Akzent auf „2+“)",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 13,
    "title": "Reiner Hi-Hat & Bass Groove (Snare setzt aus)",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 14,
    "title": "Der Southern-Rock Puls (Lynyrd Skynyrd Feel)",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 15,
    "title": "Minimalist Rock Ballad Verse",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 16,
    "title": "Der „Heavy-Stomp“ (Deep Purple Stil)",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 17,
    "title": "Strophe mit Galopp-Bass-Drum",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.75,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 18,
    "title": "Verzögerter Backbeat",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 19,
    "title": "Tom & Hi-Hat Kombinations-Strophe",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "hiTom",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 20,
    "title": "Doppelter Kick-Puls auf den geraden Zeiten",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 21,
    "title": "Der Psychedelic Rock Verse (Pink Floyd Feel)",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 22,
    "title": "Rollende Achtel auf dem Floor Tom",
    "section": "verse",
    "events": [
      {
        "lane": "lowTom",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 23,
    "title": "Strophe mit offener Hi-Hat auf „2+“",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "openHat",
        "beat": 1.0,
        "velocity": 92
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 24,
    "title": "Der „Driving Hand“ Rhythmus",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.25,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.75,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.25,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.75,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.25,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.75,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.25,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.75,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 25,
    "title": "Akzentuierte Beckenglocke in der Strophe",
    "section": "verse",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 96
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 96
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 26,
    "title": "Der Heartbeat-Groove",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 27,
    "title": "Vorgezogene Takt-Eins",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 28,
    "title": "Der „Lover's Classic Rock“ Puls",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 29,
    "title": "Die nackte Strophe (Bass und Snare pur)",
    "section": "verse",
    "events": [
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 30,
    "title": "Der rollende Takt-Ausklang",
    "section": "verse",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.75,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 31,
    "title": "Standard Ride Chorus",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 32,
    "title": "Offene Hi-Hat „Driving“ Chorus",
    "section": "chorus",
    "events": [
      {
        "lane": "openHat",
        "beat": 0.0,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 0.5,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 1.0,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 1.5,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 2.0,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 2.5,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 3.0,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 3.5,
        "velocity": 92
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 33,
    "title": "Ride-Becken mit konstantem Glocken-Akzent",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 96
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 96
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 96
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 96
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 34,
    "title": "Push-Beat Chorus (Vorzieher auf der Bass Drum)",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.75,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 35,
    "title": "Crash-Becken auf jeder „1“",
    "section": "chorus",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 36,
    "title": "Power-Rock Anthem (Doppel-Bass im Refrain)",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 37,
    "title": "Off-Beat Hi-Hat (Glam Rock, z. B. KISS)",
    "section": "chorus",
    "events": [
      {
        "lane": "openHat",
        "beat": 0.5,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 1.5,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 2.5,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 3.5,
        "velocity": 92
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 38,
    "title": "Southern Rock Vorwärtsdrang-Chorus",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 39,
    "title": "Der „Wall of Sound“ (Beide Hände auf Becken)",
    "section": "chorus",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 40,
    "title": "Ride-Synkope gegen den Beat",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.75,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.25,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.75,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 41,
    "title": "Heavy Half-Time Chorus",
    "section": "chorus",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 42,
    "title": "Chorus mit wirbelndem Ausklang auf 4+",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.25,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.75,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 43,
    "title": "Der Arena-Rock-Puls (Queen-Stil)",
    "section": "chorus",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 44,
    "title": "Wechselspiel Ride-Fläche und Crash",
    "section": "chorus",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 45,
    "title": "Bombastischer Doppel-Snare Chorus",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5333,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0667,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.6,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.1333,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.6667,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.2,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.7333,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0667,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.1333,
        "velocity": 42
      },
      {
        "lane": "snare",
        "beat": 3.2,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.7333,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5333,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.6,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.1333,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.6667,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.7333,
        "velocity": 90
      }
    ]
  },
  {
    "id": 46,
    "title": "Rock-Shuffle Chorus (Toto / Van Halen Feel)",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.75,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.25,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.25,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.75,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.75,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 47,
    "title": "Treibender Dreier-Kick Refrain",
    "section": "chorus",
    "events": [
      {
        "lane": "openHat",
        "beat": 0.0,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 0.5,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 1.0,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 1.5,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 2.0,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 2.5,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 3.0,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 3.5,
        "velocity": 92
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 48,
    "title": "Offenes Ride mit durchgehender Kick",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 49,
    "title": "Der Punk-Rock-Crossover Chorus",
    "section": "chorus",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 50,
    "title": "Synkopierter Ride-Refrain",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 51,
    "title": "Die schleppende Power-Ballade (Aerosmith Stil)",
    "section": "chorus",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.25,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.75,
        "velocity": 90
      }
    ]
  },
  {
    "id": 52,
    "title": "Doppel-Crash Akzent auf 1 und 3",
    "section": "chorus",
    "events": [
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 53,
    "title": "Progressiver Rock-Chorus (Rush Feel)",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 54,
    "title": "Heavy Metal Urtyp-Chorus (Black Sabbath Stil)",
    "section": "chorus",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 55,
    "title": "Weite Sizzle-Fläche mit synkopierter Kick",
    "section": "chorus",
    "events": [
      {
        "lane": "openHat",
        "beat": 0.0,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 0.5,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 1.0,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 1.5,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 2.0,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 2.5,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 3.0,
        "velocity": 92
      },
      {
        "lane": "openHat",
        "beat": 3.5,
        "velocity": 92
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.75,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 56,
    "title": "Der \"Gitarrensolo-Teppich\"",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 57,
    "title": "Akzentuierte Ride-Kante",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 58,
    "title": "Der \"All-In\" Refrain (Maximales Volumen)",
    "section": "chorus",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 0.5333,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.0667,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.6,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.1333,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.6667,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.2,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.7333,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 0.5333,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.0667,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.6,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.1333,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.6667,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.2,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.7333,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5333,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0667,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.6,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.1333,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.6667,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.2,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.7333,
        "velocity": 90
      }
    ]
  },
  {
    "id": 59,
    "title": "Takt-Verschiebung im Chorus",
    "section": "chorus",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 60,
    "title": "Das monumentale Outro-Gewitter",
    "section": "chorus",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 120
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 120
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 61,
    "title": "Tom-Aufbau (Crescendo)",
    "section": "bridge",
    "events": [
      {
        "lane": "hiTom",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "hiTom",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "hiTom",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "hiTom",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "hiTom",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "hiTom",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "hiTom",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "hiTom",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 62,
    "title": "Stop-and-Go Bridge",
    "section": "bridge",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 63,
    "title": "Der Tribal-Groove (Dschungel-Feeling)",
    "section": "bridge",
    "events": [
      {
        "lane": "hiTom",
        "beat": 0.8,
        "velocity": 100
      },
      {
        "lane": "hiTom",
        "beat": 2.4,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 1.6,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 3.2,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.6,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.2,
        "velocity": 90
      }
    ]
  },
  {
    "id": 64,
    "title": "Nur Bass Drum & Handclaps (simuliert auf Snare)",
    "section": "bridge",
    "events": [
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 65,
    "title": "Ride-Only (Völliges Zurücknehmen)",
    "section": "bridge",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 66,
    "title": "Marsch-Rhythmus (Snare-Teppich)",
    "section": "bridge",
    "events": [
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 0.25,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 0.75,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.25,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.75,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 2.25,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 2.75,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 3.75,
        "velocity": 100
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 67,
    "title": "6/8 Takt-Wechsel (Häufig in Classic-Rock-Bridges)",
    "section": "bridge",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.6667,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.3333,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.6667,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.3333,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 68,
    "title": "Akzentuierte Beckenschläge mit Pausen",
    "section": "bridge",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 69,
    "title": "Verzögerter Snare-Einsatz in der Bridge",
    "section": "bridge",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 70,
    "title": "Spannungsaufbau über Achtel-Noten",
    "section": "bridge",
    "events": [
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 0.5333,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.0667,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.6,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.1333,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.6667,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.2,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.7333,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5333,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0667,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.6,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.1333,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.6667,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.2,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.7333,
        "velocity": 90
      }
    ]
  },
  {
    "id": 71,
    "title": "Syncopated Bridge (Gegen den Takt)",
    "section": "bridge",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 72,
    "title": "Sanfter Shaker/Hi-Hat Groove",
    "section": "bridge",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      }
    ]
  },
  {
    "id": 73,
    "title": "Der „We Will Rock You“-Klopfer",
    "section": "bridge",
    "events": [
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 74,
    "title": "Kuhglocken Interlude (Cowbell)",
    "section": "bridge",
    "events": [
      {
        "lane": "ride",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "ride",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 75,
    "title": "Der schleppende Dreier-Tom Beat",
    "section": "bridge",
    "events": [
      {
        "lane": "hiTom",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 76,
    "title": "Hi-Hat Foot Choke (Mit dem Fuß getreten)",
    "section": "bridge",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 77,
    "title": "Linearer Bridge-Groove",
    "section": "bridge",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 78,
    "title": "Wechselspiel High Tom und Floor Tom",
    "section": "bridge",
    "events": [
      {
        "lane": "hiTom",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "hiTom",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "lowTom",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 79,
    "title": "Das psychedelische Becken-Flirren",
    "section": "bridge",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 0.25,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 0.75,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.25,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.75,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.25,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.75,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.25,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.75,
        "velocity": 100
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 80,
    "title": "Halftime Breakdown Bridge",
    "section": "bridge",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 81,
    "title": "Verschobener Rim-Click Rhythmus",
    "section": "bridge",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "altSnare",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "altSnare",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 82,
    "title": "Doppelter Takt-Aussetzer",
    "section": "bridge",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 83,
    "title": "Der schwere Mosh-Puls",
    "section": "bridge",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 84,
    "title": "Sanfter Blues-Rock Walk",
    "section": "bridge",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.75,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.25,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.25,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.75,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.75,
        "velocity": 66
      },
      {
        "lane": "altSnare",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "altSnare",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 85,
    "title": "Ganztaktiger Snare-Build (Vorbereitung aufs Finale)",
    "section": "bridge",
    "events": [
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.25,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.75,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.25,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 86,
    "title": "Der klassische Abwärts-Fill (Über alle Toms)",
    "section": "fill",
    "events": [
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 0.25,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 0.75,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 1.25,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 1.75,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.25,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.75,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.25,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.75,
        "velocity": 90
      }
    ]
  },
  {
    "id": 87,
    "title": "Snare-Roll-Intro (Wirbel)",
    "section": "fill",
    "events": [
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 0.25,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 0.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 0.75,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.25,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 1.75,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 2.25,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 2.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 2.75,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 3.25,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 3.5,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 3.75,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      }
    ]
  },
  {
    "id": 88,
    "title": "Das Triolen-Power-Fill",
    "section": "fill",
    "events": [
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 0.3333,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 0.6667,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 1.3333,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 1.6667,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.3333,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.6667,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.3333,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.6667,
        "velocity": 90
      }
    ]
  },
  {
    "id": 89,
    "title": "Flam-Fill (Gleichzeitiger Doppelanschlag)",
    "section": "fill",
    "events": [
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 120
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 120
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 120
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 120
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 90,
    "title": "Kurzer Akzent-Fill am Taktende",
    "section": "fill",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.25,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.75,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 91,
    "title": "Bass Drum & Cymbal Choke (Abgedämpftes Becken)",
    "section": "fill",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 92,
    "title": "Synkopierter Takt-Unterbrecher",
    "section": "fill",
    "events": [
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 0.75,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.25,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.75,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.25,
        "velocity": 90
      }
    ]
  },
  {
    "id": 93,
    "title": "Funk-Rock-Fill (Sehr knackig und abgehackt)",
    "section": "fill",
    "events": [
      {
        "lane": "snare",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 0.75,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.75,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.75,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.25,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.75,
        "velocity": 90
      }
    ]
  },
  {
    "id": 94,
    "title": "Das „Klassische Triplett“ (Hand-Hand-Fuß)",
    "section": "fill",
    "events": [
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 0.25,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.25,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.5,
        "velocity": 90
      }
    ]
  },
  {
    "id": 95,
    "title": "Linearer Fill (Niemals zwei Trommeln gleichzeitig)",
    "section": "fill",
    "events": [
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 0.25,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 0.75,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 1.25,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.75,
        "velocity": 90
      }
    ]
  },
  {
    "id": 96,
    "title": "Der „Moby Dick“ Bonham-Roll (Trommel-Kaskade)",
    "section": "fill",
    "events": [
      {
        "lane": "closedHat",
        "beat": 0.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 0.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 1.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 2.5,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.0,
        "velocity": 66
      },
      {
        "lane": "closedHat",
        "beat": 3.5,
        "velocity": 66
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.25,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.75,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 97,
    "title": "Das Phil-Collins-Intro (Der legendäre Tom-Einstieg)",
    "section": "fill",
    "events": [
      {
        "lane": "hiTom",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 0.25,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 0.5,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 0.75,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 1.25,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 1.5,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 1.75,
        "velocity": 90
      },
      {
        "lane": "hiTom",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.25,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.75,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.25,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.5,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 3.75,
        "velocity": 90
      },
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      }
    ]
  },
  {
    "id": 98,
    "title": "Doppelter Flam-Wechsel am Taktende",
    "section": "fill",
    "events": [
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 120
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 120
      },
      {
        "lane": "lowTom",
        "beat": 2.0,
        "velocity": 120
      },
      {
        "lane": "lowTom",
        "beat": 3.0,
        "velocity": 120
      },
      {
        "lane": "crash",
        "beat": 3.5,
        "velocity": 100
      }
    ]
  },
  {
    "id": 99,
    "title": "Der „Rimshot-Staccato“ Teaser",
    "section": "fill",
    "events": [
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 120
      },
      {
        "lane": "snare",
        "beat": 0.75,
        "velocity": 120
      },
      {
        "lane": "snare",
        "beat": 1.5,
        "velocity": 120
      },
      {
        "lane": "lowTom",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.25,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.5,
        "velocity": 90
      },
      {
        "lane": "lowTom",
        "beat": 2.75,
        "velocity": 90
      },
      {
        "lane": "crash",
        "beat": 3.0,
        "velocity": 100
      }
    ]
  },
  {
    "id": 100,
    "title": "Der „Big Crash“ Outro-Ausstieg (Das große Finale)",
    "section": "fill",
    "events": [
      {
        "lane": "crash",
        "beat": 0.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 1.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 2.0,
        "velocity": 100
      },
      {
        "lane": "crash",
        "beat": 3.0,
        "velocity": 100
      },
      {
        "lane": "snare",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "snare",
        "beat": 3.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 0.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 1.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 2.0,
        "velocity": 90
      },
      {
        "lane": "kick",
        "beat": 3.0,
        "velocity": 90
      }
    ]
  }
];
