# Funk Drummer Intelligence Audit — 9.5.0

## Purpose
Add a dedicated physical-performance constraint pass after the established Funk drummer patterns and 9.4.8 probability layer. This layer does not author a second groove or duplicate optional-event probability decisions.

## Behavior
- Linear Funk and Jazz Funk enforce single-voice sixteenth-note slots. Existing locked-lane events take precedence; otherwise the strongest authored voice is retained.
- Open-hat events are protected from an immediate same-step closed-hat choke. When both lanes are editable, a quiet closed-hat close is inserted one sixteenth later if no close already follows within that interval.
- Higher Groove Variation can introduce sparse, deterministic breathing gaps with drummer-specific behavior: Ghost Note Funk thins selected closed-hat events, New Orleans Funk occasionally leaves a ghost-note space, Jazz Funk thins selected hat events, and Amen Break Funk uses a rarer hat-dropout cycle.
- Linear Funk does not receive the dropout layer.

## Safety
- Fill sections are excluded.
- Lane locks are respected; locked events win single-voice conflicts.
- The pass adds no fills, no timing offsets, no MIDI remapping and no new probability engine.
- No GUI layout, MIDI map, audio preview, samples, scheduler, or non-Funk genre code was changed.
- The Web Audio preview engine source suffix, including embedded WAV data, remains byte-identical to 9.4.9.

## Verification
- Dedicated runtime test covers open-hat close behavior, lane locks, Linear/Jazz single-voice constraints, drummer-specific breathing gaps, and fill exclusion.
- Full `npm run test:verify` regression suite passed.
- Audio Engine SHA-256: `d7f78bb9bb3ff7eab0b2fd07e2bea000e9ac87d945c415622f25492ebc77fd23`.
- Ableton-host audition remains a user-side musical check.
