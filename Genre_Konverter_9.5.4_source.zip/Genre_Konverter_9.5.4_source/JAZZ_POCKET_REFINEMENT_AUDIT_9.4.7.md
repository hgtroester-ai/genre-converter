# Jazz Pocket Refinement — 9.4.7

## Scope

Builds on 9.4.6. This release refines Jazz articulation only. It does not alter the Jazz style selector, authored tab banks, section structures, fill recipes, GUI geometry, scheduler, MIDI timing anchors, or audio preview implementation.

## Changes

- Swing: stronger ride articulation on the quarter-note pulse, softer triplet subdivisions, and a restrained phrase-end lift.
- Straight Jazz: even eighth-note ride pulse with alternating quarter-note accents.
- Jazz Fusion: firmer ride accents on beats 1 and 3 with restrained subdivisions.
- Existing snare/alt-snare comping and kick hits receive subtle style-dependent velocity contours.
- Generic random ornaments are excluded from Jazz; Groove Variation now affects Jazz through its dedicated deterministic articulation pass.
- Groove Variation at 0% remains unchanged. Fill sections are excluded. Locked lanes are respected. No notes are added or moved by this refinement.

## Regression and release checks

- Full `npm run test:verify` suite passes.
- `verify-947-jazz-pocket.mjs` checks style branches, deterministic behavior, fill exclusion, lane locks, invocation order, metadata and the unchanged audio-preview source hash.
- Audio preview source remains byte-identical to the 9.4.3 reference hash.
- Portable Ableton Extension package built successfully with manifest version 9.4.7.

## Host validation

Automated build and source checks pass. Actual Ableton-host playback and musical audition remain to be confirmed by the user.
