# Song Dramaturgy 9.2.0 — Technical Audit

## Scope
Introduces a song-wide tension-curve layer on top of the existing genre-specific groove engines. It does not replace authored groove banks, drummer profiles, fill generation, or MIDI maps.

## User controls
- Song Arc: Classic Build, Slow Burn, Drop & Return, Cinematic Rise.
- Dramaturgy Strength: 0–100%; blends the selected profile with the previous section-energy curve. At 0%, the previous curve is retained.
- Next Section: Auto, Verse, Chorus, Bridge, Outro, Song End.
- Preferences are retained through the existing settings payload.

## Musical behavior
- Each arc contains a four-point energy curve for Intro, Verse, Chorus, Bridge and Outro.
- The curves are interpolated over 2-, 4- and 8-bar clips.
- The Next Section context shapes only existing notes in the final bar:
  - Chorus: modest anchor/support crescendo.
  - Bridge: support-lane pullback.
  - Verse: restrained landing.
  - Outro/Song End: final-bar taper.
- No MIDI notes are added or removed by the transition layer.
- Locked lanes are untouched.
- Fill clips are excluded from transition shaping.
- A wrapper around the existing generator ensures genre-specific early-return branches receive the transition layer.

## Verification
- Full `npm run test:verify`: 105 PASS, 0 FAIL.
- Song Dramaturgy-specific runtime tests cover four presets, five sections, 2/4/8-bar interpolation, automatic/manual transitions, non-destructive velocity shaping and lane locks.
- Built UI HTML inspected for all controls and runtime markers.
- Portable build completed: single-file runtime bundle.
- ABLX archive integrity check passed.
- Source ZIP integrity check passed.
- Package, manifest, GUI label and embedded ABLX manifest all use version 9.2.0.

## Host testing
Ableton Live was not launched in this build environment. In-host behavior and listening remain to be auditioned in Live.
