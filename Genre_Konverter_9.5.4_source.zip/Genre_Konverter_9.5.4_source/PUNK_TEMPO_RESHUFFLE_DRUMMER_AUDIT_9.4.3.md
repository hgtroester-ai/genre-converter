# Punk Tempo, Re-shuffle Fill Protection & Drummer State Audit — 9.4.3

## Findings in 9.4.2
- Punk Rock's genre definition correctly declared 158 BPM and the UI cap was 160 BPM.
- The selected default Punk drummer (`uk77SkaDrop`) overrode the tempo to 105 BPM both at startup and when selecting that drummer. This was the source of the unexpected Punk tempo.
- Re-shuffle restored a fill only when it had been created through the explicit Regenerate Fill overlay. Genre/section phrase fills generated without that overlay could be regenerated, including Classic Rock's final-bar phrase.
- Classic Rock drummer selection was not persisted in the settings payload, and restored drummer state was not synchronized to all visible drummer selectors.

## Changes in 9.4.3
- Punk Rock now consistently defaults to 158 BPM; its maximum remains 160 BPM.
- Changing the Punk drummer changes only the drummer profile, not the project tempo.
- Re-shuffle preserves the current final-bar phrase for every genre when there is no explicit fill overlay. If an explicit overlay exists, the existing scope-aware overlay restoration remains authoritative.
- Classic Rock drummer selection is now persisted and restored; visible drummer selectors are synchronized with their active profile state.
- Package, manifest and GUI version label are 9.4.3.

## Verification
- Added `verify-943-punk-tempo-reshuffle-drummer-state.mjs`.
- Full automated verification suite and portable build are required before release.
- This is source-level and automated verification; no live Ableton host or listening test is claimed.
