# Jungle Break Reconstruction — 9.1.2

## Rebuild intent
The 9.1.1 implementation was too regular: constant eighth-note hats, fixed backbeat recipes, independent ghost-note grids and repeated straight rolls produced a machine-gun feel rather than a breakbeat.

## 9.1.2 changes
- Replaced the old recipe loop with four-bar phrase banks for Verse, Chorus/Drop and Bridge.
- Each bar has its own kick/snare relationship, ghost-note placement and hat phrasing.
- Closed hats now breathe: varied sparse 16th-note placements replace the constant eighth-note stream.
- Ghost notes are quieter and are placed as phrase pickups/answers rather than a fixed repeating grid.
- Second Pass introduces omissions and selective ghost-note changes; Final Pass adds limited phrase edits and a short ending answer instead of continuous rolls.
- Bridge retains a half-time snare anchor and reduced kick vocabulary.
- Chorus/Bridge keep the Jungle-authored phrase rather than being overwritten by generic section profiles.
- Preview and MIDI export continue to share the same pattern and pocket-processing path.
- Jungle remains at 160 BPM; Drum & Bass remains separately capped at 144 BPM.

## Validation boundary
Automated source tests, portable build and archive integrity are checked for this release. Ableton Live host loading and subjective audio audition cannot be performed in this build environment and must be checked in Live.
