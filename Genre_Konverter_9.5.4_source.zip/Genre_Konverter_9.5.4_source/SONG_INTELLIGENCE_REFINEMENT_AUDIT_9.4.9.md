# Song Intelligence Refinement Audit — 9.4.9

## Responsibilities

- **Song Arc:** selects the section-level energy contour across Intro, Verse, Chorus, Bridge and Outro.
- **Dramaturgy:** controls the strength of that selected contour.
- **Next Section:** shapes only the ending of the current clip toward its intended destination.
- **Section/drummer touch:** applies genre- and drummer-specific articulation to existing notes.
- **Pass Intelligence:** remains a separate, bounded phrase-colour layer and is applied after the shared velocity contour.

## Implementation

The previous separate velocity passes for section energy, drummer touch and next-section transition were consolidated into `applyUnifiedSongPerformanceContour()`. Each unlocked existing MIDI event is evaluated once and clamped once:

`finalVelocity = clamp(round((baseVelocity + energyDelta) * drummerTouch + sectionAccent + transitionDelta), 1, 127)`

The pass does not create, remove, move or remap MIDI notes. Fill sections are excluded. Locked lanes are untouched. The non-destructive `songArcBasePattern` / `songArcAppliedPattern` workflow remains in place so repeated control changes do not compound and manual sequencer edits can become the new base.

Next-section transition response is genre-sensitive: Funk, Jazz, Reggae and Dub receive restrained transition dynamics; Rock, Punk and Heavy styles can use stronger phrase-end lift. The four existing Song Arc presets and manual/automatic Next Section choices remain unchanged.

## Audio Engine protection

The complete source suffix beginning at `// ---- Web Audio preview engine ----` is SHA-256 checked against the 9.4.8 baseline:

`d7f78bb9bb3ff7eab0b2fd07e2bea000e9ac87d945c415622f25492ebc77fd23`

This includes embedded WAV data, Web Audio sample loading, synthesis, preview gain, scheduling and audio snapshot logic. No Audio Engine code was modified.

## Scope exclusions

No GUI layout, audio samples, audio scheduler, MIDI mapping, genre note vocabulary, fill generation, probability engine, or sequencer lane layout changes.
