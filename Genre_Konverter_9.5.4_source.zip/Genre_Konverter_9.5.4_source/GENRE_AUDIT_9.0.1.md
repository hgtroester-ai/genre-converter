# Genre Konverter — Complete Genre & Feature Audit

**Release:** 9.0.1  
**Baseline:** 9.0.0  
**Scope:** Structural source audit, regression suite, genre routing and pattern-bank coverage.  
**Not in scope:** Listening tests inside Ableton Live, sample-by-sample sound verification, or a redesign of existing grooves.

## 1. Executive summary

The 9.0.0 baseline passed its complete automated verification suite. The audit found 25 selectable genre definitions, separate specialized engines for important styles, authored or generated pattern banks, and broad existing coverage for section development, fills, phrase lengths, preview and MIDI routing.

Two stale genre-key references were found and corrected in 9.0.1:

1. `hiphop` was written as `hipHop` in `ARRANGEMENT_FAMILY`, causing Hip-Hop to fall back to the default Rock family for family-based arrangement behavior.
2. Intelligent Verse Variation classified `punk` and `rapRock`, although the selectable genre keys are `punkRock` and there is no `rapRock` genre. The list now uses the actual `punkRock` key and no longer contains the unsupported key.

## 2. Genre and tab-bank coverage

- **25** selectable genre definitions in `src/patterns.ts`.
- **20** generated tab banks, each with **12 Verse / 8 Chorus / 6 Bridge / 6 Fill** entries (32 per genre; 640 generated entries total).
- **Classic Rock:** separate authored bank with 100 entries — 30 Verse, 30 Chorus, 25 Bridge, 15 Fill.
- **Funk:** dedicated engine and authored tab collection — 197 entries: 167 Verse, 12 Chorus, 8 Bridge, 10 Fill.
- **Reggae:** dedicated styles/engine and authored tab collection — 116 entries: 77 Verse, 17 Chorus, 6 Bridge, 16 Fill.
- **Punk Rock:** dedicated drummer options and authored tab collection — 92 entries: 59 Verse, 21 Chorus, 2 Bridge, 10 Fill.
- **Jazz:** dedicated triplet-oriented engine and authored tab collection — 114 entries: 104 Verse, 0 Chorus, 1 Bridge, 9 Fill. Jazz Chorus deliberately reuses the authored Verse bank as a fallback and then receives the Chorus section treatment.
- **Ska:** generated shared tab bank plus five specialized drummer profiles: Two Tone Groove, Nutty Sound, DanceBEATZ, Power-Ska and Jamaican First Wave.

The bank audit also checks lane names, beat positions within a 4/4 bar and MIDI velocity range (1–127).

## 3. Functional areas already covered by regression tests

- Genre selection and initialization safeguards.
- Verse, Chorus and Bridge section engines, section contrast and energy arcs.
- First / Second / Final Pass development and phrase-level repetition variation.
- 2-, 4- and 8-bar phrase handling in specialized profiles.
- Groove Variation, Re-shuffle, Fill Scope, Fill Intensity and Regenerate Fill.
- Genre-specific fill grammar and final-bar landing behavior.
- Lane locks and protected style anchors in selected specialized engines.
- GM and alternate drum-map paths, clip targeting, preview samples and velocity layers.
- Release metadata and package build checks.

## 4. Findings and follow-up priorities

### Addressed in 9.0.1

- Hip-Hop arrangement-family key corrected.
- Intelligent Verse Variation stale Punk key corrected.
- Added `verify-901-genre-audit.mjs` to validate all 25 genre keys, family mapping, generated-bank structure, special-bank coverage and MIDI-safe tab events.
- Reconciled the verification command list: all 93 test files are included exactly once; two previously omitted tests were restored and a duplicate command was removed.

### Follow up in the next development stages

1. **Jazz content depth:** author a true Jazz Chorus bank and expand the Bridge from one authored tab into several distinct treatments. The current Verse-bank Chorus fallback remains functional, but is not as rich as the other section banks.
2. **Cross-genre musical isolation:** inspect generic Groove Variation ornaments and shared fill builders for accidental stylistic notes in specialized profiles (especially First Wave Ska, Jazz, Reggae and Dub).
3. **Pass consistency:** exercise First / Second / Final Pass for every specialized profile at 2/4/8 bars, including lane-lock combinations and repeated regeneration.
4. **MIDI map audit:** verify every lane against GM, EZdrummer 3, Battery, Kontakt and Drumlogue mappings, including alternate snare / side-stick behavior.
5. **Tempo and UI audit:** check default tempo, sensible limits, control visibility and saved-setting restoration for every genre and sub-profile.
6. **Live verification:** perform actual Ableton Live 12 launch, clip insertion, preview playback and listening checks on the user's system. Automated source tests cannot substitute for this.

## 5. Release validation

The release is considered technically validated only after all 93 test files in the full `npm run test:verify` suite, portable `.ablx` build, metadata checks and archive-integrity checks pass. Ableton Live launch and listening are not claimed as completed by this report.
