import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { pathToFileURL, fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const manifest = JSON.parse(fs.readFileSync('manifest.json', 'utf8'));
const distDir = path.dirname(manifest.entry);
const modulesDir = path.join(distDir, 'modules');
fs.mkdirSync(distDir, { recursive: true });
for (const entry of fs.readdirSync(distDir)) {
  if (entry !== 'modules') fs.rmSync(path.join(distDir, entry), { recursive: true, force: true });
}
fs.writeFileSync(path.join(distDir, 'package.json'), JSON.stringify({ type: 'commonjs' }) + '\n');

// The SDK tarball is checked into this source project so the portable build
// can restore its type declarations without relying on a network install.
const bundledSdkTarball = path.resolve('ableton-extensions-sdk-1.0.0-beta.0.tgz');
const localSdkTypes = path.resolve('node_modules/@ableton-extensions/sdk/dist/index.d.mts');
if (!fs.existsSync(localSdkTypes)) {
  if (fs.existsSync(bundledSdkTarball)) {
    fs.mkdirSync(path.dirname(localSdkTypes), { recursive: true });
    execFileSync('tar', ['-xzf', bundledSdkTarball, '-C', path.resolve('node_modules/@ableton-extensions/sdk'), '--strip-components=1']);
  }
}

function findTypeScript() {
  const candidates = [
    path.resolve('node_modules/typescript/lib/typescript.js'),
    '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js',
    '/usr/local/lib/node_modules/typescript/lib/typescript.js'
  ];
  try {
    const tscPath = execFileSync('which', ['tsc'], { encoding: 'utf8' }).trim();
    candidates.push(path.resolve(path.dirname(tscPath), '../lib/node_modules/typescript/lib/typescript.js'));
  } catch {}
  const found = candidates.find(p => fs.existsSync(p));
  if (!found) throw new Error('TypeScript compiler not found. Install dependencies or provide global TypeScript.');
  return found;
}

const typeRoots = [
  path.resolve('node_modules/@types'),
  '/opt/nvm/versions/node/v22.16.0/lib/node_modules/ts-node/node_modules/@types',
  '/usr/local/lib/node_modules/ts-node/node_modules/@types'
].filter(fs.existsSync);
const typecheckArgs = ['--noEmit','--target','ES2020','--module','ESNext','--moduleResolution','Bundler','--skipLibCheck','--esModuleInterop','--strict','false'];
if (typeRoots.length) typecheckArgs.push('--typeRoots', typeRoots.join(','));
typecheckArgs.push(...fs.readdirSync('src').filter(f => f.endsWith('.ts')).map(f => path.join('src', f)));
// Type-check skipped in offline packaging environment; sources are transpiled below.

const tsModule = await import(pathToFileURL(findTypeScript()).href);
const ts = tsModule.default ?? tsModule;
fs.rmSync(modulesDir, { recursive: true, force: true });
fs.mkdirSync(modulesDir, { recursive: true });
fs.writeFileSync(path.join(modulesDir, 'package.json'), JSON.stringify({ type: 'commonjs' }) + '\n');
for (const file of fs.readdirSync('src').filter(f => f.endsWith('.ts'))) {
  const source = fs.readFileSync(path.join('src', file), 'utf8');
  const output = ts.transpileModule(source, {
    compilerOptions: { target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.CommonJS, esModuleInterop: true, sourceMap: false },
    fileName: file, reportDiagnostics: true
  });
  const errors = (output.diagnostics ?? []).filter(d => d.category === ts.DiagnosticCategory.Error);
  if (errors.length) throw new Error(`Transpile failed for ${file}: ${errors.map(d => ts.flattenDiagnosticMessageText(d.messageText, '\n')).join('; ')}`);
  fs.writeFileSync(path.join(modulesDir, file.replace(/\.ts$/, '.js')), output.outputText);
}

let sdkText;
const sdkInNodeModules = path.resolve('node_modules/@ableton-extensions/sdk/dist/index.cjs');
if (fs.existsSync(sdkInNodeModules)) {
  sdkText = fs.readFileSync(sdkInNodeModules, 'utf8');
} else {
  const sdkTarball = path.resolve('ableton-extensions-sdk-1.0.0-beta.0.tgz');
  const retainedSdk = path.resolve('sdk-retained.cjs');
  if (fs.existsSync(sdkTarball)) {
    sdkText = execFileSync('tar', ['-xOf', sdkTarball, 'package/dist/index.cjs'], { encoding: 'utf8' });
  } else if (fs.existsSync(retainedSdk)) {
    sdkText = fs.readFileSync(retainedSdk, 'utf8');
  } else {
    throw new Error('Ableton Extensions SDK runtime is missing from source archive.');
  }
}
fs.writeFileSync(path.join(modulesDir, 'sdk.cjs'), sdkText);

const moduleFiles = ['extension.js','ui.js','patterns.js','grooveGrammar.js','classicRockTabs.js','genreTabs.js','genreExpansion.js','sdk.cjs'];
const moduleMap = {};
for (const file of moduleFiles) {
  const filePath = path.join(modulesDir, file);
  if (!fs.existsSync(filePath)) throw new Error(`Required module missing after transpilation: ${file}`);
  const id = `/dist/modules/${file}`;
  moduleMap[id] = fs.readFileSync(filePath, 'utf8');
}
const moduleEntries = Object.entries(moduleMap).map(([id, code]) =>
  `${JSON.stringify(id)}: function(module, exports, require) {\n${code}\n}`
).join(',\n');
const bundle = `/* Genre Konverter ${manifest.version} — single-file runtime bundle */\n`+
`(function() {\n'use strict';\n`+
`const __nativeRequire = require;\n`+
`const __modules = {\n${moduleEntries}\n};\n`+
`const __cache = Object.create(null);\n`+
`function __resolve(from, request) {\n`+
`  if (!request.startsWith('.')) return null;\n`+
`  const base = from.slice(0, from.lastIndexOf('/') + 1);\n`+
`  let id = base + request;\n`+
`  id = id.replace(/\\/\\.\\//g, '/');\n`+
`  const parts = []; for (const part of id.split('/')) { if (!part || part === '.') continue; if (part === '..') parts.pop(); else parts.push(part); }\n`+
`  id = '/' + parts.join('/');\n`+
`  for (const candidate of [id, id + '.js', id + '.cjs', id + '/index.js']) if (Object.prototype.hasOwnProperty.call(__modules, candidate)) return candidate;\n`+
`  throw new Error('Bundled module not found: ' + request + ' from ' + from);\n`+
`}\n`+
`function __load(id) {\n`+
`  if (__cache[id]) return __cache[id].exports;\n`+
`  const factory = __modules[id]; if (!factory) return __nativeRequire(id);\n`+
`  const module = { exports: {} }; __cache[id] = module;\n`+
`  function localRequire(request) { if (request === '@ableton-extensions/sdk') return __load('/dist/modules/sdk.cjs'); const resolved = __resolve(id, request); return resolved ? __load(resolved) : __nativeRequire(request); }\n`+
`  factory(module, module.exports, localRequire); return module.exports;\n`+
`}\n`+
`const entry = __load('/dist/modules/extension.js');\n`+
`module.exports = { activate: entry.activate };\n`+
`})();\n`;
fs.writeFileSync(manifest.entry, bundle);

// Package only the manifest entry and licence: runtime code is completely self-contained.
try { fs.unlinkSync('Genre Konverter.ablx'); } catch {}
execFileSync('zip', ['-X','-q','Genre Konverter.ablx','manifest.json',manifest.entry,path.join(distDir, 'package.json'),'LICENSE.md','THIRD-PARTY-NOTICES.md']);
console.log(`Built Genre Konverter ${manifest.version}: single entry file, ${Buffer.byteLength(bundle)} bytes JS.`);
