# Jungle Sequencer Repair — 9.1.4

## Root cause
The Jungle lane insertion helper referenced `phraseBar`, a `const` declared inside the subsequent bar loop. JavaScript block scope meant the helper could not see that variable. The first call to the helper therefore threw a `ReferenceError` before Jungle lane events could be inserted. Because the pattern generator initializes/clears the lane arrays before dispatching to the Jungle branch, Re-shuffle could leave the sequencer empty. The fill button used a separate fill-generation path, explaining why it could still respond.

## Fix
- `phraseBar` is now passed explicitly into the Jungle insertion helper for each lane.
- Kick, snare, ghost snare, closed hat, open hat and chorus crash insertion all receive the active phrase-bar index.
- GUI version tag, package version and extension manifest now consistently report 9.1.4.
- No non-Jungle generator or MIDI mapping was changed.

## Runtime regression test
`tests/verify-jungle-sequencer-914.mjs` executes the actual Jungle branch in an isolated harness. It covers:
- Verse, Chorus and Bridge
- 2, 4 and 8 bars
- First, Second and Final Pass
- non-empty kick/snare/ghost/closed-hat lanes
- event positions within the selected loop length
- MIDI-safe velocities (1–127)

## Validation
- `npm run build:portable`: successful
- `npm run test:verify`: successful, including the runtime Jungle matrix above
- ABLX archive integrity and embedded manifest checked after packaging

Ableton Live host loading and audio audition still require a test in the user's Live installation.
