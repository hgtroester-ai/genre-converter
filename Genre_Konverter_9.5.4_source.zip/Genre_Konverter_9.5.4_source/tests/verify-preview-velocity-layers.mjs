import fs from 'node:fs';
import assert from 'node:assert/strict';
const root = new URL('../', import.meta.url);
const ui = fs.readFileSync(new URL('src/ui.ts', root), 'utf8');
const manifest = JSON.parse(fs.readFileSync(new URL('manifest.json', root), 'utf8'));
assert.equal(manifest.version, '9.5.4');
assert.match(ui, /return v <= 50 \? 0 : v <= 80 \? 1 : v <= 105 \? 2 : 3/);
assert.match(ui, /const segment = buffer\.duration \/ 4/);
assert.match(ui, /src\.start\(t, offset, Math\.max\(0\.04, segment - 0\.012\)\)/);
for (const name of ['CRASH','RIDE','KICK','SNARE','RIM','LOWTOM','MIDTOM','HITOM','CLOSEDHAT','OPENHAT']) {
  const match = ui.match(new RegExp(`const ${name}_SAMPLE_B64 = "([^"]+)"`));
  assert.ok(match && match[1].length > 1000, `${name} sample embedded`);
}
assert.match(ui, /const PREVIEW_LAYER_GAIN = \{/);
for (const lane of ['kick','snare','altSnare','hiTom','midTom','lowTom','closedHat','openHat','crash','ride']) {
  assert.match(ui, new RegExp(`${lane}:\\s*\\[[0-9., \]+\\]`), `${lane} has four calibrated layer gains`);
}
assert.match(ui, /const PREVIEW_TRIM = \{/);
assert.match(ui, /playKick\(t, g, v\)/);
assert.match(ui, /playSnare\(t, g, v\)/);
console.log('PASS: ten recorded preview instruments, four velocity slices (1–50/51–80/81–105/106–127), and per-instrument, per-layer RMS calibration with preserved velocity contour.');

assert.match(ui, /function previewVelocityGain\(velocity, layer\)/);
assert.match(ui, /const referenceVelocity = \[25, 65, 93, 116\]\[layer\]/);
