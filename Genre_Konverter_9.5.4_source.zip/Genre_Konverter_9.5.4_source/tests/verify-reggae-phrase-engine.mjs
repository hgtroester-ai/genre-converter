import fs from 'node:fs';
import assert from 'node:assert/strict';
const source = fs.readFileSync('src/ui.ts', 'utf8');
const start = source.indexOf('const REGGAE_GROOVE_BANKS = {');
const end = source.indexOf('function generateBankedGenrePattern', start);
assert.ok(start >= 0 && end > start, 'dedicated Reggae groove engine exists');
const engine = source.slice(start, end);
for (const style of ['oneDrop','rockers','steppers']) assert.match(engine, new RegExp(style + ': \\['), `${style} groove bank exists`);
assert.match(engine, /const recipeIndex = \(reggaeRecipeCycle[\s\S]*?const recipe = bank\[recipeIndex\]/,
  'Re-shuffle cycles through a stable recipe selection independent of repetition pass');
assert.match(engine, /const phraseBar = bar % 4/,
  'four-bar phrase roles repeat coherently inside eight-bar clips');
assert.match(engine, /pass === 2[\s\S]*?pass === 3/,
  'Second and Final Pass receive controlled phrase changes');
assert.match(engine, /REGGAE_DRUMMER_PROFILES[\s\S]*?drummer\.kick[\s\S]*?drummer\.rim[\s\S]*?drummer\.hat/,
  'drummer profiles influence kick, rim and cymbal articulation');
console.log('PASS: Reggae phrase engine uses a stable selected recipe with 4-bar phrase development, repetition variation and drummer interpretation.');
