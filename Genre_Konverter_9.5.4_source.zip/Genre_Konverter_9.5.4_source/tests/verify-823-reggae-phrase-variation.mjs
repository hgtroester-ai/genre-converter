import assert from 'node:assert/strict';
import fs from 'node:fs';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
assert.equal(manifest.version, '9.5.4');
assert.equal(pkg.version, '9.5.4');
assert.match(ui, /Version 9\.5\.4/);
assert.match(ui, /Reggae has its own phrase language/);
assert.match(ui, /Second Pass: a light late-bar hat pickup/);
assert.match(ui, /Final Pass: one more phrase-end response/);
for (const drummer of ['rootsKeeper','deepOneDrop','dubExplorer','rockersDriver','steppersPulse','vintageReggae']) {
  assert.match(ui, new RegExp(`reggaeDrummer === "${drummer}"`), `${drummer} has an authored signature`);
}
assert.match(ui, /Safety invariant: One Drop has no kick on beat 1/);
assert.match(ui, /if \(currentGenre\.key === "reggae"\)/);
console.log('PASS: 8.3.0 adds deterministic Reggae phrase-pass changes and six drummer signatures while retaining One Drop protection.');
