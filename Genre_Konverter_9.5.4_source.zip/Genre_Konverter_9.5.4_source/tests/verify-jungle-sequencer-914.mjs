import fs from 'node:fs';
import assert from 'node:assert/strict';
const source = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const start = source.indexOf('// Jungle Sequencer Repair 9.1.4');
const end = source.indexOf('// Genre Expansion 7.9.3', start);
assert.ok(start >= 0 && end > start, 'Jungle sequencer block must exist');
const block = source.slice(start, end);
assert.match(block, /const add = \(lane, steps, baseVelocity, accents = \[\], phraseBar = 0\)/, 'phraseBar must be an explicit helper argument');
assert.match(block, /const barShape = \[3, -3, 1, 5\]\[phraseBar\]/, 'barShape uses the explicitly passed phraseBar parameter');
for (const lane of ['kick','snare','altSnare','closedHat','openHat']) {
  assert.match(block, new RegExp(`add\\("${lane}",[^\\n]*phraseBar\\)`), `${lane} insertion must receive phraseBar`);
}
assert.match(block, /for \(let bar = 0; bar < barsCount; bar\+\+\)/, 'selected 2/4/8 bar loop must be honored');
assert.match(block, /const recipe = bank\[phraseBar\]/, 'each bar must select its authored phrase recipe');

// Execute the real Jungle branch in isolation. This catches runtime errors
// (including the previous out-of-scope phraseBar ReferenceError) and verifies
// actual lane insertion for 2, 4 and 8 bars in Verse, Chorus and Bridge.
const lanes = ['kick','snare','altSnare','hiTom','midTom','lowTom','closedHat','openHat','crash','ride'].map(key => ({key}));
for (const section of ['verse','chorus','bridge']) {
  for (const bars of [2,4,8]) {
    for (const pass of [1,2,3]) {
      const pattern = Object.fromEntries(lanes.map(({key}) => [key, []]));
      const run = new Function('currentGenre','currentSection','barsCount','sectionPass','lockedLanes','currentPattern','LANES','beatsPerBar','applySectionProfile', `${block}\nreturn currentPattern;`);
      run({key:'jungle'}, section, bars, pass, new Set(), pattern, lanes, () => 4, () => {});
      const result = pattern;
      for (const lane of ['kick','snare','altSnare','closedHat']) {
        assert.ok(result[lane].length > 0, `${section}/${bars} bars/pass ${pass}: ${lane} lane must contain notes`);
      }
      for (const {key} of lanes) {
        for (const [beat, velocity] of result[key]) {
          assert.ok(Number.isFinite(beat) && beat >= 0 && beat < bars * 4, `${section}/${bars} bars: ${key} event must be inside the selected sequence`);
          assert.ok(Number.isInteger(velocity) && velocity >= 1 && velocity <= 127, `${key} velocity must be MIDI-safe`);
        }
      }
      assert.ok(result.kick.length >= bars * 2, `${section}/${bars} bars: kick events should cover the full sequence`);
    }
  }
}
console.log('PASS: Jungle runtime generation inserts valid MIDI events for Verse/Chorus/Bridge, 2/4/8 bars and First/Second/Final Pass; phraseBar scope regression fixed.');
