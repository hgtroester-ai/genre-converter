import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
assert.match(ui, /#sliders\s*\{[^}]*display:\s*grid;[^}]*repeat\(5,\s*minmax\(0,\s*1fr\)\)/s, 'five controls share one compact row');
for (const id of ['vol','pocket','swing','fillIntensity','grooveVariation']) {
  assert.match(ui, new RegExp(`<input id="${id}" type="range"`), `${id} is a range slider`);
}
assert.match(ui, /<label>Groove Variation <span id="grooveVariationVal">20%<\/span><\/label>/, 'Groove Variation label and value remain visible');
assert.doesNotMatch(ui, /grooveVariationKnob/, 'old Groove Variation rotary control is removed');
assert.match(ui, /slider\.addEventListener\("input"/, 'slider value updates while dragging');
assert.match(ui, /slider\.addEventListener\("change"[\s\S]*?generatePattern\(\);\s*restoreFillOverlay\(\);\s*renderGrid\(\);/, 'existing variation engine refreshes once on commit and restores the fill overlay');
console.log('PASS: Groove Variation is a fifth horizontal slider; original generation behavior retained.');
