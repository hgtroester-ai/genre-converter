import { normalizeAudioEngine } from './audio-engine-fingerprint.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const ui = fs.readFileSync('src/ui.ts', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const manifest = JSON.parse(fs.readFileSync('manifest.json', 'utf8'));
assert.equal(pkg.version, '9.5.4');
assert.equal(manifest.version, '9.5.4');
assert.match(ui, /id="versionTag">Version 9\.5\.4<\/div>/);
const layers = ui.slice(ui.indexOf('function applySongArcLayers()'), ui.indexOf('// Pass Intelligence 9.4.3'));
assert.match(layers, /currentPattern = clonePatternData\(songArcBasePattern\)/);
assert.match(layers, /applyUnifiedSongPerformanceContour\(\)/);
assert.match(layers, /applyPassIntelligence\(\)/);
assert.equal((layers.match(/applyUnifiedSongPerformanceContour\(\)/g) || []).length, 1);
assert.doesNotMatch(layers, /applySectionEnergyArc|applySectionDrummerInteraction|applySongDramaturgyTransition/,
  'legacy velocity layers cannot run a second time');
const unified = ui.slice(ui.indexOf('function applyUnifiedSongPerformanceContour()'), ui.indexOf('// Pass Intelligence 9.4.3'));
assert.match(unified, /if \(!barsCount \|\| currentSection === "fill"\) return/);
assert.match(unified, /if \(lockedLanes\.has\(lane\.key\)\) continue/);
assert.match(unified, /energyDelta = sectionEnergyVelocityDelta/);
assert.match(unified, /touch = sectionDrummerVelocityShape/);
assert.match(unified, /transitionDelta = songTransitionVelocityDelta/);
assert.match(unified, /Math\.max\(1, Math\.min\(127, Math\.round\(combined\)\)\)/);
assert.doesNotMatch(unified, /\.push\(\[/, 'song performance contour never creates MIDI notes');
for (const family of ['funk','blues','rock','heavy','punk','breaks','hiphop','reggae','dub','jazz']) {
  assert.match(ui, new RegExp('\\b' + family + ':\\s*0?\\.?\\d+'), `genre response profile missing ${family}`);
}
const audioMarker = '// ---- Web Audio preview engine ----';
const audioHash = crypto.createHash('sha256').update(normalizeAudioEngine(ui.slice(ui.indexOf(audioMarker)))).digest('hex');
assert.equal(audioHash, '4ee4780c679cac8bfa7a5d007863008bb4853e1a99a30a2519d5a54f6bdd0776',
  'Audio Engine must remain byte-identical to the 9.4.8 baseline');
console.log('PASS 9.5.0: Song Intelligence is single-pass, bounded, lane-lock-aware, non-destructive; Audio Engine SHA-256 unchanged.');
