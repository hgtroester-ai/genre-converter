import fs from 'node:fs';
import assert from 'node:assert/strict';
const source = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
for (const name of ['altRockDropFill', 'skaOffbeatFill', 'hiphopPocketFill']) {
  assert.match(source, new RegExp(`function ${name}\\(big\\)`), `${name} exists`);
}
assert.match(source, /altRock:.*altRockDropSmall/s);
assert.match(source, /ska:\s*\{ bar4: \[\{ custom: "skaOffbeatSmall"/);
assert.match(source, /hiphop:\s*\{ bar4: \[\{ custom: "hiphopPocketSmall"/);
assert.match(source, /altRockDropSmall: \(\) => altRockDropFill\(false\)/);
assert.match(source, /skaOffbeatBig: \(\) => skaOffbeatFill\(true\)/);
assert.match(source, /hiphopPocketBig: \(\) => hiphopPocketFill\(true\)/);
console.log('PASS: Alternative Rock, Ska and Hip-Hop have dedicated small/big fills with genre-specific rhythmic intent.');
