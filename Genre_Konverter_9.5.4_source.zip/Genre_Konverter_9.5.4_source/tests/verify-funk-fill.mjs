import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const src = fs.readFileSync('src/ui.ts', 'utf8');
const match = src.match(/const FUNK_FILL_PATTERNS = (\[[\s\S]*?\n\]);\nfunction funkFillGrammar/);
assert.ok(match, 'Funk fill pattern bank exists');
const patterns = vm.runInNewContext(`(${match[1]})`);
assert.equal(patterns.length, 7, "seven Funk fill variations are present");
const lanes = new Set(['kick','snare','altSnare','hiTom','midTom','lowTom','closedHat','openHat','crash','ride']);
for (const [index, pattern] of patterns.entries()) {
  assert.ok(pattern.some(([lane, step]) => lane === 'kick' && step === 0), `pattern ${index + 1} anchors the downbeat with kick`);
  for (const [lane, step, velocity] of pattern) {
    assert.ok(lanes.has(lane), `pattern ${index + 1} uses known lane ${lane}`);
    assert.ok(Number.isInteger(step) && step >= 0 && step <= 15, `pattern ${index + 1} uses 16-step index ${step}`);
    assert.ok(Number.isFinite(velocity) && velocity >= 1 && velocity <= 127, `pattern ${index + 1} velocity ${velocity} is MIDI-safe`);
  }
}
assert.ok(patterns.some(pattern => pattern.some(([lane, step]) => lane === 'openHat' && step === 3)));
assert.ok(patterns.some(pattern => pattern.some(([lane, step]) => lane === 'closedHat' && step === 4)), 'open hat is followed by a closed-hat choke');
assert.ok(patterns.some(pattern => pattern.some(([lane, step, velocity]) => lane === 'snare' && velocity <= 40)), 'ghost notes are quiet');
assert.match(src, /funkSmall: \(\) => funkFillGrammar\(false\)/);
assert.match(src, /funkBig: \(\) => funkFillGrammar\(true\)/);
console.log('PASS: Funk fill patterns use valid 16-step positions, MIDI-safe velocities, downbeat kick, ghost notes and hat choke.');
