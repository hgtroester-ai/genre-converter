import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
assert.match(ui, /const g = laneVol \* \(PREVIEW_TRIM\[lane\] \|\| 1\) \* genreMix;/);
assert.match(ui, /const velocityGain = previewVelocityGain\(velocity, layer\);/);
assert.match(ui, /const requestedGain = g \* PREVIEW_OUTPUT_BOOST \* layerGain \* velocityGain;/);
assert.match(ui, /function previewVelocityGain\(velocity, layer\)/);
assert.match(ui, /Math\.pow\(v \/ referenceVelocity, 1\.7\)/);
console.log('PASS: preview reproduces continuous MIDI velocity dynamics within the selected sample layer; MIDI generation is not modified.');
