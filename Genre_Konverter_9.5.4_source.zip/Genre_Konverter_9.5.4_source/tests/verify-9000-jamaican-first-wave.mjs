import fs from 'node:fs';
import assert from 'node:assert/strict';
import vm from 'node:vm';
const ui=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url)));
const manifest=JSON.parse(fs.readFileSync(new URL('../manifest.json',import.meta.url)));
assert.equal(pkg.version,'9.5.4');assert.equal(manifest.version,'9.5.4');
assert.match(ui,/Version 9\.5\.4/);
assert.match(ui,/<option value="jamaicanFirstWave">Jamaican Ska · First Wave<\/option>/);
assert.doesNotMatch(ui,/Jamaican Ska · in Entwicklung/);
const a=ui.indexOf('skaDrummer === "jamaicanFirstWave" && currentSection !== "fill"');
const b=ui.indexOf('skaDrummer === "twoToneGroove" && currentSection !== "fill"',a);
assert.ok(a>=0&&b>a,'dedicated Jamaican First Wave engine exists');
const branch=ui.slice(a,b);
for(const section of ['verse','chorus','bridge'])assert.ok(branch.includes(`currentSection === "${section}"`));
assert.match(branch,/q\+2\/3/,'triplet swing subdivision is present');
assert.match(branch,/altSnare:\s*\[\[1,104\],\[3,108\]\]/,'rim-click backbeat on beats 2 and 4');
assert.match(branch,/kick:\s*\[\[0,78\],\[2,70\]\]/,'restrained kick on 1 and 3');
assert.match(branch,/applyJamaicanSkaShuffleVariation\(\)/);assert.match(branch,/applyJamaicanSkaPassDevelopment\(\)/);
assert.match(ui,/function buildJamaicanSkaFill\(pass, context\)/);
assert.match(ui,/skaDrummer === "jamaicanFirstWave"\) \{\s*const built = buildJamaicanSkaFill/);
assert.match(ui,/skaDrummer === "jamaicanFirstWave" \? "125"/);
const laneKeys=['kick','snare','altSnare','hiTom','midTom','lowTom','closedHat','openHat','crash','ride'];
const passFn=ui.slice(ui.indexOf('function applyJamaicanSkaPassDevelopment()'),ui.indexOf('function applyJamaicanSkaShuffleVariation()'));
const shuffleFn=ui.slice(ui.indexOf('function applyJamaicanSkaShuffleVariation()'),ui.indexOf('function buildJamaicanSkaFill'));
function seeded(section,bars){const p=Object.fromEntries(laneKeys.map(k=>[k,[]]));for(let bar=0;bar<bars;bar++){for(let q=0;q<4;q++){p.closedHat.push([bar*4+q,76],[bar*4+q+2/3,66]);}p.kick.push([bar*4,78],[bar*4+2,70]);p.altSnare.push([bar*4+1,104],[bar*4+3,108]);if(section==='chorus')p.ride.push([bar*4,90],[bar*4+2/3,80]);}return p;}
const count=p=>Object.values(p).reduce((n,x)=>n+x.length,0);
for(const section of ['verse','chorus','bridge'])for(const bars of [4,8]){const first=seeded(section,bars),second=seeded(section,bars),final=seeded(section,bars),common={currentGenre:{key:'ska'},skaDrummer:'jamaicanFirstWave',currentSection:section,barsCount:bars,lockedLanes:new Set(),LANES:laneKeys.map(key=>({key})),beatsPerBar:()=>4};vm.runInNewContext(passFn+';applyJamaicanSkaPassDevelopment();',{...common,currentPattern:second,sectionPass:2});vm.runInNewContext(passFn+';applyJamaicanSkaPassDevelopment();',{...common,currentPattern:final,sectionPass:3});assert.ok(count(second)>count(first),`${section} ${bars}-bar Second Pass evolves`);assert.ok(count(final)>count(first),`${section} ${bars}-bar Final Pass evolves`);}
for(const section of ['verse','chorus','bridge']){const sig=[];for(let cycle=1;cycle<=3;cycle++){const pattern=seeded(section,8);vm.runInNewContext(shuffleFn+';applyJamaicanSkaShuffleVariation();',{currentGenre:{key:'ska'},skaDrummer:'jamaicanFirstWave',currentSection:section,barsCount:8,beatsPerBar:()=>4,lockedLanes:new Set(),currentPattern:pattern,LANES:laneKeys.map(key=>({key})),jamaicanSkaShuffleCycle:cycle});sig.push(JSON.stringify(pattern));}assert.equal(new Set(sig).size,3,`${section} Re-shuffle variants differ`);}
console.log('PASS 9.0.0 Jamaican First Wave: triplet shuffle, rim-click backbeat, restrained bass, 4/8-bar pass evolution and distinct Re-shuffle recipes');
