import fs from 'node:fs';
import assert from 'node:assert/strict';
const expansion = fs.readFileSync(new URL('../src/genreExpansion.ts', import.meta.url), 'utf8');
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
for (const key of ['reggae','dub','ska','hiphop','jungle','drumAndBass']) {
  assert.match(expansion, new RegExp(`\\b${key}:\\s*\\{`), `${key} has a dedicated expansion bank`);
}
for (const key of ['hardRock','bluesRock','altRock','popPunk','rap','breakbeat','psychRock','progRock','symphonicRock','grunge','indieRock','nuMetal','gothicRock','glamRock','lofi']) {
  assert.match(expansion, new RegExp(`\\b${key}:\\s*\\{`), `${key} has audit-driven additions`);
}
assert.match(ui, /const expansion = GENRE_EXPANSION\[currentGenre\.key\]/, 'expansion bank is wired into generation');
assert.match(ui, /const recipe = pick\(phraseBank/, 'one coordinated recipe is selected for a phrase');
assert.match(ui, /currentSection !== "bridge"\) applySectionProfile\(\)/, 'authored expanded bridge is not overwritten by generic bridge rules');
assert.equal(manifest.version, '9.5.4');
// Validate all declared recipe step arrays stay inside the 16-step 4/4 grid.
const arrays = [...expansion.matchAll(/(?:kick|snare|altSnare|midTom|lowTom|closedHat|openHat|hiTom|crash|ride):\s*\[([^\]]*)\]/g)];
assert.ok(arrays.length > 40, 'expanded banks contain a substantial set of lane recipes');
for (const [, body] of arrays) {
  for (const token of body.split(',').map(x=>x.trim()).filter(Boolean)) {
    const n = Number(token);
    assert.ok(Number.isInteger(n) && n >= 0 && n <= 15, `step ${token} is in the 0..15 grid`);
  }
}
console.log(`PASS: Genre Expansion banks, phrase-level integration and ${arrays.length} lane-step arrays verified.`);
