import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
assert.match(ui, /#mainContent\s*\{[\s\S]*?min-height:\s*0;[\s\S]*?overflow:\s*hidden;/, 'main content must constrain its children');
assert.match(ui, /#grid\s*\{[\s\S]*?min-height:\s*0;[\s\S]*?overflow-y:\s*auto;/, 'sequencer grid must scroll instead of pushing the footer out of view');
assert.match(ui, /#footer\s*\{[\s\S]*?flex:\s*0\s+0\s+auto;[\s\S]*?z-index:\s*3;/, 'footer must remain a non-shrinking visible row');
assert.match(ui, /id="createBtn"[\s\S]*?Create MIDI Clip/, 'Create MIDI Clip action must remain present');
assert.match(ui, /id="cancelBtn"[\s\S]*?Cancel/, 'Cancel action must remain present');
assert.match(ui, /id="regenBtn"[\s\S]*?Re-shuffle/, 'Re-shuffle action must remain present');
console.log('PASS: 9.3.8 footer visibility, scrollable sequencer and all primary action controls verified.');

assert.match(ui, /Version 9\.5\.4/, 'visible GUI version must match the release');
assert.match(ui, /event\.key === "Escape"[\s\S]*?closeWithResult\(\{ type: "cancel"/, 'Escape must provide a safe cancel/close path');
console.log('PASS: 9.3.8 visible version and Escape close fallback verified.');
