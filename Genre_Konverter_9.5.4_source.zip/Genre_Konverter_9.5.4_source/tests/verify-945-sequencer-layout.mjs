import fs from 'node:fs';
import assert from 'node:assert/strict';

const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

assert.equal(manifest.version, '9.5.4', 'manifest version must be 9.4.7');
assert.equal(pkg.version, '9.5.4', 'package version must be 9.4.7');
assert.match(ui, /#styleList\s*\{[\s\S]*?overflow-y:\s*auto;/, 'genre list must have its own vertical scroll area');
assert.doesNotMatch(ui, /#styleList\s*\{[^}]*overflow:\s*hidden/, 'no later styleList rule may disable scrolling');
assert.match(ui, /grid-template-rows:\s*16px\s+repeat\(10,\s*minmax\(0,\s*1fr\)\)/, 'sequencer must allocate visible space for ruler plus all ten lanes');
assert.match(ui, /const LANES:[\s\S]*?\{ key: "ride", label: "Ride"/, 'Ride lane must remain in the sequencer lane list');
assert.match(ui, /#grid\s*\{[\s\S]*?overflow:\s*hidden;/, 'sequencer remains a non-scrolling viewport');
assert.match(ui, /Version 9\.5\.4/, 'visible GUI version must match release');
console.log('PASS 9.4.7 genre-list scrolling and full-height 10-lane sequencer layout');
