// Hash only the executable preview-engine implementation, excluding the
// intentionally replaced embedded sample payloads and their format labels.
export function normalizeAudioEngine(source) {
  return source
    .replace(/(const\s+\w+_SAMPLE_B64\s*=\s*")[^"]+(";)/g, '$1<SAMPLE_PAYLOAD>$2')
    .replace('original drum WAV samples could not be decoded.', 'original drum MP3 samples could not be decoded.')
    .replace('Loading original WAVs…', 'Loading original MP3s…')
    .replace('original WAV loading failed.', 'original MP3 loading failed.');
}
