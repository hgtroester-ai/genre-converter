import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync('src/ui.ts', 'utf8');
const init = ui.slice(ui.lastIndexOf('// init'));
assert.ok(init.indexOf('renderStyleList();') < init.indexOf('generatePattern();'), 'genre list is rendered before pattern generation');
assert.ok(init.indexOf('renderGrid();') < init.indexOf('generatePattern();'), 'sequencer is rendered before pattern generation');
assert.match(init, /catch \(error\)/, 'initial pattern failure is caught');
assert.match(init, /currentPattern\.kick\.push/, 'fallback groove is present');
console.log('PASS: genre list and sequencer render before generation; fallback groove protects GUI initialization.');
