import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url)));
const manifest=JSON.parse(fs.readFileSync(new URL('../manifest.json',import.meta.url)));
assert.equal(pkg.version,'9.5.4'); assert.equal(manifest.version,'9.5.4');
assert.match(ui,/Version 9\.5\.4/);
assert.match(ui,/<option value="danceBEATZ">DanceBEATZ<\/option>/);
assert.match(ui,/\["twoToneGroove", "nuttySound", "danceBEATZ", "powerSka", "jamaicanFirstWave"\]/);
assert.match(ui,/skaDrummer === "danceBEATZ" \? "140"/);
assert.match(ui,/currentGenre\.key === "ska" && skaDrummer === "danceBEATZ" && currentSection !== "fill"/);
assert.match(ui,/function buildDanceBEATZFill[\s\S]*?1: \[[\s\S]*?2: \[[\s\S]*?3: \[/);
assert.match(ui,/currentGenre\.key === "ska" && skaDrummer === "danceBEATZ"/);
const branch=ui.slice(ui.indexOf('skaDrummer === "danceBEATZ" && currentSection !== "fill"'),ui.indexOf('skaDrummer === "nuttySound" && currentSection !== "fill"'));
assert.match(branch,/for \(let bar = 0; bar < barsCount; bar\+\+\)/);
assert.match(branch,/kick: \[\[0,118\]/); // four-on-the-floor chorus anchor
assert.match(branch,/snare: \[\[0\.5,28\]/); // quiet bridge ghost notes
console.log('PASS 9.0.0 DanceBEATZ profile, 2/4/8-bar selectable sections, 140 BPM, pass fills and release metadata');
