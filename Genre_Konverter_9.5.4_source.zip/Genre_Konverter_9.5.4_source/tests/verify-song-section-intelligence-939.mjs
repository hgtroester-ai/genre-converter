import fs from 'node:fs';
import assert from 'node:assert/strict';
const source = fs.readFileSync('src/ui.ts', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const manifest = JSON.parse(fs.readFileSync('manifest.json', 'utf8'));
assert.equal(pkg.version, '9.5.4');
assert.equal(manifest.version, '9.5.4');
assert.match(source, /const SECTION_DRUMMER_TOUCH = \{/);
for (const id of ['straight','ghostNoteFunk','linearFunk','newOrleansFunk','jazzFunk','amenBreakFunk','uk77SkaDrop','militaryPunkRoll','tribalTomPulse','garageDrive','downbeatAnchor','protoPunkPulse','twoToneGroove','nuttySound','danceBEATZ','powerSka','jamaicanFirstWave','rootsKeeper','deepOneDrop','dubExplorer','rockersDriver','steppersPulse','vintageReggae']) {
  assert.match(source, new RegExp('\\b' + id + ':\\s*\\{'), `Missing drummer touch profile: ${id}`);
}
assert.match(source, /function sectionDrummerVelocityShape\(laneKey, beat\)/);
assert.match(source, /function applyUnifiedSongPerformanceContour\(\)/);
assert.match(source, /const combined = \(velocity \+ energyDelta\) \* touch\.factor \+ touch\.accent \+ transitionDelta/);
assert.doesNotMatch(source, /function applySectionDrummerInteraction\(\)/,
  'legacy separate velocity pass must be removed');
console.log('PASS 9.3.9 compatibility: drummer touch profiles are retained and composed once with Song Arc.');
