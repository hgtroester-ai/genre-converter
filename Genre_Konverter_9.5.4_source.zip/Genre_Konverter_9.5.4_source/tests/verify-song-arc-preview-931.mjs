import fs from "node:fs";
import assert from "node:assert/strict";
const root = new URL("../", import.meta.url);
const ui = fs.readFileSync(new URL("src/ui.ts", root), "utf8");
const pkg = JSON.parse(fs.readFileSync(new URL("package.json", root), "utf8"));
const manifest = JSON.parse(fs.readFileSync(new URL("manifest.json", root), "utf8"));
assert.equal(pkg.version, "9.5.4");
assert.equal(manifest.version, "9.5.4");
assert.match(ui, /<div id="versionTag">Version 9\.5\.4<\/div>/);
assert.match(ui, /id="songArcPreview" role="img"/);
assert.match(ui, /function updateSongArcPreview\(\)/);
for (const section of ["intro", "verse", "chorus", "bridge", "outro"]) {
  assert.match(ui, new RegExp(section + ":\\["), `energy preview must include ${section}`);
}
assert.match(ui, /preview\.innerHTML = sections\.map/);
assert.match(ui, /const percent = Math\.round\(average \* 100\)/);
assert.match(ui, /currentSection === section/);
assert.match(ui, /updateSongArcPreview\(\);/);
console.log("PASS: Song Arc Preview 9.3.8 — five section energy levels, selected arc/strength blending, active-section emphasis and consistent release version.");
