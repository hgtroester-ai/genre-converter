import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
assert.equal(manifest.version, '9.5.4');
for (const name of ['classicRockFill','hardRockFill','symphonicRockFill','indieRockFill','lofiHumanFill']) {
  assert.match(ui, new RegExp(`function ${name}\\(`), `${name} grammar exists`);
}
for (const key of ['classicRockGrammarSmall','hardRockGrammarSmall','symphonicRockGrammarSmall','indieRockGrammarSmall','lofiHumanSmall']) {
  assert.ok(ui.includes(`${key}:`), `${key} is registered`);
}
for (const genre of ['classicRock','hardRock','symphonicRock','indieRock','lofi']) {
  assert.match(ui, new RegExp(`${genre}:\\s*\\{ bar4: \\[\\{ custom:`), `${genre} routes through a dedicated fill grammar`);
}
assert.match(ui, /function takeSpecialFill\(/);
assert.match(ui, /SPECIAL_FILL_BAGS\[key\]/);
assert.match(ui, /function balanceFillSnare\(/, 'existing snare-density safety remains');
assert.match(ui, /if \(currentGenre\.key === "progRock"\)/, 'Progressive Rock path remains isolated');
assert.match(ui, /fillSequenceGridStep\(\)/, 'existing rhythmic grid logic remains');
console.log('PASS: regression guard (8.1.1) dedicated Rock/Lo-Fi fill grammars and regression guards');
