import fs from "node:fs";
import assert from "node:assert/strict";
const ui = fs.readFileSync(new URL("../src/ui.ts", import.meta.url), "utf8");
const manifest = JSON.parse(fs.readFileSync(new URL("../manifest.json", import.meta.url), "utf8"));
const pkg = JSON.parse(fs.readFileSync(new URL("../package.json", import.meta.url), "utf8"));
assert.equal(manifest.version, "9.5.4");
assert.equal(pkg.version, "9.5.4");
assert.match(ui, /const SECTION_ENERGY_ARCS = \{[\s\S]*?intro:\s*\[[\s\S]*?verse:\s*\[[\s\S]*?chorus:\s*\[[\s\S]*?bridge:\s*\[[\s\S]*?outro:\s*\[/);
assert.match(ui, /function sectionEnergyAtBar\(barIndex\)/);
assert.match(ui, /function sectionEnergyVelocityDelta\(laneKey, beat, velocity\)/);
assert.match(ui, /function applyUnifiedSongPerformanceContour\(\)/);
assert.match(ui, /if \(!barsCount \|\| currentSection === "fill"\) return/);
assert.match(ui, /if \(lockedLanes\.has\(lane\.key\)\) continue/);
assert.match(ui, /function applySongArcLayers\(\)[\s\S]*?applyUnifiedSongPerformanceContour\(\);[\s\S]*?applyPassIntelligence\(\);/);
assert.doesNotMatch(ui.slice(ui.indexOf("function applyUnifiedSongPerformanceContour()"), ui.indexOf("// Pass Intelligence")), /\.push\(\[/,
  "Song Arc contour cannot add MIDI notes");
assert.match(ui, /restoreFillOverlay\(\);\s*renderGrid\(\);/,
  "the existing separate fill overlay must still be restored after re-shuffle");
console.log("PASS: 9.5.0 unified section energy contours cover all song sections, respect lane locks and preserve the fill overlay.");
