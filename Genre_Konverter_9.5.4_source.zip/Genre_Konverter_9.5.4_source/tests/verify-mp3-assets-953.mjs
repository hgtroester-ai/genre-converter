import fs from 'node:fs';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ui = fs.readFileSync(path.join(root, 'src/ui.ts'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
assert.equal(manifest.version, '9.5.4');
assert.equal(pkg.version, '9.5.4');
assert.match(ui, /<div id=\"versionTag\">Version 9\.5\.4<\/div>/);
const names = ['CRASH','RIDE','KICK','SNARE','RIM','LOWTOM','MIDTOM','HITOM','CLOSEDHAT','OPENHAT'];
for (const name of names) {
  const m = ui.match(new RegExp(`const ${name}_SAMPLE_B64 = \"([^\"]+)\"`));
  assert.ok(m && m[1].length > 1000, `${name} embedded MP3 payload`);
  const bytes = Buffer.from(m[1], 'base64');
  assert.equal(bytes[0], 0xff, `${name} MP3 frame sync`);
  assert.equal(bytes[1] & 0xe0, 0xe0, `${name} MP3 frame sync bits`);
}
const files = fs.readdirSync(path.join(root, 'samples'));
assert.equal(files.filter(x => x.toLowerCase().endsWith('.mp3')).length, 10);
assert.equal(files.filter(x => x.toLowerCase().endsWith('.wav')).length, 0);
assert.match(ui, /const segment = buffer\.duration \/ 4/);
assert.match(ui, /src\.start\(t, offset, Math\.max\(0\.04, segment - 0\.012\)\)/);
assert.match(ui, /decodeAudioData\(base64ToArrayBuffer\(name\)\)/);
console.log('PASS: 9.5.4 embeds ten MP3 samples; no WAV assets remain; existing four-layer Web Audio playback path is retained.');
