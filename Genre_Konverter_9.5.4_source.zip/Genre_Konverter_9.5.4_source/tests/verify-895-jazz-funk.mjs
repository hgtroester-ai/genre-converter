import fs from 'node:fs';
const src = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
const checks = [
  [pkg.version === '9.5.4' && manifest.version === '9.5.4', 'release metadata'],
  [src.includes('value="jazzFunk">Jazz-Funk</option>'), 'Jazz-Funk profile selector'],
  [src.includes('function applyJazzFunkPass()'), 'Jazz-Funk generator'],
  [src.includes('cells.verseTurn') && src.includes('cells.chorusTurn') && src.includes('cells.bridgeTurn'), '12-bar section transitions'],
  [src.includes('priority > old.priority'), 'single-voice collision resolution'],
  [src.includes('event.lane === "snare" ? 0.012 : 0'), 'behind-the-beat snare timing'],
  [src.includes('funkDrummer === "jazzFunk") applyJazzFunkPass();'), 'generator dispatch']
];
for (const [ok, label] of checks) { if (!ok) throw new Error(`FAIL: ${label}`); console.log(`PASS: ${label}`); }
