import fs from 'node:fs';
import assert from 'node:assert/strict';
const source = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
assert.equal(pkg.version, '9.5.4');
assert.equal(manifest.version, '9.5.4');
assert.match(source, /<div id="versionTag">Version 9\.5\.4<\/div>/);
const start = source.indexOf('function dubEffectFill(big)');
const end = source.indexOf('// Breakbeat / Big Beat', start);
assert.ok(start >= 0 && end > start, 'Dub fill function exists');
const dub = source.slice(start, end);
for (const concept of ['rimEcho','tapeDelay','oneDropSpace','bassEcho','tomCall','skankCut','tripletRim','dubDropout','crossStickAnswer','softPickup']) {
  assert.ok(dub.includes(`"${concept}"`), `Dub concept ${concept} exists`);
}
assert.match(dub, /clearFrom: start, landing: \{ lane: null \}/);
console.log('PASS: Dub has ten dedicated fill concepts and release/UI version metadata reads 8.1.1.');
