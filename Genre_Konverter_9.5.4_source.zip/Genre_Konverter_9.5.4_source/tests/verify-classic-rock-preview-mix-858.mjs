import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
assert.match(ui, /const CLASSIC_ROCK_PREVIEW_MIX = \{/);
assert.match(ui, /kick: 4\.00, snare: 4\.00/);
assert.match(ui, /closedHat: 0\.25, openHat: 0\.32/);
assert.match(ui, /currentGenre\?\.key === "classicRock"/);
assert.match(ui, /const g = laneVol \* \(PREVIEW_TRIM\[lane\] \|\| 1\) \* genreMix;/);
console.log('PASS: Classic Rock preview mix is genre-specific, retained through 8.7.0, and respects lane faders.');
