import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const patternsSource = fs.readFileSync('src/patterns.ts', 'utf8');
const match = patternsSource.match(/export const GENRES: GenrePattern\[\] = (\[[\s\S]*\n\]);\s*$/);
assert.ok(match, 'genre pattern bank is available');
const genres = vm.runInNewContext(`(${match[1]})`);
const expected = [
  'classicRock','hardRock','bluesRock','psychRock','progRock','symphonicRock',
  'punkRock','popPunk','grunge','altRock','indieRock','nuMetal','gothicRock',
  'glamRock','funk','reggae','ska','jazz','hiphop','rap','dub','breakbeat',
  'jungle','drumAndBass','lofi'
];
assert.equal(genres.length, 25, 'exactly 25 genre definitions exist');
assert.deepEqual(Array.from(genres, g => g.key), expected, 'all requested genres are present in the expected order');
const laneKeys = ['kick','snare','altSnare','midTom','lowTom','closedHat','openHat','hiTom','crash','ride'];
for (const genre of genres) {
  assert.ok(genre.label && genre.defaultBpm > 0, `${genre.key}: label and BPM`);
  for (const lane of laneKeys) {
    assert.ok(Array.isArray(genre.lanes[lane]), `${genre.key}.${lane}: lane variants exist`);
    for (const variant of genre.lanes[lane]) {
      assert.ok(Array.isArray(variant), `${genre.key}.${lane}: variant is an array`);
      for (const beat of variant) assert.ok(Number.isFinite(beat) && beat >= 0 && beat < 4, `${genre.key}.${lane}: beat ${beat} is inside one 4/4 bar`);
    }
  }
}
const ui = fs.readFileSync('src/ui.ts', 'utf8');
assert.match(ui, /function generateBankedGenrePattern\(preserved\)/, 'genre-aware bank engine exists');
assert.match(ui, /generateBankedGenrePattern\(preserved\);\s*applyGrooveVariation\(\);\s*applyBridgePhraseArc\(\);\s*applyRepetitionVerseFill\(\);\s*applyChorusPhraseFill\(\);\s*applyBridgePhraseFill\(\);\s*return;/, 'non-Classic-Rock/non-Funk genres route through their genre bank');
assert.match(ui, /function styleVelocity\(laneKey, beat, genreKey\)/, 'genre-specific dynamics exist');
assert.match(ui, /authoredFillBank/, 'existing authored fill tabs remain available where supplied');
assert.match(ui, /if \(currentGenre\.key === "funk"\) \{\s*generateFunkPattern\(preserved\);\s*applyGrooveVariation\(\);\s*applyBridgePhraseArc\(\);\s*applyRepetitionVerseFill\(\);\s*applyChorusPhraseFill\(\);\s*applyBridgePhraseFill\(\);\s*return;/, 'Funk keeps its dedicated whole-genre engine');
console.log('PASS: all 25 requested genres have valid per-lane 4/4 pattern banks; genre-aware dynamics/routing and existing Funk/Classic Rock paths are present.');
