import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
assert.match(ui, /const groupBackSteps = meter === "4\/4" \? \[8\]/, '4/4 Progressive Rock must have an explicit snare backbeat');
assert.match(ui, /chorusAnswers = \[/, 'Progressive Rock Chorus has recipe-specific kick answers');
assert.match(ui, /chorusSnareAnswers = meter === "4\/4"/, 'Progressive Rock Chorus has explicit snare variations');
assert.match(ui, /if \(currentSection === "bridge"\)[\s\S]*?snares = \[8, \.\.\.\(bar % 2 \? \[\] : \[14\]\)\]/, 'Progressive Rock Bridge retains a deliberate snare backbeat');
assert.match(ui, /if \(bar % 2 === 1 && steps >= 8\) addAt\("lowTom"/, 'Progressive Rock Bridge has restrained alternating tom punctuation');
console.log('PASS: Progressive Rock 4/4 snare, Chorus kick/snare variation and Bridge backbeat/tom punctuation.');
