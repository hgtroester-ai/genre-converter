import fs from 'node:fs';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const bundle = fs.readFileSync(new URL('../dist/extension.js', import.meta.url), 'utf8');
for (const token of ['jazzTripletRideBeats = [0, 2/3, 1, 5/3, 2, 8/3, 3, 11/3]', 'currentGenre.key === "jazz"', 'event.lane === "closedHat"']) {
  if (!ui.includes(token)) throw new Error(`Missing Jazz triplet behavior: ${token}`);
}
if (!bundle.includes('jazzTripletRideBeats')) throw new Error('Jazz triplet engine not present in bundle');
console.log('PASS: Jazz uses 12-slot triplet ride pulse, foot hi-hat on 2/4, and tab-derived comping/fill voices.');
