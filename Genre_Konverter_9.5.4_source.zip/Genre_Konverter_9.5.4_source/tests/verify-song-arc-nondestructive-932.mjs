import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
assert.equal(pkg.version, '9.5.4');
assert.equal(manifest.version, '9.5.4');
assert.match(ui, /<div id="versionTag">Version 9\.5\.4<\/div>/);
assert.match(ui, /function generatePattern\(\)\s*\{\s*generatePatternCore\(\);\s*songArcBasePattern = clonePatternData\(currentPattern\);\s*songArcAppliedPattern = null;\s*applySongArcLayers\(\);\s*\}/);
for (const id of ['songArcPreset','songArcStrength','nextSection']) {
  const handler = ui.match(new RegExp('document\\.getElementById\\("' + id + '"\\)\\.addEventListener'));
  assert.ok(handler, `${id} control remains wired`);
}
assert.match(ui, /function applyUnifiedSongPerformanceContour\(\)/);
assert.match(ui, /const combined = \(velocity \+ energyDelta\) \* touch\.factor \+ touch\.accent \+ transitionDelta/);
assert.doesNotMatch(ui, /applySectionEnergyArc\(\);\s*applySectionDrummerInteraction\(\);/,
  'energy and drummer touch must not be applied as separate velocity passes');
assert.match(ui, /patternsMatch\(currentPattern, songArcAppliedPattern\)/);
assert.match(ui, /songArcBasePattern = clonePatternData\(currentPattern\);/);
assert.match(ui, /currentPattern = clonePatternData\(songArcBasePattern\);\s*applyUnifiedSongPerformanceContour\(\);[\s\S]*?applyPassIntelligence\(\);\s*songArcAppliedPattern = clonePatternData\(currentPattern\);/);
console.log('PASS: Song Arc, drummer touch and transition now share one non-compounding velocity pass; sequencer edits remain non-destructive.');
