import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
assert.equal(pkg.version, '9.5.4');
assert.equal(manifest.version, '9.5.4');
assert.match(ui, /function glamFillGrammar\(big\)/, 'Glam must use its dedicated fill grammar');
assert.match(ui, /glamFillSmall: \(\) => glamFillGrammar\(false\)/);
assert.match(ui, /glamFillBig: \(\) => glamFillGrammar\(true\)/);
assert.match(ui, /glamRock:\s*\{ bar4: \[\{ custom: "glamFillSmall", p: 1\.0 \}\], bar8: \[\{ custom: "glamFillBig", p: 1\.0 \}\] \}/,
  'Glam must not fall back to the old generic stomp recipes');
for (const phrase of ['Glitter drive', 'Glam hard-rock', 'Snare drive', 'Theatrical stop', 'Stomp-clap reference', 'Mini descending tom pickup']) {
  assert.ok(ui.includes(phrase), `Missing Glam fill phrase family: ${phrase}`);
}
assert.ok(!ui.includes('glamStompFill') && !ui.includes('glamStompSmall') && !ui.includes('glamStompBig'),
  'Old repetitive stomp fill must be fully retired');
assert.match(ui, /clearFrom: start, landing: \{ lane: "crash", vel: landingVel \}/,
  'Fill scope must remain bounded and use a controlled landing accent');
console.log('PASS: 8.1.1 Glam fill engine has dedicated small/full phrase families, varied Glam vocabulary and no repetitive stomp fallback.');
