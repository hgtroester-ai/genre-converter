import fs from 'node:fs';
import assert from 'node:assert/strict';
import vm from 'node:vm';
const ui=fs.readFileSync(new URL('../src/ui.ts',import.meta.url),'utf8');
const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url)));
const manifest=JSON.parse(fs.readFileSync(new URL('../manifest.json',import.meta.url)));
assert.equal(pkg.version,'9.5.4'); assert.equal(manifest.version,'9.5.4');
assert.match(ui,/Version 9\.5\.4/);
assert.match(ui,/function applyDanceBeatzPassDevelopment\(\)/);
const helper=ui.slice(ui.indexOf('function applyDanceBeatzPassDevelopment'),ui.indexOf('function buildNuttySoundFill'));
for (const section of ['verse','chorus','bridge']) assert.ok(helper.includes(`currentSection === "${section}"`), `${section} pass development missing`);
assert.match(helper,/if \(!final\)/); assert.match(helper,/else \{/);
const variation=ui.slice(ui.indexOf('function applyIntelligentVerseVariation'),ui.indexOf('function applyRepetitionIntelligence'));
assert.match(variation,/genre === "ska" && skaDrummer === "danceBEATZ"/);
const branch=ui.slice(ui.indexOf('skaDrummer === "danceBEATZ" && currentSection !== "fill"'),ui.indexOf('skaDrummer === "nuttySound" && currentSection !== "fill"'));
assert.match(branch,/applyDanceBeatzPassDevelopment\(\)/);
assert.match(branch,/sectionPass >= 2 && verseVariationEnabled/);
assert.match(branch,/applyIntelligentVerseVariation\(\)/);
// Execute the isolated deterministic pass-development helper against representative
// four-bar lane patterns, rather than only checking that source strings exist.
const laneKeys=['kick','snare','altSnare','closedHat','openHat','crash','ride','hiTom','midTom','lowTom'];
function simulatedPattern(section,pass,bars=4){
  const pattern=Object.fromEntries(laneKeys.map(k=>[k,[]]));
  for(let bar=0;bar<bars;bar++){
    if(section==='verse'){
      for(const t of [.5,1.5,2.5,3.5]) pattern.closedHat.push([bar*4+t,86]);
      for(const t of [0,1,2,3]) pattern.kick.push([bar*4+t,110]);
      for(const t of [1,3]) pattern.snare.push([bar*4+t,112]);
    } else if(section==='chorus') {
      for(let t=0;t<4;t+=.5) pattern.closedHat.push([bar*4+t,90]);
      for(const t of [0,1,2,3]) pattern.kick.push([bar*4+t,110]);
      for(const t of [1,2.5,3.5]) pattern.snare.push([bar*4+t,110]);
    } else {
      for(let t=0;t<4;t++) pattern.closedHat.push([bar*4+t,60]);
      for(const t of [0,2]) pattern.kick.push([bar*4+t,100]);
      for(const t of [.5,.75,1,1.5,1.75,2,2.5,2.75,3,3.5,3.75]) pattern.snare.push([bar*4+t,30]);
    }
  }
  const ctx={currentGenre:{key:'ska'},skaDrummer:'danceBEATZ',sectionPass:pass,currentSection:section,currentPattern:pattern,barsCount:bars,lockedLanes:new Set(),LANES:laneKeys.map(key=>({key}))};
  vm.runInNewContext(helper+'; applyDanceBeatzPassDevelopment();',ctx);
  return pattern;
}
const noteCount=p=>Object.values(p).reduce((n,a)=>n+a.length,0);
for(const section of ['verse','chorus','bridge']){
  const first=simulatedPattern(section,1), second=simulatedPattern(section,2), final=simulatedPattern(section,3);
  assert.equal(noteCount(first),noteCount(simulatedPattern(section,1)),'First Pass must remain deterministic');
  assert.ok(noteCount(second)>noteCount(first),`${section} Second Pass must develop the groove`);
  assert.ok(noteCount(final)>noteCount(first),`${section} Final Pass must develop the groove`);
  const eightFirst=simulatedPattern(section,1,8), eightSecond=simulatedPattern(section,2,8), eightFinal=simulatedPattern(section,3,8);
  assert.ok(Object.values(eightFirst).some(lane=>lane.some(([t])=>t>=16)),`${section} 8-bar First Pass must contain notes in bars 5–8`);
  assert.ok(noteCount(eightSecond)>noteCount(eightFirst),`${section} 8-bar Second Pass must develop both phrases`);
  assert.ok(noteCount(eightFinal)>noteCount(eightFirst),`${section} 8-bar Final Pass must develop both phrases`);
}
// Run the actual optional Verse Variation helper for Second and Final Pass.
const variationFn=ui.slice(ui.indexOf('function applyIntelligentVerseVariation'),ui.indexOf('function applyRepetitionIntelligence'));
for(const pass of [2,3]){
  const pattern=simulatedPattern('verse',1);
  const ctx={sectionPass:pass,verseVariationStrength:'balanced',beatsPerBar:()=>4,currentGenre:{key:'ska'},skaDrummer:'danceBEATZ',lockedLanes:new Set(),currentPattern:pattern,barsCount:4,LANES:laneKeys.map(key=>({key}))};
  vm.runInNewContext(variationFn+'; applyIntelligentVerseVariation();',ctx);
  assert.ok(pattern.altSnare.length>0,`Intelligent Verse Variation must add phrase detail on pass ${pass}`);
}
console.log('PASS 9.0.0 DanceBEATZ: runtime-simulated Second/Final Pass evolution in all sections at 4 and 8 bars and optional intelligent Verse Variation');
