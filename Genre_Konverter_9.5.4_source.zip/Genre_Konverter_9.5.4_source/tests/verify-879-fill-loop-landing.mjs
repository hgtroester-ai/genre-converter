import fs from "node:fs";
import assert from "node:assert/strict";
const ui = fs.readFileSync(new URL("../src/ui.ts", import.meta.url), "utf8");
// Both fill paths must add a landing only when the next bar is still inside
// the phrase. The final bar must not wrap an extra accent onto bar 1.
assert.match(ui, /if \(barIndex < barsCount - 1\) \{\s*const nextBarStart = \(barIndex \+ 1\) \* beats;/);
assert.match(ui, /if \(landing && barIndex < barsCount - 1\) \{/);
assert.match(ui, /Do not wrap a second kick\/cymbal landing into that same/);
console.log("PASS: final-bar fill landings no longer wrap into the loop's opening downbeat.");
