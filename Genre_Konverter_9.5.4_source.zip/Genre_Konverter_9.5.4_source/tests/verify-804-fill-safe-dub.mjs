import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const expansion = fs.readFileSync(new URL('../src/genreExpansion.ts', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
assert.equal(pkg.version, '9.5.4');
assert.equal(manifest.version, '9.5.4');
assert.match(ui, /slider\.addEventListener\("input"[\s\S]*?generatePattern\(\);\s*restoreFillOverlay\(\);\s*renderGrid\(\);/,
  'Groove Variation slider must restore the exact saved fill overlay after rebuilding the groove');
assert.match(ui, /slider\.addEventListener\("pointerdown", \(\) => \{ pushUndo\(\);/,
  'Groove Variation slider must capture an undo snapshot before interaction');
assert.match(ui, /if \(slow && !lockedLanes\.has\("closedHat"\)\)/,
  'Slow Dub should receive a stable offbeat hat pulse');
assert.match(ui, /const slow = bpm < 105/,
  'Slow Dub motion must be based on actual tempo, without changing BPM');
const dub = expansion.slice(expansion.indexOf('  dub: {'), expansion.indexOf('  ska: {'));
assert.ok(dub.includes('r([0,4,8,12]'), 'Dub bank needs a clear Steppers foundation');
assert.ok(dub.includes('r([8],[],eighths'), 'Dub bank needs a recognizable One Drop foundation');
assert.ok(dub.includes('openHat:[6,14]'), 'Dub needs offbeat skank punctuation');
console.log('PASS: regression guard (8.1.1) fill-safe Groove Variation, reset preservation and stronger low-tempo Dub foundations.');
