import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
const root = new URL('../', import.meta.url);
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'genre-konverter-902-'));
try {
  execFileSync('tsc', ['--target','ES2022','--module','commonjs','--skipLibCheck','--outDir',temp,'src/grooveGrammar.ts','src/genreTabs.ts'], { cwd: root, stdio:'pipe' });
  const req = createRequire(import.meta.url);
  const { GENRE_TABS } = req(path.join(temp,'genreTabs.js'));
  const jazz = GENRE_TABS.jazz || [];
  const counts = Object.fromEntries(['verse','chorus','bridge','fill'].map(section => [section,jazz.filter(tab=>tab.section===section).length]));
  assert.deepEqual(counts, { verse:104, chorus:8, bridge:7, fill:9 });
  const lanes = new Set(['kick','snare','altSnare','hiTom','midTom','lowTom','closedHat','openHat','crash','ride']);
  for (const tab of jazz.filter(t=>t.section==='chorus'||t.section==='bridge')) {
    assert.ok(tab.title.length > 8, 'authored section pattern has a descriptive title');
    assert.ok(tab.events.length > 0, `${tab.title} has comping events`);
    for (const event of tab.events) {
      assert.ok(lanes.has(event.lane), `${tab.title} lane ${event.lane} exists`);
      assert.ok(Number.isFinite(event.beat) && event.beat >= 0 && event.beat < 4, `${tab.title} beat is within 4/4`);
      assert.ok(Number.isInteger(event.velocity) && event.velocity >= 1 && event.velocity <= 127, `${tab.title} velocity is MIDI-safe`);
    }
  }
  assert.ok(jazz.filter(t=>t.section==='chorus').every(t=>t.events.some(e=>['snare','altSnare','kick'].includes(e.lane))));
  assert.ok(jazz.filter(t=>t.section==='bridge').every(t=>t.events.some(e=>['snare','altSnare','lowTom','kick'].includes(e.lane))));
} finally { fs.rmSync(temp,{recursive:true,force:true}); }
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url),'utf8');
assert.match(ui,/function applyJazzBridgePassDevelopment\(\)/);
assert.match(ui,/if \(pass === 2\)[\s\S]*?Second pass: one quiet offbeat response/);
assert.match(ui,/Final pass: a little more conversation, never a rock backbeat/);
assert.match(ui,/if \(currentGenre\.key === "jazz" && currentSection === "bridge"\) applyJazzBridgePassDevelopment\(\)/);
console.log('PASS 9.2.0 Jazz Completion: 8 authored Chorus grooves, 7 Bridge grooves, MIDI-safe comping, and Jazz-specific Bridge pass development.');
