import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url)));
const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url)));
assert.equal(pkg.version, '9.5.4'); assert.equal(manifest.version, '9.5.4');
assert.match(ui, /Version 9\.5\.4/);
assert.match(ui, /<option value="powerSka">Power-Ska<\/option>/);
assert.doesNotMatch(ui, /DanceBEATZ · in Entwicklung/);
const start=ui.indexOf('skaDrummer === "powerSka" && currentSection !== "fill"');
const end=ui.indexOf('skaDrummer === "twoToneGroove" && currentSection !== "fill"',start);
assert.ok(start>=0 && end>start,'Power-Ska specialized generator exists');
const branch=ui.slice(start,end);
for (const section of ['verse','chorus','bridge']) assert.ok(branch.includes(`currentSection === "${section}"`));
assert.match(branch,/for \(let bar = 0; bar < barsCount; bar\+\+\)/);
assert.match(branch,/applyPowerSkaShuffleVariation\(\)/); assert.match(branch,/applyPowerSkaPassDevelopment\(\)/);
assert.match(ui,/function applyPowerSkaShuffleVariation\(\)/);
assert.match(ui,/function applyPowerSkaPassDevelopment\(\)/);
assert.match(ui,/function buildPowerSkaFill\(pass, context\)/);
assert.match(ui,/skaDrummer === "powerSka"\) \{\s*const built = buildPowerSkaFill/);
assert.match(ui,/powerSkaShuffleCycle = \(powerSkaShuffleCycle \+ 1\) % 4/);
assert.match(ui,/powerSkaFillCycle = \(powerSkaFillCycle \+ 1\) % 4/);
assert.match(ui,/skaDrummer === "powerSka" \? "175"/);
// Runtime-check the actual pass and shuffle helpers over complete 4- and 8-bar patterns.
import vm from 'node:vm';
const laneKeys=['kick','snare','altSnare','hiTom','midTom','lowTom','closedHat','openHat','crash','ride'];
const passFn=ui.slice(ui.indexOf('function applyPowerSkaPassDevelopment()'),ui.indexOf('function applyPowerSkaShuffleVariation()'));
const shuffleFn=ui.slice(ui.indexOf('function applyPowerSkaShuffleVariation()'),ui.indexOf('function buildPowerSkaFill'));
function seededPattern(section,bars){
  const p=Object.fromEntries(laneKeys.map(k=>[k,[]]));
  for(let b=0;b<bars;b++){
    for(const beat of [0,1,2,3]) p.kick.push([b*4+beat,110]);
    for(const beat of [0.5,2.5]) p.snare.push([b*4+beat,104]);
    p.closedHat.push([b*4,84],[b*4+1,80],[b*4+2,86],[b*4+3,82]);
    if(section==='chorus') for(let t=0;t<4;t+=0.5) p.ride.push([b*4+t,100]);
    if(section==='bridge') p.snare.push([b*4+2,112]);
  }
  return p;
}
const count=p=>Object.values(p).reduce((n,a)=>n+a.length,0);
for(const section of ['verse','chorus','bridge']) for(const bars of [4,8]){
  const first=seededPattern(section,bars), second=seededPattern(section,bars), final=seededPattern(section,bars);
  const common={currentGenre:{key:'ska'},skaDrummer:'powerSka',currentSection:section,barsCount:bars,lockedLanes:new Set(),LANES:laneKeys.map(key=>({key})),beatsPerBar:()=>4};
  vm.runInNewContext(passFn+'; applyPowerSkaPassDevelopment();',{...common,currentPattern:second,sectionPass:2});
  vm.runInNewContext(passFn+'; applyPowerSkaPassDevelopment();',{...common,currentPattern:final,sectionPass:3});
  assert.ok(count(second)>count(first),`${section} ${bars}-bar Second Pass adds phrase detail`);
  assert.ok(count(final)>count(first),`${section} ${bars}-bar Final Pass adds phrase detail`);
  assert.ok(Object.values(first).some(a=>a.some(([t])=>t>=(bars===8?16:12))),`${section} authored pattern spans all selected bars`);
}
for(const section of ['verse','chorus','bridge']){
  const signatures=[];
  for(let cycle=1;cycle<=3;cycle++){
    const pattern=seededPattern(section,8);
    vm.runInNewContext(shuffleFn+'; applyPowerSkaShuffleVariation();',{currentGenre:{key:'ska'},skaDrummer:'powerSka',currentSection:section,barsCount:8,beatsPerBar:()=>4,lockedLanes:new Set(),currentPattern:pattern,LANES:laneKeys.map(key=>({key})),powerSkaShuffleCycle:cycle});
    signatures.push(JSON.stringify(pattern));
  }
  assert.equal(new Set(signatures).size,3,`${section} Re-shuffle produces three distinct variants`);
}
console.log('PASS 9.0.0 Power-Ska: runtime pass evolution in Verse/Chorus/Bridge at 4/8 bars and distinct Re-shuffle variants');
