import fs from "node:fs";
import assert from "node:assert/strict";
const ui = fs.readFileSync(new URL("../src/ui.ts", import.meta.url), "utf8");
const manifest = JSON.parse(fs.readFileSync(new URL("../manifest.json", import.meta.url), "utf8"));
const pkg = JSON.parse(fs.readFileSync(new URL("../package.json", import.meta.url), "utf8"));
assert.equal(manifest.version, "9.5.4");
assert.equal(pkg.version, "9.5.4");
for (const phrase of ['value="2"', 'value="4"', 'value="8"']) assert.ok(ui.includes(phrase), `missing phrase length ${phrase}`);
assert.ok(!ui.includes('value="16"'), '16-bar phrase option must be removed');
assert.ok(ui.includes('grooveVariation'), 'continuous Groove Variation knob exists');
for (const name of ["ARRANGEMENT_FAMILY","CHORUS_RULES","applyChorusSection","introVariant","applyIntroOverride","applyOutroOverride","bridgeVariant","applyBridgeSection"]) {
  assert.ok(ui.includes(name), `missing arrangement feature ${name}`);
}
for (const family of ["rock","blues","punk","funk","jazz","reggae","dub","ska","hiphop","heavy","breaks"]) {
  assert.ok(ui.includes(`${family}:`), `missing genre arrangement family ${family}`);
}
assert.ok(!ui.includes('ensureDownbeatCrash: true'), "legacy universal chorus crash rule remains");
assert.ok(!ui.includes("TOM_BRIDGE_PATTERN"), "legacy generic tom bridge fallback remains");
console.log("PASS: Arrangement Intelligence profiles, section engines and 2/4/8-bar phrase selector.");
