import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync('src/ui.ts', 'utf8');
const manifest = JSON.parse(fs.readFileSync('manifest.json', 'utf8'));
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
assert.equal(manifest.version, '9.5.4');
assert.equal(pkg.version, '9.5.4');
assert.match(ui, /id="reggaeStyleField"[\s\S]*?value="oneDrop"[\s\S]*?value="rockers"[\s\S]*?value="steppers"/,
  'Reggae offers One Drop, Rockers and Steppers');
assert.match(ui, /id="reggaeDrummerField"[\s\S]*?Roots Keeper[\s\S]*?Deep One Drop[\s\S]*?Dub Explorer[\s\S]*?Rockers Driver[\s\S]*?Steppers Pulse[\s\S]*?Vintage Reggae/,
  'Reggae offers six distinct drummer profiles');
assert.match(ui, /const REGGAE_GROOVE_BANKS = \{[\s\S]*?oneDrop:[\s\S]*?rockers:[\s\S]*?steppers:/,
  'three independent authored groove banks exist');
assert.match(ui, /function generateReggaeVerse\(\)[\s\S]*?const recipeIndex = \(reggaeRecipeCycle[\s\S]*?generateReggaeVerse\(\);/,
  'Reggae uses its dedicated phrase engine and Re-shuffle recipe cycle');
const banksStart = ui.indexOf("const REGGAE_GROOVE_BANKS = {");
const banksEnd = ui.indexOf("const REGGAE_DRUMMER_PROFILES", banksStart);
const banks = ui.slice(banksStart, banksEnd);
const styles = ["oneDrop", "rockers", "steppers"];
for (let i = 0; i < styles.length; i++) {
  const start = banks.indexOf(styles[i] + ": [");
  const end = i < styles.length - 1 ? banks.indexOf(styles[i + 1] + ": [", start) : banks.length;
  const count = (banks.slice(start, end).match(/^    \{ kick:/gm) || []).length;
  assert.equal(count, i === 0 ? 8 : 6, `${styles[i]} has a broad authored groove repertoire`);
}
assert.match(ui, /if \(reggaeStyle === "oneDrop"[\s\S]*?Math\.abs\(\(beat % 4 \+ 4\) % 4\) > 0\.02/,
  'One Drop explicitly prevents kick on beat 1');
assert.match(ui, /function reggaeRootsFill\(big\)[\s\S]*?const oneDrop = \[[\s\S]*?const rockers = \[[\s\S]*?const steppers = \[/,
  'fills have separate grammars for all three Reggae styles');
assert.match(ui, /return \{ out: addFlavor\(out\), clearFrom: 0, clearTo: 4, landing: null \}/,
  'Reggae fills rebuild a full bar and do not add a generic kick landing');
assert.match(ui, /reggae:\s*\{ bar4: \[\{ custom: "reggaeRootsSmall", p: 1\.0 \}\], bar8: \[\{ custom: "reggaeRootsBig", p: 1\.0 \}\] \}/,
  'Reggae fill generation cannot fall back to unrelated generic fills');
assert.match(ui, /currentGenre\.key === "reggae" && barsCount === 4 \? "bar4" : "bar8"/,
  'Reggae uses its appropriate 4/8-bar fill context without changing other genres');
assert.match(ui, /if \(currentGenre\.key === "reggae"\) reggaeFillCycle = \(reggaeFillCycle \+ 1\)/,
  'Regenerate Fill cycles through different Reggae variations');
console.log('PASS: 8.5.2 provides three Reggae styles, six drummer profiles, phrase-aware repertoire, full-bar fills and One Drop beat-1 protection.');
