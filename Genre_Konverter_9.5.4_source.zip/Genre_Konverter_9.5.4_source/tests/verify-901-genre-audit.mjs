import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const root = process.cwd();
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const manifest = JSON.parse(fs.readFileSync('manifest.json', 'utf8'));
const ui = fs.readFileSync('src/ui.ts', 'utf8');
const patternSource = fs.readFileSync('src/patterns.ts', 'utf8');
const tabSource = fs.readFileSync('src/genreTabs.ts', 'utf8');
const classicSource = fs.readFileSync('src/classicRockTabs.ts', 'utf8');

assert.equal(pkg.version, '9.5.4');
assert.equal(manifest.version, '9.5.4');
assert.match(ui, /<div id="versionTag">Version 9\.5\.4<\/div>/);

const genreMatch = patternSource.match(/export const GENRES: GenrePattern\[\] = (\[[\s\S]*\n\]);\s*$/);
assert.ok(genreMatch, 'GENRES array must be statically auditable');
const genres = vm.runInNewContext(`(${genreMatch[1]})`);
const genreKeys = genres.map(g => g.key);
assert.equal(genreKeys.length, 25);
assert.equal(new Set(genreKeys).size, genreKeys.length, 'genre keys are unique');

const familyMatch = ui.match(/const ARRANGEMENT_FAMILY = \{([\s\S]*?)\n\};/);
assert.ok(familyMatch, 'arrangement family map exists');
const families = vm.runInNewContext(`({${familyMatch[1]}})`);
for (const key of genreKeys) assert.ok(families[key], `${key} has an explicit arrangement family`);
assert.equal(families.hiphop, 'hiphop', 'Hip-Hop key resolves to the Hip-Hop family');
assert.ok(!Object.hasOwn(families, 'hipHop'), 'stale Hip-Hop camel-case key is absent');

const heavyMatch = ui.match(/const heavy = (\[[^\]]*\])/);
assert.ok(heavyMatch, 'Verse Variation heavy-genre list exists');
const heavyGenres = vm.runInNewContext(`(${heavyMatch[1]})`);
for (const key of heavyGenres) assert.ok(genreKeys.includes(key), `Verse Variation uses valid genre key ${key}`);

const generatedMatch = tabSource.match(/const GENERATED_TAB_GENRES = (\[[\s\S]*?\]);/);
const countsMatch = tabSource.match(/const SECTION_COUNTS = (\[[\s\S]*?\]);/);
assert.ok(generatedMatch && countsMatch, 'generated tab bank declarations exist');
const generatedKeys = vm.runInNewContext(`(${generatedMatch[1]})`);
const sectionCounts = vm.runInNewContext(`(${countsMatch[1].replaceAll(' as const', '')})`);
assert.equal(generatedKeys.length, 20);
assert.equal(new Set(generatedKeys).size, generatedKeys.length);
assert.deepEqual(Array.from(sectionCounts, x => [x.section, x.count]), [
  ['verse', 12], ['chorus', 8], ['bridge', 6], ['fill', 6]
]);
for (const key of generatedKeys) assert.ok(genreKeys.includes(key), `generated tab key ${key} belongs to a selectable genre`);

// Compile the TypeScript data modules and inspect the actual runtime-generated tab banks.
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'genre-konverter-901-'));
try {
  execFileSync('tsc', [
    '--target', 'ES2022', '--module', 'commonjs', '--skipLibCheck',
    '--outDir', temp,
    'src/grooveGrammar.ts', 'src/genreTabs.ts', 'src/classicRockTabs.ts'
  ], { cwd: root, stdio: 'pipe' });
  const req = createRequire(import.meta.url);
  const { GENRE_TABS } = req(path.join(temp, 'genreTabs.js'));
  const { CLASSIC_ROCK_TABS } = req(path.join(temp, 'classicRockTabs.js'));
  const laneKeys = new Set(['kick','snare','altSnare','hiTom','midTom','lowTom','closedHat','openHat','crash','ride']);
  const countsFor = tabs => {
    const counts = { verse: 0, chorus: 0, bridge: 0, fill: 0 };
    for (const tab of tabs) counts[tab.section]++;
    return counts;
  };
  for (const key of generatedKeys) {
    const tabs = GENRE_TABS[key] || [];
    assert.equal(tabs.length, 32, `${key} has 32 generated tabs`);
    assert.deepEqual(countsFor(tabs), { verse: 12, chorus: 8, bridge: 6, fill: 6 }, `${key} section coverage`);
    for (const tab of tabs) for (const event of tab.events) {
      assert.ok(laneKeys.has(event.lane), `${key}/${tab.title}: known lane ${event.lane}`);
      assert.ok(Number.isFinite(event.beat) && event.beat >= 0 && event.beat < 4, `${key}/${tab.title}: beat in 4/4 bar`);
      assert.ok(Number.isInteger(event.velocity) && event.velocity >= 1 && event.velocity <= 127, `${key}/${tab.title}: MIDI velocity`);
    }
  }
  const classicCounts = countsFor(CLASSIC_ROCK_TABS);
  assert.deepEqual(classicCounts, { verse: 30, chorus: 30, bridge: 25, fill: 15 });
  const specialCounts = Object.fromEntries(['funk','reggae','punkRock','jazz'].map(key => [key, countsFor(GENRE_TABS[key] || [])]));
  assert.ok(specialCounts.funk.verse && specialCounts.funk.chorus && specialCounts.funk.bridge && specialCounts.funk.fill);
  assert.ok(specialCounts.reggae.verse && specialCounts.reggae.chorus && specialCounts.reggae.bridge && specialCounts.reggae.fill);
  assert.ok(specialCounts.punkRock.verse && specialCounts.punkRock.chorus && specialCounts.punkRock.bridge && specialCounts.punkRock.fill);
  assert.ok(specialCounts.jazz.verse && specialCounts.jazz.chorus && specialCounts.jazz.bridge && specialCounts.jazz.fill);
  assert.equal(specialCounts.jazz.chorus, 8, 'Jazz has eight dedicated authored Chorus grooves');
  assert.equal(specialCounts.jazz.bridge, 7, 'Jazz has seven authored Bridge grooves');
  assert.doesNotMatch(ui, /currentGenre\.key === "jazz" && currentSection === "chorus"[\s\S]*?filter\(tab => tab\.section === "verse"\)/);
} finally {
  fs.rmSync(temp, { recursive: true, force: true });
}

console.log('PASS 9.2.0 Genre Audit: 25 selectable genres, complete arrangement-family routing, valid Verse Variation keys, 20 generated banks with 12/8/6/6 coverage, Classic Rock dedicated bank, special Funk/Reggae/Punk/Jazz banks, and MIDI-safe tab events.');
