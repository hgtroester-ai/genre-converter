import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const src = fs.readFileSync('src/ui.ts', 'utf8');
const match = src.match(/const FUNK_GROOVE_PATTERNS = (\[[\s\S]*?\n\]);\n\nfunction generateFunkPattern/);
assert.ok(match, 'whole-genre Funk pattern bank exists');
const patterns = vm.runInNewContext(`(${match[1]})`);
assert.equal(patterns.length, 5, 'five whole-genre Funk groove families exist');
for (const pattern of patterns) {
  assert.ok(pattern.events.some(([lane, step]) => lane === 'kick' && step === 0), `${pattern.name}: downbeat kick`);
  assert.ok(pattern.events.some(([lane, step]) => lane === 'snare' && step === 4), `${pattern.name}: beat-2 snare accent`);
  assert.ok(pattern.events.some(([lane, step]) => lane === 'snare' && step === 12), `${pattern.name}: beat-4 snare accent`);
  assert.ok(pattern.events.some(([lane, , velocity]) => lane === 'altSnare' && velocity <= 40), `${pattern.name}: quiet ghost notes`);
  for (const [lane, step, velocity] of pattern.events) {
    assert.ok(['kick','snare','altSnare','hiTom','midTom','lowTom','closedHat','openHat','crash','ride'].includes(lane), `${pattern.name}: known lane`);
    assert.ok(Number.isInteger(step) && step >= 0 && step <= 15, `${pattern.name}: 16-step position ${step}`);
    assert.ok(Number.isFinite(velocity) && velocity >= 1 && velocity <= 127, `${pattern.name}: MIDI velocity ${velocity}`);
  }
}
const linear = patterns.find(pattern => pattern.name === 'Linear Ghost Groove');
assert.equal(new Set(linear.events.map(event => event[1])).size, linear.events.length, 'linear groove has no stacked instrument events');
assert.match(src, /if \(currentGenre\.key === "funk"\) \{\s*generateFunkPattern\(preserved\);\s*applyGrooveVariation\(\);\s*applyBridgePhraseArc\(\);\s*applyRepetitionVerseFill\(\);\s*applyChorusPhraseFill\(\);\s*applyBridgePhraseFill\(\);\s*return;/, 'Funk routes through dedicated whole-genre engine');
assert.match(src, /const byLaneStep = new Map\(\)/, 'same-lane duplicates are merged before MIDI creation');
assert.match(src, /funkSmall: \(\) => funkFillGrammar\(false\)/, 'Funk small fill remains available');
assert.match(src, /funkBig: \(\) => funkFillGrammar\(true\)/, 'Funk big fill remains available');
console.log('PASS: whole-genre Funk grammar, five patterns, grid, dynamics, accents, linearity and fill hooks.');
