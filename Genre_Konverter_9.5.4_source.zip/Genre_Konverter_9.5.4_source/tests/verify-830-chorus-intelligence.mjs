import assert from 'node:assert/strict';
import fs from 'node:fs';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
const manifest = JSON.parse(fs.readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'));
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
assert.equal(manifest.version, '9.5.4');
assert.equal(pkg.version, '9.5.4');
assert.match(ui, /Version 9\.5\.4/);
assert.match(ui, /Chorus Intelligence 8\.4\.0/);
for (const family of ['rock','blues','punk','funk','jazz','reggae','dub','ska','hiphop','heavy','breaks']) {
  assert.match(ui, new RegExp(`\\b${family}:\\s*\\{ lift:`), `${family} has an authored chorus profile`);
}
for (const pass of ['First','Second','Final']) assert.ok(ui.includes(pass.toLowerCase()) || ui.includes('sectionPass'));
assert.match(ui, /restrainedGenres/);
assert.match(ui, /barsCount >= 8 \? \[0,4,7\]/);
assert.match(ui, /if \(lockedLanes\.has\(lane\.key\)\) continue/);
assert.match(ui, /function applyRepetitionIntelligence\(\)[\s\S]*?currentSection !== "verse"/);
console.log('PASS: 8.3.0 Chorus Intelligence has genre profiles, restrained mode, phrase landmarks, pass-aware shaping and locked-lane protection.');
