import fs from "node:fs";
import assert from "node:assert/strict";
const src = fs.readFileSync(new URL("../src/ui.ts", import.meta.url), "utf8");
assert.match(src, /function punkFillGrammar\(big, flavor = "classic"\)/, "dedicated Punk fill grammar exists");
assert.match(src, /punkSmall: \(\) => punkFillGrammar\(false, "classic"\)/);
assert.match(src, /punkBig: \(\) => punkFillGrammar\(true, "classic"\)/);
assert.match(src, /popPunkSmall: \(\) => punkFillGrammar\(false, "pop"\)/);
assert.match(src, /popPunkBig: \(\) => punkFillGrammar\(true, "pop"\)/);
assert.match(src, /push\(out, lane, t, velocity \* scale, 0, true\)/, "Punk hits are locked to the grid");
assert.match(src, /landing: \{ lane: "crash", vel: 120 \}/, "fills resolve into a crash landing");
assert.match(src, /Version 9\.5\.4/);
console.log("PASS: Punk and Pop Punk use dedicated grid-locked fill variants with controlled accents and crash landings.");

assert.match(src, /Classic Punk/);
assert.match(src, /Skate Punk/);
assert.match(src, /Hardcore Punk/);
assert.match(src, /choose ONE coherent sub-style per generated eight-bar/);
