import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const { createRequire } = await import('node:module');
const require = createRequire(import.meta.url);
const grammar = require('../dist/modules/grooveGrammar.js').GROOVE_GRAMMAR;
const expected = ['hardRock','bluesRock','psychRock','progRock','symphonicRock','punkRock','popPunk','grunge','altRock','indieRock','nuMetal','gothicRock','glamRock','reggae','ska','jazz','hiphop','rap','dub','breakbeat','jungle','drumAndBass','lofi'];
assert.deepEqual(Object.keys(grammar), expected, 'all 23 non-Classic-Rock/non-Funk genres have coordinated recipes');
const lanes = new Set(['kick','snare','altSnare','midTom','lowTom','closedHat','openHat','hiTom','crash','ride']);
for (const [genre, recipes] of Object.entries(grammar)) {
  assert.ok(recipes.length >= 12, `${genre}: at least twelve coordinated groove recipes`);
  const signatures = new Set();
  for (const [index, recipe] of recipes.entries()) {
    for (const [lane, steps] of Object.entries(recipe)) {
      assert.ok(lanes.has(lane), `${genre} recipe ${index}: known lane ${lane}`);
      assert.ok(Array.isArray(steps), `${genre} recipe ${index}: lane ${lane} is an array`);
      for (const step of steps) assert.ok(Number.isInteger(step) && step >= 0 && step <= 15, `${genre} recipe ${index}: step ${step} is on the 16th grid`);
    }
    signatures.add(JSON.stringify(recipe));
  }
  assert.ok(signatures.size >= 12, `${genre}: twelve recipes are distinct`);
}
assert.ok(grammar.reggae[0].kick.includes(8) && grammar.reggae[0].altSnare.includes(8), 'Reggae first recipe preserves the one-drop on beat 3');
assert.ok(grammar.ska[0].closedHat.every(step => [2,6,10,14].includes(step)), 'Ska first recipe emphasizes offbeats');
assert.ok(grammar.rap[0].snare.includes(8), 'Rap/Trap first recipe uses half-time snare');
assert.ok(grammar.jazz[0].ride.length >= 8, 'Jazz first recipe uses a ride-led pulse');
for (const key of ['hardRock','punkRock','altRock']) assert.ok(grammar[key].length >= 8, `${key}: expanded Groove Intelligence bank has at least eight recipes`);
console.log('PASS: 23 genre groove banks each have at least 12 distinct recipes, valid 16th-step grids and style anchors.');
