import fs from 'node:fs';
import assert from 'node:assert/strict';
const ui = fs.readFileSync(new URL('../src/ui.ts', import.meta.url), 'utf8');
assert.match(ui, /<label>Performance Feel <span id="pocketVal">20<\/span><\/label>/);
assert.match(ui, /function applyPerformanceFeel\(laneKey, t, vel\)/);
assert.match(ui, /function applyPocketSwing\(laneKey, t, vel\) \{ return applyPerformanceFeel\(laneKey, t, vel\); \}/);
assert.match(ui, /const GROOVE_INTELLIGENCE_PROFILES = \{/);
for (const key of ['classicRock','hardRock','bluesRock','psychRock','progRock','symphonicRock','punkRock','popPunk','grunge','altRock','indieRock','nuMetal','gothicRock','glamRock','funk','reggae','ska','jazz','hiphop','rap','dub','breakbeat','jungle','drumAndBass','lofi']) {
  assert.match(ui, new RegExp('\\b'+key+'\\s*:'), `profile ${key} exists`);
}
assert.match(ui, /Micro Timing/);
assert.match(ui, /Dynamics \+ Articulation/);
assert.match(ui, /Interaction references only events in the immutable base pattern/);
assert.match(ui, /Repetition variation is deterministic and deliberately smaller/);
assert.match(ui, /Swing remains independent/);
assert.match(ui, /const intensity = raw === 0 \? 0 : Math.pow\(raw, 0.78\)/);
assert.match(ui, /timingMs \* bpm \/ 60000/);
assert.match(ui, /velocity:18, accent:15, articulation:13/);
assert.match(ui, /currentPattern\[key\] \|\| \[\]/, 'interaction reads existing notes only');
assert.doesNotMatch(ui.slice(ui.indexOf('function applyPerformanceFeel'), ui.indexOf('// ---- Web Audio preview engine')), /\.push\(/, 'performance transform does not add notes');
console.log('PASS: 9.3.8 Performance Feel 2.0 UI, five bounded components and all 25 genre profiles verified.');
