import fs from 'node:fs';
import assert from 'node:assert/strict';
const root = new URL('../', import.meta.url);
const ui = fs.readFileSync(new URL('src/ui.ts', root), 'utf8');
const manifest = JSON.parse(fs.readFileSync(new URL('manifest.json', root), 'utf8'));
const pkg = JSON.parse(fs.readFileSync(new URL('package.json', root), 'utf8'));
assert.equal(manifest.version, '9.5.4');
assert.equal(pkg.version, '9.5.4');
assert.match(ui, /<div id="versionTag">Version 9\.5\.4<\/div>/);
for (const key of ['CRASH_SAMPLE_B64','RIDE_SAMPLE_B64','KICK_SAMPLE_B64','SNARE_SAMPLE_B64','RIM_SAMPLE_B64','LOWTOM_SAMPLE_B64','MIDTOM_SAMPLE_B64','HITOM_SAMPLE_B64','CLOSEDHAT_SAMPLE_B64','OPENHAT_SAMPLE_B64']) {
  assert.match(ui, new RegExp(`const ${key} = "[A-Za-z0-9+/]{1000}`), `${key} must contain embedded MP3 data`);
}
assert.match(ui, /drumSamplesReady = Promise\.all\(/);
assert.match(ui, /await drumSamplesReady/);
assert.match(ui, /refusing synthetic fallback/);
assert.doesNotMatch(ui, /fallback\(t, g \* PREVIEW_OUTPUT_BOOST\)/);
assert.match(ui, /function playAltSnare\(t, g, v\) \{ playSampleHit\(t, g, rimBuffer, "altSnare", v\); \}/);
for (const file of ['src/genreTabs.ts','src/classicRockTabs.ts','src/grooveGrammar.ts','src/patterns.ts','src/genreExpansion.ts','src/extension.ts']) assert.ok(fs.existsSync(new URL(file, root)));
console.log('PASS: 8.7.0 embeds all ten original MP3s, waits for decode, blocks synth fallbacks, and keeps MIDI modules present.');
