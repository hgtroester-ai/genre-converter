import fs from 'node:fs';
import assert from 'node:assert/strict';
const root = new URL('../', import.meta.url);
const ui = fs.readFileSync(new URL('src/ui.ts', root), 'utf8');
const manifest = JSON.parse(fs.readFileSync(new URL('manifest.json', root), 'utf8'));
const pkg = JSON.parse(fs.readFileSync(new URL('package.json', root), 'utf8'));
assert.equal(manifest.version, '9.5.4');
assert.equal(pkg.version, '9.5.4');
assert.match(ui, /const PREVIEW_OUTPUT_BOOST = 10;/);
assert.match(ui, /const PREVIEW_HIT_PEAK = 0\.88;/);
assert.match(ui, /sampleSegmentPeak\(buffer, layer\)/);
assert.match(ui, /Math\.min\(requestedGain, lanePeakTarget \/ sourcePeak, laneMaxGain\)/);
assert.match(ui, /linearRampToValueAtTime\(safeGain, t \+ 0\.0025\)/);
assert.match(ui, /masterCompressorNode\.ratio\.value = 12;/);
// Preview-only update: MIDI generation modules remain separate and present.
for (const file of ['src/genreTabs.ts','src/classicRockTabs.ts','src/grooveGrammar.ts','src/patterns.ts','src/genreExpansion.ts','src/extension.ts']) {
  assert.ok(fs.existsSync(new URL(file, root)), `${file} remains present`);
}
console.log('PASS: 8.7.0 original sample preview engine, per-hit peak guard, smoothing and release metadata.');
