import { normalizeAudioEngine } from './audio-engine-fingerprint.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import vm from 'node:vm';

const ui = fs.readFileSync('src/ui.ts', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const manifest = JSON.parse(fs.readFileSync('manifest.json', 'utf8'));
assert.equal(pkg.version, '9.5.4');
assert.equal(manifest.version, '9.5.4');
assert.match(ui, /id="versionTag">Version 9\.5\.4<\/div>/);
assert.match(ui, /applyFunkProbabilityEngine\(\);\s*applyFunkDrummerIntelligence\(\);/);

const marker = '// Funk Drummer Intelligence 9.5.0.';
const start = ui.indexOf(marker);
const end = ui.indexOf('\n}\n\n// Funk Probability Engine', start);
assert.ok(start >= 0 && end > start, 'Drummer Intelligence function exists');
const fnSource = ui.slice(ui.indexOf('function applyFunkDrummerIntelligence()', start), end + 2);
assert.doesNotMatch(fnSource, /Math\.random|chance\(/, 'intelligence pass is deterministic and does not duplicate probability generation');
assert.match(fnSource, /currentSection === "fill"/, 'fills are excluded');
assert.match(fnSource, /lockedLanes\.has\("closedHat"\)/, 'hat close respects lane locks');
assert.match(fnSource, /ghostNoteFunk: \{ lane: "closedHat"/);
assert.match(fnSource, /newOrleansFunk: \{ lane: "altSnare"/);
assert.match(fnSource, /jazzFunk: \{ lane: "closedHat"/);
assert.match(fnSource, /amenBreakFunk: \{ lane: "closedHat"/);

function run(dr) {
  const state = {
    currentGenre: { key: 'funk' }, currentSection: 'verse', grooveVariation: 0,
    barsCount: 4, funkProbabilityGeneration: 1, funkDrummer: dr,
    beatsPerBar: () => 4,
    lockedLanes: new Set(),
    LANES: ['kick','snare','altSnare','hiTom','midTom','lowTom','closedHat','openHat','crash','ride'].map(key => ({key})),
    currentPattern: Object.fromEntries(['kick','snare','altSnare','hiTom','midTom','lowTom','closedHat','openHat','crash','ride'].map(key => [key, []])),
    addHit(lane, beat, velocity) { state.currentPattern[lane].push([beat, velocity]); }
  };
  const context = vm.createContext(state);
  vm.runInContext(fnSource, context);
  return { state, context };
}
const invoke = ctx => vm.runInContext('applyFunkDrummerIntelligence()', ctx);

// Open hat must not be choked on the same step; a quiet close is inserted 1/16 later.
let {state: s, context: ctx} = run('ghostNoteFunk');
s.currentPattern.openHat = [[1, 92]];
s.currentPattern.closedHat = [[1, 64], [2, 60]];
invoke(ctx);
assert.deepEqual(s.currentPattern.closedHat, [[1.25, 34], [2, 60]]);

// A locked hat lane is never rewritten.
({state: s, context: ctx} = run('ghostNoteFunk'));
s.lockedLanes.add('closedHat');
s.currentPattern.openHat = [[1, 92]];
s.currentPattern.closedHat = [[1, 64]];
invoke(ctx);
assert.deepEqual(s.currentPattern.closedHat, [[1, 64]]);

// Linear Funk keeps one voice per sixteenth; an existing locked voice wins.
({state: s, context: ctx} = run('linearFunk'));
s.currentPattern.kick = [[0.25, 110]];
s.currentPattern.closedHat = [[0.25, 50]];
invoke(ctx);
assert.deepEqual(s.currentPattern.kick, [[0.25, 110]]);
assert.deepEqual(s.currentPattern.closedHat, []);
({state: s, context: ctx} = run('linearFunk'));
s.lockedLanes.add('closedHat');
s.currentPattern.kick = [[0.25, 110]];
s.currentPattern.closedHat = [[0.25, 50]];
invoke(ctx);
assert.deepEqual(s.currentPattern.kick, []);
assert.deepEqual(s.currentPattern.closedHat, [[0.25, 50]]);

// Ghost Note Funk removes at most one selected hat in every second bar at high variation.
({state: s, context: ctx} = run('ghostNoteFunk'));
s.grooveVariation = 80;
s.currentPattern.closedHat = [[4.5,60],[6.5,60],[0.5,60],[2.5,60]];
invoke(ctx);
assert.equal(s.currentPattern.closedHat.length, 3);
assert.ok(!s.currentPattern.closedHat.some(([beat]) => Math.abs(beat - 4.5) < 0.01));

// New Orleans leaves a ghost-note breathing space; Amen uses a rarer cycle.
({state: s, context: ctx} = run('newOrleansFunk'));
s.grooveVariation = 80;
s.currentPattern.altSnare = [[4.75,28],[6.75,27]];
invoke(ctx);
assert.equal(s.currentPattern.altSnare.length, 1);
({state: s, context: ctx} = run('amenBreakFunk'));
s.grooveVariation = 90;
s.currentPattern.closedHat = [[12.5,60],[13.5,60],[14.5,60]];
invoke(ctx);
assert.equal(s.currentPattern.closedHat.length, 2);

// Fill clips are completely untouched.
({state: s, context: ctx} = run('ghostNoteFunk'));
s.currentSection = 'fill';
s.currentPattern.openHat = [[1,92]];
s.currentPattern.closedHat = [[1,64]];
invoke(ctx);
assert.deepEqual(s.currentPattern.closedHat, [[1,64]]);

// The Web Audio preview engine remains byte-identical after excluding the replaced MP3 sample payloads and format labels.
const audioMarker = '// ---- Web Audio preview engine ----';
const audioHash = crypto.createHash('sha256').update(normalizeAudioEngine(ui.slice(ui.indexOf(audioMarker)))).digest('hex');
assert.equal(audioHash, '4ee4780c679cac8bfa7a5d007863008bb4853e1a99a30a2519d5a54f6bdd0776');
console.log('PASS 9.5.0: drummer-specific breathing, open-hat close, linear limb constraints, lane locks, fill exclusion and Audio Engine integrity.');
