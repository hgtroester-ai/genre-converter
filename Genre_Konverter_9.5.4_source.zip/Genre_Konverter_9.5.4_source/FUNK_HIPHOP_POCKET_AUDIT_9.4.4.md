# Funk & Hip-Hop Pocket Refinement — 9.4.4

## Development baseline

Version 9.4.4 is built from the working 9.4.3 source. The complete Web Audio preview engine is intentionally preserved byte-for-byte. The SHA-256 of the preview-engine suffix beginning at `// ---- Web Audio preview engine ----` is:

`d7f78bb9bb3ff7eab0b2fd07e2bea000e9ac87d945c415622f25492ebc77fd23`

The same hash was verified in the 9.4.3 and 9.4.4 transpiled `dist/modules/ui.js` files.

## Funk

- Existing five Funk drummer profiles and their authored note patterns remain unchanged.
- Existing ghost-note events receive a bounded velocity contour; the main snare anchors are not moved.
- Closed-hat accents distinguish quarter-note anchors, eighth-note offbeats and finer subdivisions.
- Open-hat accents receive a small bounded lift.
- Kick notes that coincide with a main snare are softened slightly; anticipations before the main backbeat receive a restrained lift.
- Linear Funk timing and its single-voice authored orchestration are not rewritten.

## Hip-Hop and Rap

- Hip-Hop keeps a spacious hat pulse with stronger quarter-note anchors and softer offbeat articulations.
- Rap uses a more articulated subdivision contour.
- Ghost-snare velocities are kept within a bounded range and respond to their proximity to the next main snare event.
- Syncopated kick notes receive a small lift, while kick/snare collisions are balanced slightly.
- Rap may receive one restrained sixteenth-note phrase-end hat pickup when Groove Variation is at least 40%, outside the dedicated Fill section, with the hat lane unlocked and sufficient existing hat activity.

## Boundaries

- No GUI layout changes.
- No changes to Fill Intensity or fill-generation routines.
- No changes to Re-shuffle.
- No changes to Reggae, Dub, Jazz, Jungle, Drum & Bass or other genre profiles.
- No changes to the audio preview code, embedded WAVs, AudioContext startup, sample decoding, scheduler, gain or mixing.

## Verification

- Full `npm run test:verify` suite passed.
- New `verify-944-funk-hiphop-pocket.mjs` verifies genre scope, bounded deterministic refinement, drummer preservation, Rap pickup conditions and byte-identical preview engine.
- Actual playback in Ableton Live remains a user-side listening check; automated tests cannot certify sound output from the host.
