# Genre Intelligence 9.5.2

## Scope

- Added a single genre-specific voice-articulation contour inside the existing Performance Feel transform.
- Covers all 25 genre keys with distinct hat, kick, snare and cymbal articulation roles.
- Re-shapes velocities of existing MIDI events only; it does not add, remove or move notes.
- Performance Feel remains the sole owner of micro-timing; Groove Variation and genre-specific engines retain their existing responsibilities.
- Respects the existing audio-preview and MIDI-export transform path.

## Protected areas

- No GUI layout changes.
- No pattern-bank or MIDI-map changes.
- No audio preview engine changes.
- No changes to sample data, scheduler, mixer or sample decoding.

## Verification

- Full regression suite.
- Profile coverage for all 25 genres.
- Static checks for velocity-only behavior and single invocation.
- Audio engine source SHA-256 remains identical to the 9.4.8 baseline.
